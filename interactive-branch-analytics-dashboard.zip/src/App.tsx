import { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2,
  Download,
  FileSpreadsheet,
  RefreshCw,
  ShieldCheck,
  Star,
  Timer,
  TriangleAlert,
} from "lucide-react";
import { Sidebar } from "@/components/Sidebar";
import { Header } from "@/components/Header";
import { KpiCard } from "@/components/KpiCard";
import { OpsPulse } from "@/components/OpsPulse";
import { InsightsBar } from "@/components/InsightsBar";
import { TechnicianScorecard } from "@/components/TechnicianScorecard";
import { DayHighlights } from "@/components/DayHighlights";
import { DataTable } from "@/components/DataTable";
import { ImportDialog } from "@/components/ImportDialog";
import { JobRegister } from "@/components/JobRegister";
import { PeriodAnalysis } from "@/components/PeriodAnalysis";
import { BriefAnalysis, FastTrackCard, WarrantyCard } from "@/components/JobPanels";
import { Card } from "@/components/ui/Card";
import { VolumeChart } from "@/components/charts/VolumeChart";
import { TatChart } from "@/components/charts/TatChart";
import { MixDonut } from "@/components/charts/MixDonut";
import { WeekdayPattern } from "@/components/charts/WeekdayPattern";
import {
  buildView,
  SERVICES,
  SLA_HOURS,
  TECHNICIANS,
  type View,
} from "@/lib/data";
import { buildImportedView } from "@/lib/importedView";
import { isImportedDataset, type ImportedDataset } from "@/lib/import";
import {
  buildJobView,
  buildPeriodSummaries,
  isJobDataset,
  warrantySummary,
  type JobDataset,
  type JobView,
} from "@/lib/jobs";
import {
  buildFullReport,
  downloadWorkbook,
  todayStamp,
  warrantyRowsAoa,
} from "@/lib/export";
import { fmtDateLong, fmtHours, fmtInt, fmtPct, fmtScore, fmtShare } from "@/lib/format";

const DAILY_KEY = "carlcare-import-v1";
const JOBS_KEY = "carlcare-jobs-v1";

function loadDaily(): ImportedDataset | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(DAILY_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!isImportedDataset(parsed)) return null;
    return {
      ...parsed,
      rows: parsed.rows.map((r) => ({ ...r, date: new Date(r.ts) })).sort((a, b) => a.ts - b.ts),
    };
  } catch {
    return null;
  }
}

function loadJobs(): JobDataset | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(JOBS_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    return isJobDataset(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

function LegendChips({ items }: { items: { label: string; color: string }[] }) {
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
      {items.map((it) => (
        <span key={it.label} className="inline-flex items-center gap-1.5 text-xs font-medium text-(--text-2)">
          <span className="h-2 w-2 rounded-full" style={{ background: it.color }} />
          {it.label}
        </span>
      ))}
    </div>
  );
}

export default function App() {
  const [days, setDays] = useState(30);
  const [service, setService] = useState("all");
  const [technician, setTechnician] = useState("all");
  const [warranty, setWarranty] = useState("all");
  const [navOpen, setNavOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [dailyDataset, setDailyDataset] = useState<ImportedDataset | null>(() => loadDaily());
  const [jobDataset, setJobDataset] = useState<JobDataset | null>(() => loadJobs());
  const [storageError, setStorageError] = useState(false);
  const [activeSection, setActiveSection] = useState("overview");
  const [dark, setDark] = useState(
    () => typeof document !== "undefined" && document.documentElement.classList.contains("dark")
  );

  const jobMode = jobDataset !== null;
  const dailyMode = !jobMode && dailyDataset !== null;
  const imported = jobMode || dailyMode;

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try {
      localStorage.setItem("carlcare-theme", dark ? "dark" : "light");
    } catch {
      /* private mode */
    }
  }, [dark]);

  useEffect(() => {
    setStorageError(false);
    try {
      if (jobDataset) {
        localStorage.removeItem(DAILY_KEY);
        localStorage.setItem(JOBS_KEY, JSON.stringify(jobDataset));
      } else {
        localStorage.removeItem(JOBS_KEY);
      }
      if (dailyDataset) localStorage.setItem(DAILY_KEY, JSON.stringify(dailyDataset));
      else localStorage.removeItem(DAILY_KEY);
    } catch {
      setStorageError(true);
    }
  }, [jobDataset, dailyDataset]);

  const view: View = useMemo(() => {
    if (jobDataset) {
      return buildJobView(jobDataset.jobs, { days, service, technician, warranty: warranty as "all" | "in" | "out" | "unknown" });
    }
    if (dailyDataset) {
      return buildImportedView(dailyDataset.rows, { days, service, technician });
    }
    return buildView({ days, service, technician });
  }, [jobDataset, dailyDataset, days, service, technician, warranty]);

  const jobView = jobMode ? (view as JobView) : null;

  const jobScope = useMemo(() => {
    if (!jobDataset) return [];
    return jobDataset.jobs.filter(
      (j) =>
        (warranty === "all" || j.warranty === warranty) &&
        (service === "all" || j.service === service) &&
        (technician === "all" || j.technician === technician)
    );
  }, [jobDataset, warranty, service, technician]);

  const periodSummaries = useMemo(() => {
    if (!jobScope.length) return null;
    return {
      daily: buildPeriodSummaries(jobScope, "day", 14),
      weekly: buildPeriodSummaries(jobScope, "week", 10),
      monthly: buildPeriodSummaries(jobScope, "month", 12),
    };
  }, [jobScope]);

  const asOf = useMemo(() => {
    if (jobDataset) {
      const latest = jobDataset.jobs.reduce((m, j) => Math.max(m, j.dateOut ?? 0, j.dateIn), 0);
      return latest ? new Date(latest) : undefined;
    }
    if (dailyDataset) return new Date(dailyDataset.rows[dailyDataset.rows.length - 1].ts);
    return undefined;
  }, [jobDataset, dailyDataset]);

  const sectionIds = useMemo(
    () => (jobMode ? ["overview", "brief", "warranty", "throughput", "tat", "team", "register", "periods"] : ["overview", "throughput", "tat", "team", "log"]),
    [jobMode]
  );

  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return;
    const els = sectionIds.map((id) => document.getElementById(id)).filter((el): el is HTMLElement => !!el);
    if (!els.length) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActiveSection(visible[0].target.id);
      },
      { rootMargin: "-20% 0px -55% 0px", threshold: 0 }
    );
    els.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [sectionIds]);

  const serviceOptions = useMemo(() => {
    if (jobDataset) {
      const values = Array.from(new Set(jobDataset.jobs.map((j) => j.service))).sort();
      return [{ value: "all", label: "All service lines" }, ...values.map((v) => ({ value: v, label: v }))];
    }
    return [{ value: "all", label: "All service lines" }, ...SERVICES.map((s) => ({ value: s.key, label: s.short }))];
  }, [jobDataset]);

  const technicianOptions = useMemo(() => {
    if (jobDataset) {
      const values = Array.from(new Set(jobDataset.jobs.map((j) => j.technician))).sort();
      return [{ value: "all", label: "All technicians" }, ...values.map((v) => ({ value: v, label: v }))];
    }
    return [{ value: "all", label: "All technicians" }, ...TECHNICIANS.map((t) => ({ value: String(t.id), label: t.name }))];
  }, [jobDataset]);

  const viewKey = `${jobMode ? "j" : dailyMode ? "d" : "s"}|${days}|${service}|${technician}|${warranty}`;
  const periodLabel = days === 0 ? "all history" : `${days} days`;
  const closeRate = view.totals.received ? view.totals.closed / view.totals.received : 0;
  const availableDays = view.availableDays ?? (jobDataset ? new Set(jobDataset.jobs.map((j) => j.dateIn)).size : 0);
  const suggestRange = availableDays > 90 ? 0 : ([7, 14, 30, 90].find((o) => o >= availableDays) ?? 90);
  const modeLabel = jobMode
    ? `${fmtInt(jobDataset.jobs.length)} job cards · ${jobDataset.files.length} workbook${jobDataset.files.length === 1 ? "" : "s"}`
    : dailyMode
      ? `${dailyDataset.rows.length} daily closing rows`
      : `${TECHNICIANS.length} technicians · sample data`;

  const navigate = (id: string) => {
    setActiveSection(id);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const resetFilters = () => {
    setService("all");
    setTechnician("all");
    setWarranty("all");
  };

  const clearData = () => {
    setDailyDataset(null);
    setJobDataset(null);
    resetFilters();
  };

  const exportFullReport = () => {
    if (!jobDataset || !periodSummaries) return;
    downloadWorkbook(`carlcare-full-analysis-${todayStamp()}.xlsx`, buildFullReport({
      jobs: jobScope,
      daily: buildPeriodSummaries(jobScope, "day", 120),
      weekly: periodSummaries.weekly,
      monthly: periodSummaries.monthly,
      warranty: warrantySummary(jobScope),
      meta: `Source: ${jobDataset.files.join(", ")} · ${fmtInt(jobScope.length)} job cards · exported ${new Date().toLocaleString("en-GB")} · filters: ${service}/${technician}/${warranty}`,
    }));
  };

  const missingMetrics = [
    !view.metrics.csat && "CSAT",
    !view.metrics.revenue && "Revenue",
  ].filter(Boolean) as string[];

  return (
    <div className="app-shell min-h-screen">
      <Sidebar
        open={navOpen}
        onClose={() => setNavOpen(false)}
        summary={view.today}
        totals={view.totals}
        imported={imported}
        asOf={asOf}
        onImport={() => setImportOpen(true)}
        activeSection={activeSection}
        onNavigate={navigate}
        jobMode={jobMode}
      />

      <div className="print:pl-0 lg:pl-60">
        <Header
          days={days}
          onDays={setDays}
          service={service}
          onService={setService}
          serviceOptions={serviceOptions}
          technician={technician}
          onTechnician={setTechnician}
          technicianOptions={technicianOptions}
          warranty={warranty}
          onWarranty={setWarranty}
          showWarranty={jobMode}
          breakdownDisabled={dailyMode}
          breakdownHint="Daily-summary imports don't include service or technician rows"
          dark={dark}
          onToggleDark={() => setDark((d) => !d)}
          onMenu={() => setNavOpen(true)}
          imported={imported}
          onImport={() => setImportOpen(true)}
          asOf={asOf}
          modeLabel={modeLabel}
        />

        <main className="mx-auto max-w-[1440px] space-y-4 px-4 py-5 sm:space-y-5 sm:px-6 lg:px-8">
          <div className="hidden print:block">
            <h1 className="font-display text-xl font-bold text-(--text)">Carlcare Islamabad · Daily Branch Analysis</h1>
            <p className="mt-0.5 text-[11px] text-(--text-3)">
              Period: {days === 0 ? "full history" : `last ${days} days`} ending {fmtDateLong(asOf ?? new Date())} · Source:{" "}
              {jobDataset ? jobDataset.files.join(", ") : dailyDataset?.name ?? "sample dataset"} · Generated {fmtDateLong(new Date())}
            </p>
            <div className="mt-2 flex flex-wrap gap-x-8 gap-y-1 text-[11px]">
              <span>Closed <strong>{fmtInt(view.totals.closed)}</strong> of {fmtInt(view.totals.received)}</span>
              <span>Avg TAT <strong>{fmtHours(view.totals.avgTat)}</strong></span>
              <span>SLA met <strong>{fmtShare(view.totals.slaPct)}</strong></span>
              <span>Pending <strong>{fmtInt(view.totals.pending)}</strong></span>
            </div>
          </div>

          {jobMode && (
            <section className="anim-rise flex flex-wrap items-center gap-x-3 gap-y-2.5 rounded-xl border border-(--line) bg-(--surface) px-4 py-3 print:hidden">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-(--brand-soft) text-(--brand-strong)">
                <FileSpreadsheet size={16} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[12.5px] font-semibold text-(--text)">
                  Analysing your day-end workbooks · {jobDataset.name}
                </p>
                <p className="truncate text-[11px] text-(--text-3)">
                  {fmtInt(jobDataset.jobs.length)} job cards · {jobDataset.files.length} file{jobDataset.files.length === 1 ? "" : "s"} ·{" "}
                  {asOf ? fmtDateLong(asOf) : ""} · {fmtShare(jobView?.job.warranty.find((w) => w.key === "in")?.pct ?? 0)} in warranty ·{" "}
                  {fmtInt(jobView?.job.fastJobs.length ?? 0)} closed ≤1h
                </p>
              </div>
              {missingMetrics.length > 0 && (
                <span className="rounded-lg bg-(--surface-2) px-2 py-1 text-[10.5px] text-(--text-3)">
                  Not in sheet: {missingMetrics.join(", ")}
                </span>
              )}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={exportFullReport}
                  className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-(--brand) px-2.5 text-[11.5px] font-semibold text-white hover:bg-(--brand-strong)"
                >
                  <Download size={12} /> Full Excel report
                </button>
                <button
                  type="button"
                  onClick={() => setImportOpen(true)}
                  className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-(--line) px-2.5 text-[11.5px] font-semibold text-(--text-2) hover:border-(--brand) hover:text-(--brand-strong)"
                >
                  <RefreshCw size={12} /> Add files
                </button>
                <button
                  type="button"
                  onClick={clearData}
                  className="inline-flex h-8 items-center rounded-lg px-2 text-[11.5px] font-medium text-(--text-3) hover:bg-(--surface-2) hover:text-(--text)"
                >
                  Use sample data
                </button>
              </div>
            </section>
          )}

          {dailyMode && (
            <section className="anim-rise flex flex-wrap items-center gap-x-3 gap-y-2 rounded-xl border border-(--line) bg-(--surface) px-4 py-3 print:hidden">
              <FileSpreadsheet size={15} className="text-(--brand-strong)" />
              <p className="min-w-0 flex-1 truncate text-[12px] text-(--text-2)">
                Daily summary imported · <span className="font-semibold text-(--text)">{dailyDataset.name}</span> · {dailyDataset.rows.length} closing days.
                Upload a Job Cards sheet to unlock warranty, 1-hour and per-job reports.
              </p>
              <button
                type="button"
                onClick={() => setImportOpen(true)}
                className="rounded-lg border border-(--line) px-2.5 py-1.5 text-[11px] font-semibold text-(--text-2) hover:border-(--brand)"
              >
                Add files
              </button>
              <button type="button" onClick={clearData} className="text-[11px] font-medium text-(--text-3) hover:text-(--text)">
                Use sample
              </button>
            </section>
          )}

          {storageError && (
            <p className="rounded-xl bg-(--warn-soft) px-3 py-2 text-[11px] font-medium text-(--warn)">
              Your files are analysed but too large to save in this browser. Keep this tab open; re-upload after a refresh.
            </p>
          )}

          {imported && view.logs.length === 0 && (
            <div className="flex flex-wrap items-center gap-3 rounded-xl border border-(--warn) bg-(--warn-soft) px-4 py-3">
              <TriangleAlert size={16} className="shrink-0 text-(--warn)" />
              <p className="min-w-0 flex-1 text-xs font-medium text-(--warn)">
                No rows fall inside the selected {days === 0 ? "history" : `${days}-day`} range.
              </p>
              <button
                type="button"
                onClick={() => setDays(suggestRange)}
                className="rounded-lg bg-(--warn) px-2.5 py-1.5 text-[11px] font-bold text-white"
              >
                {suggestRange === 0 ? "Show full history" : `Show ${suggestRange} days`}
              </button>
            </div>
          )}

          <div id="overview" className="grid scroll-mt-24 grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <KpiCard
              label="Job Cards Closed"
              icon={CheckCircle2}
              value={view.totals.closed}
              format={fmtInt}
              delta={view.deltas.closed}
              spark={view.sparks.closed}
              color="var(--brand)"
              periodLabel={periodLabel}
              compared={view.compared}
              delay={0}
              animKey={viewKey}
            />
            <KpiCard
              label="Average TAT"
              icon={Timer}
              value={view.totals.avgTat}
              format={fmtHours}
              delta={view.deltas.avgTat}
              spark={view.sparks.avgTat}
              color="var(--chart-4)"
              periodLabel={periodLabel}
              compared={view.compared}
              delay={60}
              animKey={viewKey}
              goodWhenDown
              target={`≤${SLA_HOURS}h`}
              available={view.totals.closed > 0}
              unavailableNote="no closed jobs in this range"
            />
            <KpiCard
              label="SLA Met"
              icon={ShieldCheck}
              value={view.totals.slaPct}
              format={fmtShare}
              delta={view.deltas.slaPct}
              spark={view.sparks.slaPct}
              color="var(--chart-2)"
              periodLabel={periodLabel}
              compared={view.compared}
              delay={120}
              animKey={viewKey}
              target="goal ≥85%"
              available={view.totals.closed > 0}
              unavailableNote="no closed jobs in this range"
            />
            <KpiCard
              label="Customer CSAT"
              icon={Star}
              value={view.totals.csat}
              format={fmtScore}
              delta={view.deltas.csat}
              spark={view.sparks.csat}
              color="var(--chart-3)"
              periodLabel={periodLabel}
              compared={view.compared}
              delay={180}
              animKey={viewKey}
              target="goal ≥4.5"
              available={view.metrics.csat && view.totals.csat > 0}
              unavailableNote={imported ? "CSAT not in your sheet" : "no ratings in this range"}
            />
          </div>

          {jobView && periodSummaries && (
            <BriefAnalysis
              view={jobView}
              weekly={periodSummaries.weekly}
              monthly={periodSummaries.monthly}
              days={days}
              sourceLabel={jobDataset?.files.join(", ") ?? "uploaded workbooks"}
            />
          )}

          <OpsPulse totals={view.totals} deltas={view.deltas} metrics={view.metrics} compared={view.compared} />

          <InsightsBar key={viewKey} view={view} imported={dailyMode} />

          {jobView && (
            <div id="warranty" className="grid scroll-mt-24 grid-cols-1 gap-4 sm:gap-5 xl:grid-cols-3">
              <Card
                title="Warranty Contribution"
                subtitle="In vs out-of-warranty submitted devices"
                delay={240}
              >
                <WarrantyCard
                  stats={jobView.job.warranty}
                  onReport={() =>
                    downloadWorkbook(`carlcare-warranty-summary-${todayStamp()}.xlsx`, [
                      { name: "Warranty Contribution", rows: warrantyRowsAoa(jobView.job.warranty) },
                    ])
                  }
                />
              </Card>
              <Card
                title="1-Hour Closures & Ageing"
                subtitle="Repair time of closed jobs and age of open cards"
                className="xl:col-span-2"
                delay={280}
              >
                <FastTrackCard view={jobView} />
              </Card>
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 sm:gap-5 xl:grid-cols-3">
            <Card
              id="throughput"
              title="Job Card Throughput"
              subtitle={
                jobMode
                  ? `${fmtShare(closeRate)} closed of submissions · grouped by Date In`
                  : `${fmtShare(closeRate)} closure rate · ${fmtInt(view.totals.pending)} pending in period`
              }
              className="xl:col-span-2"
              delay={300}
              action={<LegendChips items={[{ label: "Received", color: "var(--brand)" }, { label: "Closed", color: "var(--chart-2)" }]} />}
            >
              <div className="mb-2 flex flex-wrap items-baseline gap-x-4 gap-y-1">
                <span className="font-display text-2xl font-bold tabular-nums tracking-tight text-(--text)">
                  {fmtInt(view.totals.closed)}
                  <span className="ml-1 text-sm font-medium text-(--text-3)">of {fmtInt(view.totals.received)}</span>
                </span>
                <span className="text-xs text-(--text-3)">
                  job cards closed
                  {view.compared ? ` (${fmtPct(view.deltas.closed)} vs previous ${periodLabel})` : " · full-history view"}
                </span>
                <span className="ml-auto inline-flex items-center gap-1 rounded-md bg-(--surface-2) px-2 py-1 text-[11px] font-semibold text-(--text-3)">
                  {view.logs.length} closing day{view.logs.length === 1 ? "" : "s"}
                </span>
              </div>
              <div key={viewKey} className="anim-fade">
                <VolumeChart data={view.daily} height={280} />
              </div>
            </Card>

            <Card title="Closing Status Mix" subtitle={jobMode ? "Closed ≤1h, closed later and not closed" : imported ? "Closed, pending and escalated" : "Where received job cards stand at close"} delay={340}>
              <div key={viewKey}>
                <MixDonut segments={view.statusMix} />
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:gap-5 xl:grid-cols-3">
            <Card
              id="tat"
              title="TAT & SLA Performance"
              subtitle={jobMode ? "Turnaround of job cards submitted in this period" : imported ? "Average turnaround and SLA compliance from your daily rows" : `Average turnaround per closed job vs ${SLA_HOURS}h SLA target`}
              className="xl:col-span-2"
              delay={380}
              action={
                <LegendChips
                  items={[
                    { label: "Avg TAT", color: "var(--brand)" },
                    { label: "SLA met", color: "var(--chart-2)" },
                    { label: `${SLA_HOURS}h target`, color: "var(--chart-4)" },
                  ]}
                />
              }
            >
              <div className="mb-2 flex flex-wrap gap-x-6 gap-y-2">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-(--text-3)">Avg TAT</p>
                  <p className="font-display text-xl font-bold tabular-nums leading-tight" style={{ color: view.totals.avgTat <= SLA_HOURS ? "var(--up)" : "var(--down)" }}>
                    {view.totals.avgTat > 0 ? fmtHours(view.totals.avgTat) : "—"}
                    <span className="ml-1 text-[11px] font-medium text-(--text-3)">{view.totals.avgTat <= SLA_HOURS ? `within ${SLA_HOURS}h` : `over ${SLA_HOURS}h`}</span>
                  </p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-(--text-3)">SLA met</p>
                  <p className="font-display text-xl font-bold tabular-nums leading-tight text-(--chart-2)">{view.totals.closed ? fmtShare(view.totals.slaPct) : "—"}</p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-(--text-3)">Closure rate</p>
                  <p className="font-display text-xl font-bold tabular-nums leading-tight text-(--text)">{fmtShare(closeRate)}</p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-(--text-3)">Pending</p>
                  <p className="font-display text-xl font-bold tabular-nums leading-tight" style={{ color: view.totals.pending ? "var(--warn)" : "var(--up)" }}>{fmtInt(view.totals.pending)}</p>
                </div>
                {jobView && (
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-(--text-3)">≤1h closures</p>
                    <p className="font-display text-xl font-bold tabular-nums leading-tight text-(--up)">{fmtInt(jobView.job.fastJobs.length)}</p>
                  </div>
                )}
              </div>
              <div key={viewKey} className="anim-fade">
                <TatChart data={view.daily} />
                {view.serviceStats.length > 0 ? (
                  <>
                    <div className="mt-4 flex items-center justify-between">
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-(--text-3)">Service-line TAT</p>
                      <p className="text-[10px] text-(--text-3)">avg TAT · SLA met</p>
                    </div>
                    <div className="mt-1.5 grid grid-cols-2 gap-2 sm:grid-cols-4">
                      {view.serviceStats.slice(0, 4).map((s) => (
                        <div key={s.key} className="rounded-lg border border-(--line) bg-(--surface-2) px-2.5 py-2">
                          <div className="flex items-center gap-1.5">
                            <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: s.color }} />
                            <span className="truncate text-[10px] font-medium text-(--text-3)">{s.label}</span>
                          </div>
                          <div className="mt-1 flex items-baseline justify-between gap-1">
                            <span className="text-[13px] font-bold tabular-nums" style={{ color: s.avgTat > SLA_HOURS ? "var(--down)" : "var(--text)" }}>{fmtHours(s.avgTat)}</span>
                            <span className="text-[10px] font-bold tabular-nums" style={{ color: s.slaPct >= 0.85 ? "var(--up)" : s.slaPct >= 0.7 ? "var(--warn)" : "var(--down)" }}>{fmtShare(s.slaPct)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <p className="mt-4 rounded-lg border border-dashed border-(--line-strong) px-3 py-2 text-[11px] leading-relaxed text-(--text-3)">
                    This import has no service-line split. Upload a Job Cards sheet to unlock service and technician breakdowns.
                  </p>
                )}
                <WeekdayPattern data={view.weekday} />
              </div>
            </Card>

            <Card
              id="team"
              title="Technician Scorecard"
              subtitle={`Period performance · ${view.ranks.length} technicians · sortable`}
              delay={420}
            >
              <div key={viewKey} className="anim-fade">
                {view.ranks.length > 0 ? <TechnicianScorecard ranks={view.ranks} /> : <DayHighlights logs={view.logs} />}
              </div>
            </Card>
          </div>

          {jobView && periodSummaries && (
            <>
              <Card
                id="register"
                title="Job Card Register"
                subtitle="Every uploaded card · repair time, warranty, technician, status · download any view"
                delay={460}
                bodyClassName="pt-2"
              >
                <JobRegister jobs={jobView.job.cohort} asOf={jobView.job.asOf} days={days} />
              </Card>

              <Card
                id="periods"
                title="Daily / Weekly / Monthly Analysis"
                subtitle="Submission cohorts across your full uploaded history · export any period"
                delay={500}
                bodyClassName="pt-2"
              >
                <PeriodAnalysis jobs={jobScope} sourceLabel={jobDataset?.files.join(", ") ?? "uploaded workbooks"} />
              </Card>
            </>
          )}

          {!jobMode && (
            <Card
              id="log"
              title="Daily Closing Log"
              subtitle={imported ? "Calculated from your imported rows · click any column to sort" : "One row per working day · click any column to sort"}
              delay={460}
              bodyClassName="pt-2"
              action={<span className="hidden rounded-lg bg-(--surface-2) px-2.5 py-1 text-[11px] font-semibold text-(--text-3) sm:block print:hidden">{fmtInt(view.logs.length)} days</span>}
            >
              <DataTable logs={view.logs} days={days} available={view.metrics} />
            </Card>
          )}

          <footer className="flex flex-wrap items-center justify-between gap-2 px-1 pb-4 pt-2 text-[11px] text-(--text-3)">
            <span>Carlcare Islamabad · Service Operations Intelligence</span>
            <span>{imported ? "Your uploaded files stay in this browser · amounts in PKR" : "Sample data · 24h TAT target · amounts in PKR"}</span>
          </footer>
        </main>
      </div>

      <ImportDialog
        open={importOpen}
        onClose={() => setImportOpen(false)}
        currentLabel={jobDataset?.name ?? dailyDataset?.name ?? null}
        onApplyJobs={(d) => {
          setJobDataset(d);
          setDailyDataset(null);
          resetFilters();
          setDays(30);
        }}
        onApplyDaily={(d) => {
          setDailyDataset(d);
          setJobDataset(null);
          resetFilters();
          setDays(30);
        }}
        onLoadDemo={(d) => {
          setJobDataset(d);
          setDailyDataset(null);
          resetFilters();
          setDays(30);
        }}
        onRestoreSample={clearData}
      />
    </div>
  );
}
