/* ------------------------------------------------------------------ */
/*  Carlcare Islamabad — service-center daily closing data engine      */
/*  Sample data is deterministic and realistically distributed.        */
/* ------------------------------------------------------------------ */

export const SLA_HOURS = 24;
export const CENTER = "Carlcare Islamabad Service Center";

export type ServiceKey = "all" | "warranty" | "paid" | "software" | "accessories";

export interface ServiceConf {
  key: Exclude<ServiceKey, "all">;
  label: string;
  short: string;
  color: string;
  share: number;
  tatBase: number;
  revenue: [number, number];
}

export const SERVICES: ServiceConf[] = [
  { key: "warranty", label: "In-warranty repair", short: "Warranty", color: "var(--brand)", share: 0.4, tatBase: 21, revenue: [2800, 7200] },
  { key: "paid", label: "Paid / out-of-warranty", short: "Paid repair", color: "var(--chart-2)", share: 0.33, tatBase: 14, revenue: [6500, 27500] },
  { key: "software", label: "Software & flashing", short: "Software", color: "var(--chart-3)", share: 0.15, tatBase: 4, revenue: [900, 2800] },
  { key: "accessories", label: "Accessories & parts", short: "Accessories", color: "var(--chart-4)", share: 0.12, tatBase: 2, revenue: [500, 4200] },
];

export const SERVICE_OPTIONS = [
  { value: "all", label: "All service lines" },
  ...SERVICES.map((s) => ({ value: s.key, label: s.label })),
];

export interface Technician {
  id: number;
  name: string;
  role: string;
  specialty: Exclude<ServiceKey, "all">;
  base: number;
  speed: number; // <1 is faster than average
  avatar: string;
}

export const TECHNICIANS: Technician[] = [
  { id: 0, name: "Ahmed Raza", role: "Senior Technician", specialty: "paid", base: 8, speed: 0.86, avatar: "AR" },
  { id: 1, name: "Sana Malik", role: "Software Specialist", specialty: "software", base: 9, speed: 0.84, avatar: "SM" },
  { id: 2, name: "Ayesha Noor", role: "Repair Technician", specialty: "warranty", base: 7, speed: 0.93, avatar: "AN" },
  { id: 3, name: "Bilal Khan", role: "Hardware Technician", specialty: "paid", base: 7, speed: 0.98, avatar: "BK" },
  { id: 4, name: "Usman Tariq", role: "Repair Technician", specialty: "warranty", base: 7, speed: 1.02, avatar: "UT" },
  { id: 5, name: "Faisal Mehmood", role: "Parts & Accessories", specialty: "accessories", base: 6, speed: 0.9, avatar: "FM" },
  { id: 6, name: "Hamza Ali", role: "Repair Technician", specialty: "paid", base: 6, speed: 1.08, avatar: "HA" },
  { id: 7, name: "Zain Abbas", role: "Junior Technician", specialty: "software", base: 6, speed: 1.12, avatar: "ZA" },
];

export const TECHNICIAN_OPTIONS = [
  { value: "all", label: "All technicians" },
  ...TECHNICIANS.map((t) => ({ value: String(t.id), label: t.name })),
];

/* ------------------------------ RNG ------------------------------ */

const mulberry32 = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

const startOfDay = (d: Date) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};

export const TODAY = startOfDay(new Date());

export type JobStatus = "delivered" | "in-progress" | "awaiting-parts" | "escalated";

export interface JobRecord {
  id: string;
  ts: number;
  date: Date;
  technicianId: number;
  service: Exclude<ServiceKey, "all">;
  tat: number; // hours
  withinSla: boolean;
  firstTimeFix: boolean;
  csat: number; // 0 = no response collected
  revenue: number;
  status: JobStatus;
}

/* --------------------------- record model ------------------------- */

export const HISTORY_DAYS = 120;

const DOW_FACTOR = [0.26, 1.02, 1.04, 1.0, 0.97, 0.92, 0.8]; // Sun..Sat

const ALL_JOBS: JobRecord[] = (() => {
  const jobs: JobRecord[] = [];

  for (const tech of TECHNICIANS) {
    for (let di = 0; di < HISTORY_DAYS; di++) {
      const date = new Date(TODAY);
      date.setDate(TODAY.getDate() - (HISTORY_DAYS - 1 - di));
      const dow = date.getDay();
      const dom = date.getDate();
      const r = mulberry32((tech.id + 3) * 7919 + di * 104729);

      const season = 1 + Math.sin(di / 9.5) * 0.08;
      const monthStart = dom <= 5 ? 1.1 : 1;
      const surge = r() < 0.045 ? 1.32 : 1;
      const load = DOW_FACTOR[dow] * season * monthStart * surge * (0.84 + r() * 0.32);

      const count = Math.max(0, Math.round(tech.base * load));
      for (let j = 0; j < count; j++) {
        const q = mulberry32((tech.id + 11) * 2654435761 + di * 40503 + j * 7919);

        // choose service line, biased by the technician's specialty
        const weights = SERVICES.map((s) => s.share + (s.key === tech.specialty ? 0.2 : 0));
        const totalW = weights.reduce((a, b) => a + b, 0);
        let roll = q() * totalW;
        let svc = SERVICES[0];
        for (let k = 0; k < SERVICES.length; k++) {
          roll -= weights[k];
          if (roll <= 0) {
            svc = SERVICES[k];
            break;
          }
        }

        // turnaround time in hours
        let tat =
          svc.tatBase *
          (0.55 + q() * 1.15) *
          tech.speed *
          (surge > 1 ? 1.09 : 1) *
          (load > 1.08 ? 1.08 : 0.97);
        if (q() < 0.055) tat += 18 + q() * 34; // parts delay
        tat = Math.min(96, Math.max(0.4, tat));

        const statusRoll = q();
        let status: JobStatus =
          statusRoll < 0.045
            ? "escalated"
            : statusRoll < 0.115
              ? "awaiting-parts"
              : statusRoll < 0.155
                ? "in-progress"
                : "delivered";
        if (status === "escalated") tat = Math.max(tat, 32);

        const withinSla = tat <= SLA_HOURS;
        const firstTimeFix =
          status === "delivered" &&
          q() > 0.05 + (svc.key === "software" ? 0.06 : 0) + (tat > 30 ? 0.1 : 0);

        let csat = 0;
        if (status === "delivered" && q() > 0.07) {
          const raw =
            3.65 +
            (tech.speed < 0.92 ? 0.4 : tech.speed > 1.05 ? 0.02 : 0.2) +
            (withinSla ? 0.32 : -0.25) +
            (firstTimeFix ? 0.2 : -0.4) +
            q() * 0.45;
          csat = Math.round(Math.min(5, Math.max(2.4, raw)) * 10) / 10;
        }

        const [lo, hi] = svc.revenue;
        const revenue =
          status === "delivered" ? Math.round((lo + q() * (hi - lo)) / 100) * 100 : 0;

        jobs.push({
          id: `CC-${date.toISOString().slice(0, 10).replace(/-/g, "")}-${tech.id}${String(j + 1).padStart(2, "0")}`,
          ts: date.getTime(),
          date,
          technicianId: tech.id,
          service: svc.key,
          tat,
          withinSla,
          firstTimeFix,
          csat,
          revenue,
          status,
        });
      }
    }
  }
  return jobs;
})();

/* --------------------------- aggregation -------------------------- */

export type WarrantyFilter = "all" | "in" | "out" | "unknown";

export interface Filters {
  days: number;
  /** service key for sample data, service label for job-card imports */
  service: string;
  /** technician id as a string for sample data, technician name for imports */
  technician: string;
  warranty?: WarrantyFilter;
}

export interface Totals {
  received: number;
  closed: number;
  pending: number;
  avgTat: number;
  slaPct: number;
  ftfr: number;
  csat: number;
  revenue: number;
  escalations: number;
}

export interface DailyPoint extends Totals {
  date: Date;
}

export type DayStatus = "on-track" | "review" | "variance";

export interface DailyRow extends DailyPoint {
  ts: number;
  status: DayStatus;
}

export interface MixSeg {
  key: string;
  label: string;
  value: number;
  color: string;
}

export interface TechRank {
  tech: Technician;
  received: number;
  closed: number;
  avgTat: number;
  slaPct: number;
  csat: number;
  ftfr: number;
}

export interface ServiceStat {
  key: string;
  label: string;
  color: string;
  received: number;
  closed: number;
  avgTat: number;
  slaPct: number;
  revenue: number;
}

export interface WeekdayStat {
  label: string;
  dow: number;
  received: number;
  closed: number;
  avgTat: number;
  slaPct: number;
  days: number;
}

export interface MetricAvailability {
  csat: boolean;
  ftfr: boolean;
  revenue: boolean;
  escalations: boolean;
}

export interface View {
  daily: DailyPoint[];
  totals: Totals;
  prevTotals: Totals;
  deltas: Totals;
  sparks: {
    closed: number[];
    avgTat: number[];
    slaPct: number[];
    csat: number[];
  };
  statusMix: MixSeg[];
  serviceStats: ServiceStat[];
  ranks: TechRank[];
  logs: DailyRow[];
  today: { received: number; closed: number; slaPct: number; pending: number; escalations: number };
  /** weekday staffing pattern, aggregated across the selected period */
  weekday: WeekdayStat[];
  /** which optional metrics exist in the underlying data */
  metrics: MetricAvailability;
  /** true when the trend is measured against a real previous window */
  compared: boolean;
  /** present when the view was built from an imported sheet */
  availableDays?: number;
}

const DOW_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function buildWeekday(daily: DailyPoint[]): WeekdayStat[] {
  return DOW_LABELS.map((label, dow) => {
    const rows = daily.filter((d) => d.date.getDay() === dow && d.received > 0);
    const wsum = rows.reduce((a, d) => a + (d.closed || d.received), 0);
    const wavg = (pick: (d: DailyPoint) => number) =>
      wsum ? rows.reduce((a, d) => a + pick(d) * (d.closed || d.received), 0) / wsum : 0;
    return {
      label,
      dow,
      received: rows.reduce((a, d) => a + d.received, 0),
      closed: rows.reduce((a, d) => a + d.closed, 0),
      avgTat: wavg((d) => d.avgTat),
      slaPct: wavg((d) => d.slaPct),
      days: rows.length,
    };
  });
}

const ALL_METRICS: MetricAvailability = { csat: true, ftfr: true, revenue: true, escalations: true };

const mean = (arr: number[]) =>
  arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;

function derive(jobs: JobRecord[]): Totals {
  const delivered = jobs.filter((j) => j.status === "delivered");
  const csatVals = delivered.map((j) => j.csat).filter((c) => c > 0);
  return {
    received: jobs.length,
    closed: delivered.length,
    pending: jobs.length - delivered.length,
    avgTat: mean(delivered.map((j) => j.tat)),
    slaPct: delivered.length ? delivered.filter((j) => j.withinSla).length / delivered.length : 0,
    ftfr: delivered.length ? delivered.filter((j) => j.firstTimeFix).length / delivered.length : 0,
    csat: mean(csatVals),
    revenue: delivered.reduce((a, j) => a + j.revenue, 0),
    escalations: jobs.filter((j) => j.status === "escalated").length,
  };
}

const pctDelta = (cur: number, prev: number) => (prev ? (cur - prev) / Math.abs(prev) : 0);

function applyFilters(jobs: JobRecord[], f: Filters): JobRecord[] {
  return jobs.filter(
    (j) =>
      (f.service === "all" || j.service === f.service) &&
      (f.technician === "all" || String(j.technicianId) === f.technician)
  );
}

const DAY_MS = 86400000;

export const DAY_STATUS_META: Record<DayStatus, { label: string; fg: string; bg: string; dot: string }> = {
  "on-track": { label: "On track", fg: "var(--up)", bg: "var(--up-soft)", dot: "var(--up)" },
  review: { label: "Review", fg: "var(--warn)", bg: "var(--warn-soft)", dot: "var(--warn)" },
  variance: { label: "Variance", fg: "var(--down)", bg: "var(--down-soft)", dot: "var(--down)" },
};

export function classifyDay(d: Totals): DayStatus {
  const pendingRatio = d.received ? d.pending / d.received : 0;
  if (d.slaPct < 0.68 || d.escalations >= 5) return "variance";
  if (d.slaPct < 0.76 || pendingRatio > 0.26 || d.escalations > 3) return "review";
  return "on-track";
}

export function buildView(filters: Filters): View {
  const allTime = filters.days === 0;
  const end = TODAY.getTime() + DAY_MS;
  const start = allTime ? 0 : end - filters.days * DAY_MS;

  const cur = applyFilters(
    ALL_JOBS.filter((j) => j.ts >= start && j.ts < end),
    filters
  );
  const prev = allTime
    ? []
    : applyFilters(
        ALL_JOBS.filter((j) => j.ts >= start - filters.days * DAY_MS && j.ts < start),
        filters
      );

  const totals = derive(cur);
  const prevTotals = derive(prev);

  const deltas: Totals = {
    received: pctDelta(totals.received, prevTotals.received),
    closed: pctDelta(totals.closed, prevTotals.closed),
    pending: pctDelta(totals.pending, prevTotals.pending),
    avgTat: pctDelta(totals.avgTat, prevTotals.avgTat),
    slaPct: pctDelta(totals.slaPct, prevTotals.slaPct),
    ftfr: pctDelta(totals.ftfr, prevTotals.ftfr),
    csat: pctDelta(totals.csat, prevTotals.csat),
    revenue: pctDelta(totals.revenue, prevTotals.revenue),
    escalations: pctDelta(totals.escalations, prevTotals.escalations),
  };

  // daily buckets, oldest → newest
  const buckets = new Map<number, JobRecord[]>();
  if (allTime) {
    for (const j of cur) if (!buckets.has(j.ts)) buckets.set(j.ts, []);
  } else {
    for (let i = filters.days - 1; i >= 0; i--) {
      const d = new Date(TODAY);
      d.setDate(TODAY.getDate() - i);
      buckets.set(d.getTime(), []);
    }
  }
  for (const j of cur) {
    const bucket = buckets.get(j.ts);
    if (bucket) bucket.push(j);
  }
  const daily: DailyPoint[] = Array.from(buckets.entries())
    .sort((a, b) => a[0] - b[0])
    .map(([ts, jobs]) => {
      const d = new Date(ts);
      return { date: d, ...derive(jobs) };
    });

  const logs: DailyRow[] = daily.map((d) => ({
    ...d,
    ts: d.date.getTime(),
    status: classifyDay(d),
  }));

  const statusMix: MixSeg[] = [
    { key: "delivered", label: "Delivered", color: "var(--chart-2)" },
    { key: "awaiting-parts", label: "Awaiting parts", color: "var(--chart-4)" },
    { key: "in-progress", label: "In progress", color: "var(--brand)" },
    { key: "escalated", label: "Escalated", color: "var(--down)" },
  ].map((s) => ({
    ...s,
    value: cur.filter((j) => j.status === s.key).length,
  }));

  const serviceStats: ServiceStat[] = SERVICES.map((s) => {
    const rows = cur.filter((j) => j.service === s.key);
    const d = derive(rows);
    return {
      key: s.key,
      label: s.short,
      color: s.color,
      received: d.received,
      closed: d.closed,
      avgTat: d.avgTat,
      slaPct: d.slaPct,
      revenue: d.revenue,
    };
  });

  const ranks: TechRank[] = TECHNICIANS.filter(
    (t) => filters.technician === "all" || String(t.id) === filters.technician
  )
    .map((t) => {
      const rows = cur.filter((j) => j.technicianId === t.id);
      const d = derive(rows);
      return {
        tech: t,
        received: d.received,
        closed: d.closed,
        avgTat: d.avgTat,
        slaPct: d.slaPct,
        csat: d.csat,
        ftfr: d.ftfr,
      };
    })
    .sort((a, b) => b.closed - a.closed);

  const todayJobs = ALL_JOBS.filter((j) => j.ts === TODAY.getTime());
  const todayDerived = derive(todayJobs);

  return {
    daily,
    totals,
    prevTotals,
    deltas,
    sparks: {
      closed: daily.map((d) => d.closed),
      avgTat: daily.map((d) => d.avgTat),
      slaPct: daily.map((d) => d.slaPct * 100),
      csat: daily.map((d) => d.csat),
    },
    statusMix,
    serviceStats,
    ranks,
    logs,
    today: {
      received: todayDerived.received,
      closed: todayDerived.closed,
      slaPct: todayDerived.slaPct,
      pending: todayDerived.pending,
      escalations: todayDerived.escalations,
    },
    weekday: buildWeekday(daily),
    metrics: ALL_METRICS,
    compared: prevTotals.received > 0,
  };
}

/* labels used by the UI */
export const serviceLabel = (key: string) =>
  SERVICES.find((s) => s.key === key)?.short ?? key;

export const technicianName = (id: number) =>
  TECHNICIANS.find((t) => t.id === id)?.name ?? "Unassigned";
