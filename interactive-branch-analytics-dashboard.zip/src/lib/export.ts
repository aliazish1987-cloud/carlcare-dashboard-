import * as XLSX from "xlsx";
import type { Job } from "./jobs";
import type { PeriodSummary, WarrantyStat } from "./jobs";

export type Cell = string | number | null;

export interface SheetSpec {
  name: string;
  rows: Cell[][];
}

const stamp = (ts: number | null) => {
  if (!ts) return "";
  const d = new Date(ts);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
};

export const safeSheetName = (name: string) =>
  name.replace(/[\\/?*[\]:]/g, " ").slice(0, 31) || "Sheet";

export function downloadWorkbook(fileName: string, sheets: SheetSpec[]) {
  const wb = XLSX.utils.book_new();
  for (const sheet of sheets) {
    const ws = XLSX.utils.aoa_to_sheet(sheet.rows);
    ws["!cols"] = (sheet.rows[0] ?? []).map((_, i) => ({
      wch: Math.min(
        42,
        Math.max(
          11,
          ...sheet.rows.slice(0, 300).map((r) => String(r[i] ?? "").length + 2)
        )
      ),
    }));
    XLSX.utils.book_append_sheet(wb, ws, safeSheetName(sheet.name));
  }
  XLSX.writeFile(wb, fileName.endsWith(".xlsx") ? fileName : `${fileName}.xlsx`);
}

export function downloadCsv(fileName: string, rows: Cell[][]) {
  const esc = (v: Cell) => {
    const s = v == null ? "" : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const csv = rows.map((r) => r.map(esc).join(",")).join("\n");
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName.endsWith(".csv") ? fileName : `${fileName}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

const warrantyLabel = (w: Job["warranty"]) =>
  w === "in" ? "In warranty" : w === "out" ? "Out of warranty" : "Not specified";

export function jobRowsAoa(jobs: Job[]): Cell[][] {
  return [
    [
      "Job Card No", "Date In", "Date Out", "Repair Time (hours)", "Repair Time",
      "Status", "Warranty", "Service Type", "Device", "Technician",
      "Amount (PKR)", "CSAT", "Source File",
    ],
    ...jobs.map((j) => [
      j.jc,
      stamp(j.dateIn),
      j.dateOut ? stamp(j.dateOut) : "",
      j.tatHours != null ? Math.round(j.tatHours * 100) / 100 : "",
      j.tatHours == null ? "" : j.tatHours < 1 ? `${Math.round(j.tatHours * 60)} min` : `${j.tatHours.toFixed(1)} h`,
      j.closed ? "Closed" : "Not closed",
      warrantyLabel(j.warranty),
      j.service,
      j.device,
      j.technician,
      j.revenue,
      j.csat || "",
      j.source,
    ]),
  ];
}

export function summaryRowsAoa(rows: PeriodSummary[]): Cell[][] {
  return [
    [
      "Period", "Job Cards In", "Closed", "Not Closed", "Avg TAT (h)",
      "SLA Met %", "In Warranty", "In Warranty %", "Out Warranty", "Out Warranty %", "Revenue (PKR)",
    ],
    ...rows.map((r) => [
      r.label,
      r.received,
      r.closed,
      r.pending,
      Math.round(r.avgTat * 10) / 10,
      Math.round(r.slaPct * 1000) / 10,
      r.inCount,
      Math.round(r.inPct * 1000) / 10,
      r.outCount,
      Math.round(r.outPct * 1000) / 10,
      Math.round(r.revenue),
    ]),
  ];
}

export function warrantyRowsAoa(stats: WarrantyStat[]): Cell[][] {
  return [
    ["Warranty", "Submissions", "Contribution %", "Closed", "Avg TAT (h)", "SLA Met %", "Revenue (PKR)"],
    ...stats.map((s) => [
      s.label,
      s.count,
      Math.round(s.pct * 1000) / 10,
      s.closed,
      Math.round(s.avgTat * 10) / 10,
      Math.round(s.slaPct * 1000) / 10,
      Math.round(s.revenue),
    ]),
  ];
}

export function buildFullReport(input: {
  jobs: Job[];
  daily: PeriodSummary[];
  weekly: PeriodSummary[];
  monthly: PeriodSummary[];
  warranty: WarrantyStat[];
  meta: string;
}): SheetSpec[] {
  return [
    { name: "Overview", rows: [["Carlcare Islamabad — Job Card Report"], [input.meta], []] },
    { name: "Job Cards", rows: jobRowsAoa(input.jobs) },
    { name: "Daily Summary", rows: summaryRowsAoa(input.daily) },
    { name: "Weekly Summary", rows: summaryRowsAoa(input.weekly) },
    { name: "Monthly Summary", rows: summaryRowsAoa(input.monthly) },
    { name: "Warranty Contribution", rows: warrantyRowsAoa(input.warranty) },
  ];
}

export function todayStamp() {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
