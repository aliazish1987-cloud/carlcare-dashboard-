/* ------------------------------------------------------------------ */
/*  Flexible CSV / Excel-paste importer for the daily closing sheet    */
/* ------------------------------------------------------------------ */

export interface ImportedRow {
  ts: number;
  date: Date;
  received: number;
  closed: number;
  pending: number;
  avgTat: number;
  slaPct: number;
  ftfr: number;
  csat: number;
  revenue: number;
  escalations: number;
}

export interface ImportedDataset {
  name: string;
  importedAt: number;
  rows: ImportedRow[];
  /** field keys whose columns were present in the sheet */
  mapped?: string[];
}

export interface ColumnMap {
  field: string;
  label: string;
  header: string | null;
  required: boolean;
}

export interface ParseResult {
  rows: ImportedRow[];
  mapping: ColumnMap[];
  warnings: string[];
  errors: string[];
  headerIndex: number;
  preview: string[][];
  dateFrom: Date | null;
  dateTo: Date | null;
}

type FieldDef = {
  key: string;
  label: string;
  required: boolean;
  aliases: string[];
};

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");

export const FIELDS: FieldDef[] = [
  {
    key: "date",
    label: "Date",
    required: true,
    aliases: ["date", "closingdate", "day", "reportdate", "closingday", "workdate", "dateofclosing"],
  },
  {
    key: "received",
    label: "Job cards in",
    required: true,
    aliases: ["received", "jobcards", "jobcardsin", "jobsin", "intakes", "totaljobs", "totaljobcards", "jobsreceived", "receivedjobs", "inward"],
  },
  {
    key: "closed",
    label: "Closed",
    required: true,
    aliases: ["closed", "jobcardsclosed", "delivered", "completed", "closedjobs", "jobsclosed", "closedcards", "deliveries"],
  },
  {
    key: "avgTat",
    label: "Average TAT",
    required: true,
    aliases: ["avgtat", "tat", "averagestat", "averagestat", "turnaroundtime", "turnaround", "avgtathours", "avgtathrs", "tatavg", "averagehandlingtime"],
  },
  {
    key: "slaPct",
    label: "SLA met",
    required: true,
    aliases: ["sla", "slapct", "slamet", "slacompliance", "withinsla", "slapercentage", "slametpct", "slascore", "slasuccess"],
  },
  {
    key: "pending",
    label: "Pending",
    required: false,
    aliases: ["pending", "pendingjobs", "backlog", "wip", "openjobs", "pendingcards", "workinprogress"],
  },
  {
    key: "ftfr",
    label: "First-time fix",
    required: false,
    aliases: ["ftfr", "firsttimefix", "firsttimefixrate", "firsttimefixpct", "ftf", "fixedfirsttime"],
  },
  {
    key: "csat",
    label: "CSAT",
    required: false,
    aliases: ["csat", "satisfaction", "rating", "customersatisfaction", "csatscore", "customerrating"],
  },
  {
    key: "revenue",
    label: "Revenue",
    required: false,
    aliases: ["revenue", "sales", "amount", "servicerevenue", "billing", "collection", "paidamount"],
  },
  {
    key: "escalations",
    label: "Escalations",
    required: false,
    aliases: ["escalations", "escalated", "escalationcount", "escalation", "criticalcases", "escalatedjobs"],
  },
];

/** split one row, honouring quoted fields */
function splitLine(line: string, delim: string): string[] {
  const out: string[] = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (quoted && line[i + 1] === '"') {
        cell += '"';
        i++;
      } else quoted = !quoted;
    } else if (ch === delim && !quoted) {
      out.push(cell);
      cell = "";
    } else cell += ch;
  }
  out.push(cell);
  return out.map((c) => c.trim());
}

function detectDelimiter(lines: string[]): string {
  const sample = lines.filter((l) => l.trim()).slice(0, 5);
  const score = (d: string) => sample.reduce((a, l) => a + splitLine(l, d).length, 0);
  return [
    { d: ",", s: score(",") },
    { d: "\t", s: score("\t") },
    { d: ";", s: score(";") },
  ].sort((a, b) => b.s - a.s)[0].d;
}

export function parseNumber(raw: string | undefined): number {
  if (raw == null) return NaN;
  let s = String(raw).trim();
  if (!s || /^(n\/?a|-|—|--)$/i.test(s)) return NaN;
  s = s.replace(/(pkr|rs\.?|usd|%|hours?|hrs?|minutes?|mins?)/gi, "").trim();
  s = s.replace(/,/g, (_match, offset: number, str: string) => {
    // treat comma as a decimal separator when it is followed by 1–2 digits at the end
    const tail = str.slice(offset + 1);
    return /^\d{1,2}$/.test(tail) ? "." : "";
  });
  s = s.replace(/[^0-9.\-]/g, "");
  const v = Number(s);
  return Number.isFinite(v) ? v : NaN;
}

function toFraction(raw: string | undefined, header: string): number {
  const v = parseNumber(raw);
  if (!Number.isFinite(v)) return 0;
  const hasPct = header.includes("%") || /percent|pct/i.test(header);
  if (hasPct && v > 1) return Math.min(1, v / 100);
  if (v > 1) return Math.min(1, v / 100);
  return Math.max(0, v);
}

function toHours(raw: string | undefined, header: string): number {
  if (raw != null) {
    const s = String(raw).trim();
    // 14:30 or 14h 30m
    const hm = s.match(/^(\d{1,3})\s*[:h]\s*(\d{1,2})\s*m?$/i);
    if (hm) return Number(hm[1]) + Number(hm[2]) / 60;
    // 1 day 4 hrs
    if (/\bday/i.test(s)) {
      const d = s.match(/(\d+(?:\.\d+)?)\s*d/i);
      const hr = s.match(/(\d+(?:\.\d+)?)\s*h/i);
      const min = s.match(/(\d+(?:\.\d+)?)\s*m/i);
      return (d ? Number(d[1]) * 24 : 0) + (hr ? Number(hr[1]) : 0) + (min ? Number(min[1]) / 60 : 0);
    }
  }
  const v = parseNumber(raw);
  if (!Number.isFinite(v)) return NaN;
  return /min/i.test(header) ? v / 60 : v;
}

export function parseDateCell(raw: string | undefined): Date | null {
  if (!raw) return null;
  // day-end exports often carry a timestamp — keep only the date part
  const s = String(raw)
    .trim()
    .replace(/[T\s]+\d{1,2}:\d{2}(:\d{2})?(\s*(am|pm))?$/i, "")
    .trim();
  if (!s) return null;

  // ISO / yyyy-mm-dd
  const iso = s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (iso) {
    const d = new Date(Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]));
    return valid(d) ? d : null;
  }

  // dd/mm/yyyy or mm/dd/yyyy — Pakistan convention is day-first when ambiguous
  const dmy = s.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})$/);
  if (dmy) {
    let day = Number(dmy[1]);
    let month = Number(dmy[2]);
    let year = Number(dmy[3]);
    if (year < 100) year += 2000;
    if (month > 12 && day <= 12) [day, month] = [month, day];
    const d = new Date(year, month - 1, day);
    return valid(d) ? d : null;
  }

  // Excel serial date
  if (/^\d{5}$/.test(s)) {
    const serial = Number(s);
    if (serial > 30000 && serial < 60000) {
      const d = new Date(Date.UTC(1899, 11, 30) + serial * 86400000);
      return valid(d) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
    }
  }

  const parsed = new Date(s);
  return valid(parsed) ? new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate()) : null;
}

const valid = (d: Date) => !Number.isNaN(d.getTime()) && d.getFullYear() > 2000 && d.getFullYear() < 2100;

export function parseSheet(text: string): ParseResult {
  const empty: ParseResult = {
    rows: [],
    mapping: [],
    warnings: [],
    errors: [],
    headerIndex: -1,
    preview: [],
    dateFrom: null,
    dateTo: null,
  };
  if (!text.trim()) return { ...empty, errors: ["No data found. Upload a CSV file or paste rows from Excel."] };

  const lines = text.replace(/\r\n?/g, "\n").split("\n").filter((l) => l.trim() !== "");
  const delim = detectDelimiter(lines);

  // locate the header row: the line that maps to the most known fields
  let bestIdx = -1;
  let bestScore = 0;
  for (let i = 0; i < Math.min(lines.length, 12); i++) {
    const cells = splitLine(lines[i], delim).map(norm);
    const score = FIELDS.reduce(
      (a, f) => a + (cells.some((c) => c && f.aliases.some((al) => c === al || c.includes(al) || al.includes(c))) ? 1 : 0),
      0
    );
    if (score > bestScore) {
      bestScore = score;
      bestIdx = i;
    }
  }
  if (bestIdx < 0 || bestScore < 2) {
    return { ...empty, errors: ["Could not recognise the sheet headers. Make sure the first row contains columns such as Date, Job Cards In, Closed, Avg TAT and SLA."] };
  }

  const headers = splitLine(lines[bestIdx], delim);
  const normalized = headers.map(norm);

  /* Map each field to a column.
     Pass 1 reserves exact alias matches for every field, so an exact
     "Job Cards Closed" can never be stolen by the looser "jobcards" alias
     of "Job Cards In". Pass 2 only considers columns nobody has claimed. */
  const claimed = new Map<number, string>();
  const assignment = new Map<string, number>();

  for (const f of FIELDS) {
    const idx = normalized.findIndex(
      (h, i) => h && !claimed.has(i) && f.aliases.includes(h)
    );
    if (idx >= 0) {
      claimed.set(idx, f.key);
      assignment.set(f.key, idx);
    }
  }

  for (const f of FIELDS) {
    if (assignment.has(f.key)) continue;
    let bestIdx = -1;
    let bestLen = 0;
    normalized.forEach((h, i) => {
      if (!h || claimed.has(i)) return;
      // only allow a fuzzy hit when the whole header is a close variant,
      // not when it merely contains a shorter alias inside a longer word
      const hit = f.aliases.find(
        (al) => (h === al || h.startsWith(al) || al.startsWith(h)) && Math.min(h.length, al.length) >= 4
      );
      if (hit && hit.length > bestLen) {
        bestLen = hit.length;
        bestIdx = i;
      }
    });
    if (bestIdx >= 0) {
      claimed.set(bestIdx, f.key);
      assignment.set(f.key, bestIdx);
    }
  }

  // A genuine "job cards" column that is neither exactly In nor Closed is
  // ambiguous — treat it as received only if nothing else claimed it.
  if (!assignment.has("received") && !assignment.has("closed")) {
    const idx = normalized.findIndex(
      (h, i) => h && !claimed.has(i) && h.includes("jobcard")
    );
    if (idx >= 0) {
      claimed.set(idx, "received");
      assignment.set("received", idx);
    }
  }

  const mapping: ColumnMap[] = FIELDS.map((f) => {
    const idx = assignment.get(f.key);
    return {
      field: f.key,
      label: f.label,
      header: idx !== undefined ? headers[idx] : null,
      required: f.required,
    };
  });

  const col = (key: string) => mapping.find((m) => m.field === key)?.header;
  const missing = mapping.filter((m) => m.required && !m.header);
  const errors: string[] = [];
  const warnings: string[] = [];
  if (missing.length) {
    const labels = missing.map((m) => m.label);
    let hint = "Rename the column(s), or download the template to see accepted headers.";
    if (labels.includes("Job cards in") && labels.length === 1) {
      hint = "Job cards in is needed to calculate closure rate and throughput. Add a 'Job Cards In' column of daily intakes, or use the template.";
    }
    if (labels.includes("Closed") && labels.length === 1) {
      hint = "Add a 'Closed' (or 'Delivered') column with the job cards completed each day.";
    }
    errors.push(
      `Required column${missing.length > 1 ? "s" : ""} not found: ${labels.join(", ")}. ${hint}`
    );
  }

  const idxOf = (key: string): number => {
    const h = col(key);
    return h ? headers.indexOf(h) : -1;
  };

  const rawRows: ImportedRow[] = [];
  for (let li = bestIdx + 1; li < lines.length; li++) {
    const cells = splitLine(lines[li], delim);
    if (cells.every((c) => !c)) continue;
    const get = (key: string) => {
      const i = idxOf(key);
      return i >= 0 ? cells[i] : undefined;
    };
    const date = parseDateCell(get("date"));
    if (!date) {
      if (errors.length < 8) errors.push(`Row ${li + 1}: could not read the date "${get("date") ?? ""}". Use dd/mm/yyyy or yyyy-mm-dd.`);
      continue;
    }
    const received = parseNumber(get("received"));
    const closed = parseNumber(get("closed"));
    if (!Number.isFinite(received) && !Number.isFinite(closed)) {
      if (errors.length < 8) errors.push(`Row ${li + 1} (${get("date")}): job cards in / closed are not numeric.`);
      continue;
    }
    const avgTat = toHours(get("avgTat"), col("avgTat") ?? "tat");
    if (!Number.isFinite(avgTat)) {
      if (errors.length < 8) errors.push(`Row ${li + 1} (${get("date")}): average TAT is missing or not numeric.`);
      continue;
    }
    const rReceived = Math.max(0, Number.isFinite(received) ? received : closed);
    const rClosed = Math.max(0, Number.isFinite(closed) ? closed : received);
    const pendingRaw = parseNumber(get("pending"));
    const ftfrRaw = get("ftfr");
    const csat = parseNumber(get("csat"));
    const revenue = parseNumber(get("revenue"));
    const escalations = parseNumber(get("escalations"));

    rawRows.push({
      ts: date.getTime(),
      date,
      received: rReceived,
      closed: rClosed,
      pending: Number.isFinite(pendingRaw) ? Math.max(0, pendingRaw) : Math.max(0, rReceived - rClosed),
      avgTat: Math.max(0, avgTat),
      slaPct: toFraction(get("slaPct"), col("slaPct") ?? "sla"),
      ftfr: ftfrRaw ? toFraction(ftfrRaw, col("ftfr") ?? "ftfr") : 0,
      csat: Number.isFinite(csat) ? Math.min(5, Math.max(0, csat)) : 0,
      revenue: Number.isFinite(revenue) ? Math.max(0, revenue) : 0,
      escalations: Number.isFinite(escalations) ? Math.max(0, escalations) : 0,
    });
    if (rawRows.length > 2000) {
      warnings.push("Only the first 2,000 daily rows were imported.");
      break;
    }
  }

  if (!rawRows.length && !errors.length) errors.push("No usable daily rows were found below the header row.");
  if (!col("csat")) warnings.push("No CSAT column detected — the CSAT card will show 0.00.");
  if (!col("revenue")) warnings.push("No revenue column detected — revenue insights will show Rs 0.");
  if (!col("ftfr")) warnings.push("No first-time-fix column detected — FTFR will show 0.0%.");

  // merge duplicate dates (e.g. per-technician exports) so the log has one row per day
  const byDate = new Map<number, ImportedRow>();
  let merged = 0;
  for (const r of rawRows) {
    const existing = byDate.get(r.ts);
    if (!existing) {
      byDate.set(r.ts, { ...r });
      continue;
    }
    merged++;
    const wA = existing.closed || existing.received || 1;
    const wB = r.closed || r.received || 1;
    const sla = (existing.slaPct * wA + r.slaPct * wB) / (wA + wB);
    const tat = (existing.avgTat * wA + r.avgTat * wB) / (wA + wB);
    const ftfr = (existing.ftfr * wA + r.ftfr * wB) / (wA + wB);
    const csats = [existing.csat, r.csat].filter((c) => c > 0);
    byDate.set(r.ts, {
      ...existing,
      received: existing.received + r.received,
      closed: existing.closed + r.closed,
      pending: existing.pending + r.pending,
      escalations: existing.escalations + r.escalations,
      revenue: existing.revenue + r.revenue,
      avgTat: tat,
      slaPct: sla,
      ftfr,
      csat: csats.length ? csats.reduce((a, b) => a + b, 0) / csats.length : 0,
    });
  }
  if (merged > 0) {
    warnings.push(
      merged === 1
        ? "1 duplicate date row was combined into a single closing day."
        : `${merged} duplicate date rows were combined into single closing days.`
    );
  }

  const rows = Array.from(byDate.values()).sort((a, b) => a.ts - b.ts);
  if (rows.length > 1) {
    const span = (rows[rows.length - 1].ts - rows[0].ts) / 86400000;
    if (span > 400) warnings.push("The sheet spans more than 400 days — consider splitting it by month.");
  }

  return {
    rows,
    mapping,
    warnings,
    errors,
    headerIndex: bestIdx,
    preview: lines.slice(bestIdx, bestIdx + 6).map((l) => splitLine(l, delim)),
    dateFrom: rows[0]?.date ?? null,
    dateTo: rows[rows.length - 1]?.date ?? null,
  };
}

/* ---------------------------- template ---------------------------- */

const iso = (d: Date) => {
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
};

export function buildTemplateCsv(): string {
  const header = [
    "Date", "Job Cards In", "Closed", "Pending", "Avg TAT (hours)",
    "SLA Met (%)", "First Time Fix (%)", "CSAT", "Revenue (PKR)", "Escalations",
  ];
  const rows: string[][] = [];
  const examples = [
    [52, 46, 6, 14.2, 84, 92, 4.6, 318000, 1],
    [48, 44, 4, 12.8, 88, 94, 4.7, 286500, 0],
    [16, 15, 1, 18.5, 72, 90, 4.3, 86500, 2],
    [61, 54, 7, 16.1, 79, 91, 4.5, 402000, 1],
    [57, 51, 6, 13.9, 83, 93, 4.6, 371500, 0],
    [45, 42, 3, 11.6, 90, 95, 4.8, 265000, 0],
    [50, 47, 3, 12.4, 86, 94, 4.7, 298500, 1],
  ];
  examples.forEach((e, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (examples.length - 1 - i));
    rows.push([iso(d), ...e.map(String)]);
  });
  return [header.join(","), ...rows.map((r) => r.join(","))].join("\n");
}

const numericKeys: (keyof ImportedRow)[] = [
  "ts", "received", "closed", "pending", "avgTat", "slaPct", "ftfr", "csat", "revenue", "escalations",
];

/** validate a dataset restored from localStorage */
export function isImportedDataset(value: unknown): value is ImportedDataset {
  if (!value || typeof value !== "object") return false;
  const d = value as Record<string, unknown>;
  if (typeof d.name !== "string" || !Array.isArray(d.rows) || d.rows.length === 0) return false;
  return d.rows.every(
    (r) =>
      r != null &&
      typeof r === "object" &&
      numericKeys.every((k) => typeof (r as Record<string, unknown>)[k] === "number")
  );
}
