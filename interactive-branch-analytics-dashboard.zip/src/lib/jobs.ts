/* ------------------------------------------------------------------ */
/*  Job-card level analytics (from uploaded Carlcare day-end sheets)   */
/* ------------------------------------------------------------------ */

import {
  buildWeekday,
  classifyDay,
  SLA_HOURS,
  type DailyPoint,
  type DailyRow,
  type Filters,
  type MetricAvailability,
  type MixSeg,
  type ServiceStat,
  type Technician,
  type TechRank,
  type Totals,
  type View,
} from "./data";

export type Warranty = "in" | "out" | "unknown";

export interface Job {
  id: string;
  jc: string;
  source: string;
  dateIn: number;
  dateOut: number | null;
  closed: boolean;
  warranty: Warranty;
  service: string;
  technician: string;
  device: string;
  tatHours: number | null;
  revenue: number;
  csat: number;
}

export interface JobDataset {
  kind: "jobs";
  name: string;
  importedAt: number;
  files: string[];
  jobs: Job[];
}

export interface WarrantyStat {
  key: Warranty;
  label: string;
  color: string;
  count: number;
  pct: number;
  closed: number;
  avgTat: number;
  slaPct: number;
  revenue: number;
}

export interface BucketStat {
  key: string;
  label: string;
  count: number;
  color: string;
}

export interface JobExtras {
  cohort: Job[];
  closedJobs: Job[];
  openJobs: Job[];
  fastJobs: Job[];
  warranty: WarrantyStat[];
  tatBuckets: BucketStat[];
  agingBuckets: BucketStat[];
  asOf: number;
  fastPct: number;
  openOver72: number;
}

export type JobView = View & { job: JobExtras };

const HOUR = 3600000;
const DAY = 86400000;

export const SLA_TARGET = 0.85;
export const FAST_TRACK_HOURS = 1;

const COVERS = ["var(--brand)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

const mean = (a: number[]) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);

export const formatTat = (h: number | null) => {
  if (h == null || !Number.isFinite(h)) return "—";
  if (h < 1) return `${Math.max(1, Math.round(h * 60))}m`;
  if (h < 24) return `${h.toFixed(1)}h`;
  const d = Math.floor(h / 24);
  const rem = h - d * 24;
  return `${d}d ${rem.toFixed(0)}h`;
};

const ageHours = (job: Job, asOf: number) =>
  Math.max(0, (asOf - job.dateIn) / HOUR);

/* ------------------------------ summaries ------------------------- */

function summariseJobs(cohort: Job[]): Omit<Totals, "ftfr" | "escalations"> & {
  ftfr: number;
  escalations: number;
} {
  const closedJobs = cohort.filter((j) => j.closed);
  const timed = closedJobs.filter((j) => j.tatHours != null);
  return {
    received: cohort.length,
    closed: closedJobs.length,
    pending: cohort.length - closedJobs.length,
    avgTat: mean(timed.map((j) => j.tatHours as number)),
    slaPct: timed.length
      ? timed.filter((j) => (j.tatHours as number) <= SLA_HOURS).length / timed.length
      : 0,
    ftfr: 0,
    csat: mean(cohort.filter((j) => j.csat > 0).map((j) => j.csat)),
    revenue: closedJobs.reduce((a, j) => a + j.revenue, 0),
    escalations: 0,
  };
}

const pctDelta = (cur: number, prev: number) => (prev ? (cur - prev) / Math.abs(prev) : 0);
const share = (part: number, whole: number) => (whole ? part / whole : 0);

export function warrantySummary(cohort: Job[]): WarrantyStat[] {
  return warrantyStats(cohort);
}

function warrantyStats(cohort: Job[]): WarrantyStat[] {
  const defs: { key: Warranty; label: string; color: string }[] = [
    { key: "in", label: "In warranty", color: "var(--chart-2)" },
    { key: "out", label: "Out of warranty", color: "var(--brand)" },
    { key: "unknown", label: "Not specified", color: "var(--text-3)" },
  ];
  return defs
    .map((d) => {
      const rows = cohort.filter((j) => j.warranty === d.key);
      const closed = rows.filter((j) => j.closed);
      const timed = closed.filter((j) => j.tatHours != null);
      return {
        ...d,
        count: rows.length,
        pct: share(rows.length, cohort.length),
        closed: closed.length,
        avgTat: mean(timed.map((j) => j.tatHours as number)),
        slaPct: timed.length
          ? timed.filter((j) => (j.tatHours as number) <= SLA_HOURS).length / timed.length
          : 0,
        revenue: closed.reduce((a, j) => a + j.revenue, 0),
      };
    })
    .filter((w) => w.count > 0);
}

/* --------------------------- view builder ------------------------ */

export function buildJobView(
  allJobs: Job[],
  filters: Filters,
  mapped: string[] = []
): JobView {
  const asOf = allJobs.reduce((m, j) => Math.max(m, j.dateIn), 0) || Date.now();
  const dayEnd = (() => {
    const d = new Date(asOf);
    d.setHours(23, 59, 59, 999);
    return d.getTime();
  })();
  const allTime = filters.days === 0;
  const end = dayEnd + 1;
  const start = allTime ? 0 : end - filters.days * DAY;

  const segment = allJobs.filter(
    (j) =>
      (filters.warranty === "all" || j.warranty === filters.warranty) &&
      (filters.service === "all" || j.service === filters.service) &&
      (filters.technician === "all" || j.technician === filters.technician)
  );

  const cohort = segment.filter((j) => j.dateIn >= start && j.dateIn < end);
  const prevCohort = allTime
    ? []
    : segment.filter((j) => j.dateIn >= start - filters.days * DAY && j.dateIn < start);

  const build = (rows: Job[]) => {
    const t = summariseJobs(rows);
    return {
      ...t,
      escalations: rows.filter(
        (j) => !j.closed && ageHours(j, asOf) > 72
      ).length,
    };
  };

  const totals = build(cohort);
  const prevTotals = build(prevCohort);
  const deltas: Totals = {
    received: pctDelta(totals.received, prevTotals.received),
    closed: pctDelta(totals.closed, prevTotals.closed),
    pending: pctDelta(totals.pending, prevTotals.pending),
    avgTat: pctDelta(totals.avgTat, prevTotals.avgTat),
    slaPct: pctDelta(totals.slaPct, prevTotals.slaPct),
    ftfr: 0,
    csat: pctDelta(totals.csat, prevTotals.csat),
    revenue: pctDelta(totals.revenue, prevTotals.revenue),
    escalations: pctDelta(totals.escalations, prevTotals.escalations),
  };

  // daily cohorts by submission date
  const bucketKeys: number[] = [];
  if (allTime) {
    const seen = new Set<number>();
    cohort.forEach((j) => {
      const d = new Date(j.dateIn);
      d.setHours(0, 0, 0, 0);
      if (!seen.has(d.getTime())) {
        seen.add(d.getTime());
        bucketKeys.push(d.getTime());
      }
    });
    bucketKeys.sort((a, b) => a - b);
  } else {
    for (let i = filters.days - 1; i >= 0; i--) {
      const d = new Date(dayEnd);
      d.setDate(d.getDate() - i);
      d.setHours(0, 0, 0, 0);
      bucketKeys.push(d.getTime());
    }
  }

  const daily: DailyPoint[] = bucketKeys.map((ts) => {
    const rows = cohort.filter((j) => j.dateIn >= ts && j.dateIn < ts + DAY);
    const derived = build(rows);
    return { date: new Date(ts), ...derived };
  });

  const logs: DailyRow[] = daily.map((d) => ({
    ...d,
    ts: d.date.getTime(),
    status: classifyDay(d),
  }));

  const closedJobs = cohort.filter((j) => j.closed);
  const openJobs = cohort.filter((j) => !j.closed);
  const fastJobs = closedJobs.filter(
    (j) => j.tatHours != null && (j.tatHours as number) <= FAST_TRACK_HOURS
  );

  const statusMix: MixSeg[] = [
    {
      key: "fast",
      label: "Closed ≤1h",
      value: fastJobs.length,
      color: "var(--up)",
    },
    {
      key: "standard",
      label: "Closed 1h+",
      value: closedJobs.length - fastJobs.length,
      color: "var(--chart-2)",
    },
    { key: "open", label: "Not closed", value: openJobs.length, color: "var(--chart-4)" },
  ];

  const serviceGroups = new Map<string, Job[]>();
  cohort.forEach((j) => {
    const key = j.service || "General";
    if (!serviceGroups.has(key)) serviceGroups.set(key, []);
    serviceGroups.get(key)!.push(j);
  });
  const serviceStats: ServiceStat[] = Array.from(serviceGroups.entries())
    .map(([key, rows], i) => {
      const closed = rows.filter((j) => j.closed);
      const timed = closed.filter((j) => j.tatHours != null);
      return {
        key,
        label: key,
        color: COVERS[i % COVERS.length],
        received: rows.length,
        closed: closed.length,
        avgTat: mean(timed.map((j) => j.tatHours as number)),
        slaPct: timed.length
          ? timed.filter((j) => (j.tatHours as number) <= SLA_HOURS).length / timed.length
          : 0,
        revenue: closed.reduce((a, j) => a + j.revenue, 0),
      };
    })
    .sort((a, b) => b.received - a.received)
    .slice(0, 5);

  const techGroups = new Map<string, Job[]>();
  cohort.forEach((j) => {
    const key = j.technician || "Unassigned";
    if (!techGroups.has(key)) techGroups.set(key, []);
    techGroups.get(key)!.push(j);
  });
  const ranks: TechRank[] = Array.from(techGroups.entries())
    .map(([name, rows], i) => {
      const closed = rows.filter((j) => j.closed);
      const timed = closed.filter((j) => j.tatHours != null);
      const tech: Technician = {
        id: i,
        name,
        role: name === "Unassigned" ? "Not assigned in sheet" : "Repair technician",
        specialty: "paid",
        base: 0,
        speed: 1,
        avatar: name
          .split(/\s+/)
          .map((w) => w[0])
          .join("")
          .slice(0, 2)
          .toUpperCase(),
      };
      return {
        tech,
        received: rows.length,
        closed: closed.length,
        avgTat: mean(timed.map((j) => j.tatHours as number)),
        slaPct: timed.length
          ? timed.filter((j) => (j.tatHours as number) <= SLA_HOURS).length / timed.length
          : 0,
        csat: mean(rows.filter((j) => j.csat > 0).map((j) => j.csat)),
        ftfr: 0,
      };
    })
    .sort((a, b) => b.closed - a.closed);

  const tatBuckets: BucketStat[] = [
    { key: "fast", label: "≤1 hour", count: 0, color: "var(--up)" },
    { key: "quarter", label: "1–4 hours", count: 0, color: "var(--chart-2)" },
    { key: "day", label: "4–24 hours", count: 0, color: "var(--brand)" },
    { key: "two-day", label: "24–48 hours", count: 0, color: "var(--chart-4)" },
    { key: "slow", label: "Over 48 hours", count: 0, color: "var(--down)" },
    { key: "untimed", label: "No timing in sheet", count: 0, color: "var(--text-3)" },
  ];
  closedJobs.forEach((j) => {
    const t = j.tatHours;
    if (t == null) tatBuckets[5].count++;
    else if (t <= 1) tatBuckets[0].count++;
    else if (t <= 4) tatBuckets[1].count++;
    else if (t <= 24) tatBuckets[2].count++;
    else if (t <= 48) tatBuckets[3].count++;
    else tatBuckets[4].count++;
  });
  const agingBuckets: BucketStat[] = [
    { key: "fresh", label: "Open ≤24h", count: 0, color: "var(--chart-2)" },
    { key: "mid", label: "Open 1–3 days", count: 0, color: "var(--chart-4)" },
    { key: "late", label: "Open 3–7 days", count: 0, color: "var(--chart-3)" },
    { key: "critical", label: "Open over 7 days", count: 0, color: "var(--down)" },
  ];
  openJobs.forEach((j) => {
    const a = ageHours(j, asOf);
    if (a <= 24) agingBuckets[0].count++;
    else if (a <= 72) agingBuckets[1].count++;
    else if (a <= 168) agingBuckets[2].count++;
    else agingBuckets[3].count++;
  });

  const metrics: MetricAvailability = {
    csat: mapped.includes("csat") || allJobs.some((j) => j.csat > 0),
    ftfr: false,
    revenue: mapped.includes("revenue") || allJobs.some((j) => j.revenue > 0),
    escalations: false,
  };

  const availableDays = new Set(
    allJobs.map((j) => {
      const d = new Date(j.dateIn);
      d.setHours(0, 0, 0, 0);
      return d.getTime();
    })
  ).size;

  const lastDay = daily[daily.length - 1];

  const view: View = {
    daily,
    totals: { ...totals, ftfr: 0, escalations: totals.escalations },
    prevTotals: { ...prevTotals, ftfr: 0, escalations: prevTotals.escalations },
    deltas,
    sparks: {
      closed: daily.map((d) => d.closed),
      avgTat: daily.map((d) => d.avgTat),
      slaPct: daily.map((d) => d.slaPct * 100),
      csat: daily.map((d) => d.csat),
    },
    statusMix,
    serviceStats,
    ranks,
    logs,
    today: {
      received: lastDay?.received ?? 0,
      closed: lastDay?.closed ?? 0,
      slaPct: lastDay?.slaPct ?? 0,
      pending: lastDay?.pending ?? 0,
      escalations: lastDay?.escalations ?? 0,
    },
    weekday: buildWeekday(daily),
    metrics,
    compared: prevCohort.length > 0,
    availableDays,
  };

  return {
    ...view,
    job: {
      cohort,
      closedJobs,
      openJobs,
      fastJobs,
      warranty: warrantyStats(cohort),
      tatBuckets,
      agingBuckets,
      asOf,
      fastPct: share(fastJobs.length, closedJobs.length),
      openOver72: openJobs.filter((j) => ageHours(j, asOf) > 72).length,
    },
  };
}

/* ------------------------ weekly / monthly ----------------------- */

export type Granularity = "day" | "week" | "month";

export interface PeriodSummary {
  key: string;
  label: string;
  start: number;
  end: number;
  received: number;
  closed: number;
  pending: number;
  avgTat: number;
  slaPct: number;
  inCount: number;
  outCount: number;
  inPct: number;
  outPct: number;
  revenue: number;
  /** true while the week/month is still in progress */
  partial: boolean;
}

const startOfWeek = (d: Date) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  const day = (x.getDay() + 6) % 7; // Monday start
  x.setDate(x.getDate() - day);
  return x;
};

const monthName = new Intl.DateTimeFormat("en-US", { month: "short" });
const longDay = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" });

export function buildPeriodSummaries(
  jobs: Job[],
  granularity: Granularity,
  limit = 14
): PeriodSummary[] {
  const groups = new Map<string, Job[]>();
  for (const j of jobs) {
    const d = new Date(j.dateIn);
    d.setHours(0, 0, 0, 0);
    let key: string;
    if (granularity === "day") {
      key = `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
    } else if (granularity === "week") {
      const w = startOfWeek(d);
      key = `W${w.getFullYear()}-${w.getMonth() + 1}-${w.getDate()}`;
    } else {
      key = `${d.getFullYear()}-${d.getMonth() + 1}`;
    }
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(j);
  }

  // classify in-progress periods against the latest submission date, not future repair timestamps
  const asOfTs = Math.max(...jobs.map((j) => j.dateIn), 0);
  const rows = Array.from(groups.entries()).map(([key, cohort]) => {
    const closed = cohort.filter((j) => j.closed);
    const timed = closed.filter((j) => j.tatHours != null);
    const inCount = cohort.filter((j) => j.warranty === "in").length;
    const outCount = cohort.filter((j) => j.warranty === "out").length;
    const starts = cohort.map((j) => j.dateIn);
    const first = new Date(Math.min(...starts));
    first.setHours(0, 0, 0, 0);

    let periodEnd: number;
    if (granularity === "day") {
      periodEnd = new Date(first.getFullYear(), first.getMonth(), first.getDate(), 23, 59, 59, 999).getTime();
    } else if (granularity === "week") {
      const w = startOfWeek(first);
      periodEnd = new Date(w.getFullYear(), w.getMonth(), w.getDate() + 6, 23, 59, 59, 999).getTime();
    } else {
      periodEnd = new Date(first.getFullYear(), first.getMonth() + 1, 0, 23, 59, 59, 999).getTime();
    }

    return {
      key,
      label: groupLabel(key, cohort),
      start: Math.min(...starts),
      end: Math.max(...starts),
      received: cohort.length,
      closed: closed.length,
      pending: cohort.length - closed.length,
      avgTat: mean(timed.map((j) => j.tatHours as number)),
      slaPct: timed.length
        ? timed.filter((j) => (j.tatHours as number) <= SLA_HOURS).length / timed.length
        : 0,
      inCount,
      outCount,
      inPct: share(inCount, cohort.length),
      outPct: share(outCount, cohort.length),
      revenue: closed.reduce((a, j) => a + j.revenue, 0),
      partial: asOfTs > 0 && periodEnd > asOfTs,
    };
  });

  rows.sort((a, b) => a.start - b.start);
  return rows.slice(-limit);
}

function groupLabel(key: string, cohort: Job[]): string {
  if (key.startsWith("W")) {
    const w = startOfWeek(new Date(cohort[0].dateIn));
    const end = new Date(w);
    end.setDate(w.getDate() + 6);
    return `${longDay.format(w)} – ${longDay.format(end)}`;
  }
  if (key.includes("-") && key.split("-").length === 2) {
    const [y, m] = key.split("-").map(Number);
    const d = new Date(y, m - 1, 1);
    return `${monthName.format(d)} ${y}`;
  }
  return longDay.format(new Date(cohort[0].dateIn));
}

/* ------------------------------ validation ----------------------- */

export function isJobDataset(value: unknown): value is JobDataset {
  if (!value || typeof value !== "object") return false;
  const d = value as Record<string, unknown>;
  if (
    d.kind !== "jobs" ||
    typeof d.name !== "string" ||
    !Array.isArray(d.jobs) ||
    d.jobs.length === 0
  )
    return false;
  return d.jobs.every((j) => {
    if (!j || typeof j !== "object") return false;
    const r = j as Record<string, unknown>;
    return (
      typeof r.jc === "string" &&
      typeof r.dateIn === "number" &&
      typeof r.closed === "boolean" &&
      typeof r.warranty === "string"
    );
  });
}

/* ------------------------------ demo data ------------------------ */

const mulberry32 = (seed: number) => {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
};

const DEVICES = [
  "Infinix Note 40 Pro",
  "Infinix Hot 50",
  "Infinix Zero 30",
  "Tecno Camon 30",
  "Tecno Spark 20 Pro",
  "Tecno Pova 6",
  "itel A70",
  "itel S24",
  "Infinix Smart 9",
  "Tecno Phantom V2",
];
const SERVICE_LINES = ["Battery", "Display", "Charging port", "Software", "Camera", "Board repair", "Accessories"];
const TECHS = ["Ahmed Raza", "Sana Malik", "Ayesha Noor", "Bilal Khan", "Usman Tariq", "Faisal Mehmood", "Hamza Ali", "Zain Abbas"];
const ROLES = ["Senior technician", "Software specialist", "Repair technician", "Hardware technician"];

export function makeDemoJobDataset(): JobDataset {
  const jobs: Job[] = [];
  const r = mulberry32(20261017);
  const days = 95;
  const end = new Date();
  end.setHours(23, 59, 59, 999);

  for (let di = 0; di < days; di++) {
    const day = new Date(end);
    day.setDate(end.getDate() - (days - 1 - di));
    day.setHours(0, 0, 0, 0);
    const dow = day.getDay();
    const weekend = dow === 0 ? 0.35 : dow === 6 ? 0.78 : 1;
    const payday = day.getDate() >= 27 ? 1.18 : 1;
    const count = Math.round((25 + r() * 16) * weekend * payday * (0.92 + di / days * 0.14));

    for (let k = 0; k < count; k++) {
      const inAt = day.getTime() + (9 * HOUR) + r() * (10 * HOUR);
      const ageH = (end.getTime() - inAt) / HOUR;
      const closeProb = ageH > 96 ? 0.97 : ageH > 48 ? 0.9 : ageH > 24 ? 0.74 : 0.52;
      const closed = r() < closeProb;
      let tat: number | null = null;
      if (closed) {
        const fast = r() < 0.17;
        tat = fast
          ? 0.3 + r() * 0.65
          : Math.min(ageH - 0.5, 1 + Math.pow(r(), 2.1) * 62);
        tat = Math.max(0.25, tat);
      }
      const warrantyRoll = r();
      const warranty: Warranty =
        warrantyRoll < 0.61 ? "in" : warrantyRoll < 0.975 ? "out" : "unknown";
      const service = SERVICE_LINES[Math.floor(r() * SERVICE_LINES.length)];
      const tech = r() < 0.05 ? "Unassigned" : TECHS[Math.floor(r() * TECHS.length)];
      const revenue =
        warranty === "out" && closed
          ? Math.round((service === "Board repair" ? 9000 + r() * 14000 : 1800 + r() * 8000) / 100) * 100
          : closed && r() < 0.25
            ? Math.round((500 + r() * 2000) / 100) * 100
            : 0;
      jobs.push({
        id: `${inAt}-${k}`,
        jc: `JC-${String(day.getFullYear()).slice(2)}${String(day.getMonth() + 1).padStart(2, "0")}${String(day.getDate()).padStart(2, "0")}-${String(k + 1).padStart(3, "0")}`,
        source: "demo-day-end.xlsx",
        dateIn: Math.round(inAt),
        dateOut: closed && tat != null ? Math.round(inAt + tat * HOUR) : null,
        closed,
        warranty,
        service,
        technician: tech,
        device: DEVICES[Math.floor(r() * DEVICES.length)],
        tatHours: closed ? Math.round((tat as number) * 100) / 100 : null,
        revenue,
        csat: closed && r() < 0.55 ? Math.round((3.4 + r() * 1.6) * 10) / 10 : 0,
      });
    }
  }

  return {
    kind: "jobs",
    name: "Carlcare Islamabad · 95-day demo workbook",
    importedAt: Date.now(),
    files: ["demo-day-end.xlsx"],
    jobs,
  };
}

export const JOB_ROLES = ROLES;
