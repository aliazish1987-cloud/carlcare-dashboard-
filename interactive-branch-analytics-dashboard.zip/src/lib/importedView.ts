import type { ImportedRow } from "./import";
import {
  buildWeekday,
  classifyDay,
  type DailyPoint,
  type DailyRow,
  type Filters,
  type MetricAvailability,
  type MixSeg,
  type Totals,
  type View,
} from "./data";

const DAY = 86400000;

function weighted(rows: ImportedRow[], pick: (r: ImportedRow) => number, weight: (r: ImportedRow) => number) {
  let num = 0;
  let den = 0;
  for (const r of rows) {
    const w = Math.max(weight(r), 0);
    num += pick(r) * w;
    den += w;
  }
  return den ? num / den : 0;
}

function aggregate(rows: ImportedRow[]): Totals {
  const sum = (pick: (r: ImportedRow) => number) => rows.reduce((a, r) => a + pick(r), 0);
  const csatRows = rows.filter((r) => r.csat > 0);
  const w = (r: ImportedRow) => (r.closed || r.received || 1);
  return {
    received: sum((r) => r.received),
    closed: sum((r) => r.closed),
    pending: sum((r) => r.pending),
    avgTat: weighted(rows, (r) => r.avgTat, w),
    slaPct: weighted(rows, (r) => r.slaPct, w),
    ftfr: weighted(rows, (r) => r.ftfr, w),
    csat: csatRows.length ? weighted(csatRows, (r) => r.csat, w) : 0,
    revenue: sum((r) => r.revenue),
    escalations: sum((r) => r.escalations),
  };
}

const pctDelta = (cur: number, prev: number) => (prev ? (cur - prev) / Math.abs(prev) : 0);

const toPoint = (r: ImportedRow): DailyPoint => ({
  date: r.date,
  received: r.received,
  closed: r.closed,
  pending: r.pending,
  avgTat: r.avgTat,
  slaPct: r.slaPct,
  ftfr: r.ftfr,
  csat: r.csat,
  revenue: r.revenue,
  escalations: r.escalations,
});

/** Builds the dashboard View from an imported daily sheet (no per-job breakdown). */
export function buildImportedView(
  rowsIn: ImportedRow[],
  filters: Filters,
  mapped: string[] = []
): View {
  const rows = [...rowsIn].sort((a, b) => a.ts - b.ts);
  const allTime = filters.days === 0;
  const last = rows[rows.length - 1];
  const end = (last?.ts ?? Date.now()) + DAY;
  const start = allTime ? 0 : end - filters.days * DAY;

  const cur = rows.filter((r) => r.ts >= start && r.ts < end);
  const prev = allTime ? [] : rows.filter((r) => r.ts >= start - filters.days * DAY && r.ts < start);

  const totals = aggregate(cur);
  const prevTotals = aggregate(prev);
  const deltas: Totals = {
    received: pctDelta(totals.received, prevTotals.received),
    closed: pctDelta(totals.closed, prevTotals.closed),
    pending: pctDelta(totals.pending, prevTotals.pending),
    avgTat: pctDelta(totals.avgTat, prevTotals.avgTat),
    slaPct: pctDelta(totals.slaPct, prevTotals.slaPct),
    ftfr: pctDelta(totals.ftfr, prevTotals.ftfr),
    csat: pctDelta(totals.csat, prevTotals.csat),
    revenue: pctDelta(totals.revenue, prevTotals.revenue),
    escalations: pctDelta(totals.escalations, prevTotals.escalations),
  };

  const daily: DailyPoint[] = cur.map(toPoint);
  const logs: DailyRow[] = daily.map((d) => ({
    ...d,
    ts: d.date.getTime(),
    status: classifyDay(d),
  }));

  const statusMix: MixSeg[] = [
    { key: "delivered", label: "Closed", value: totals.closed, color: "var(--chart-2)" },
    { key: "pending", label: "Pending at close", value: totals.pending, color: "var(--brand)" },
    { key: "escalated", label: "Escalated", value: totals.escalations, color: "var(--down)" },
  ];

  // Respect explicit column mapping first, then infer from actual values.
  const metrics: MetricAvailability = {
    csat: mapped.includes("csat") || rows.some((r) => r.csat > 0),
    ftfr: mapped.includes("ftfr") || rows.some((r) => r.ftfr > 0),
    revenue: mapped.includes("revenue") || rows.some((r) => r.revenue > 0),
    escalations: mapped.includes("escalations") || rows.some((r) => r.escalations > 0),
  };

  const lastInScope = cur[cur.length - 1];

  return {
    daily,
    totals,
    prevTotals,
    deltas,
    sparks: {
      closed: daily.map((d) => d.closed),
      avgTat: daily.map((d) => d.avgTat),
      slaPct: daily.map((d) => d.slaPct * 100),
      csat: daily.map((d) => d.csat),
    },
    statusMix,
    serviceStats: [],
    ranks: [],
    logs,
    today: {
      received: lastInScope?.received ?? 0,
      closed: lastInScope?.closed ?? 0,
      slaPct: lastInScope?.slaPct ?? 0,
      pending: lastInScope?.pending ?? 0,
      escalations: lastInScope?.escalations ?? 0,
    },
    weekday: buildWeekday(daily),
    metrics,
    compared: prevTotals.received > 0,
    availableDays: rows.length,
  };
}
