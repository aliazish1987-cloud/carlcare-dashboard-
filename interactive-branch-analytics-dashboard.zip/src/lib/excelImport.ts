import * as XLSX from "xlsx";
import { parseDateCell, parseNumber, parseSheet, type ImportedRow } from "./import";
import type { Job, Warranty } from "./jobs";
import type { SheetSpec } from "./export";

const HOUR = 3600000;

export interface FileReport {
  name: string;
  sheets: { name: string; type: "job cards" | "daily summary" | "skipped"; rows: number; note?: string }[];
  jobRows: number;
  dailyRows: number;
  errors: string[];
  warnings: string[];
}

export interface ParseOutcome {
  jobs: Job[];
  daily: ImportedRow[];
  files: FileReport[];
  errors: string[];
  warnings: string[];
}

const norm = (s: unknown) => String(s ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
const text = (v: unknown) => (v == null ? "" : String(v).trim());

/* ------------------------- job column aliases -------------------- */

const JOB_FIELDS: { key: string; aliases: string[]; required?: boolean }[] = [
  { key: "jc", aliases: ["jobcardno", "jobcardnumber", "jobcard", "jcn", "jcno", "jc", "jobsheetno", "jobsheet", "ticketno", "ticket", "workorder", "workorderno", "wonumber", "serviceorder", "jobid", "caseid"] },
  { key: "dateIn", aliases: ["datein", "inwarddate", "inward", "receiveddate", "receivedon", "submissiondate", "submittedon", "jobdate", "opendate", "createddate", "intakedate", "receiptdate", "bookeddate"], required: true },
  { key: "dateOut", aliases: ["dateout", "outwarddate", "outward", "closeddate", "closedon", "deliverydate", "deliveredon", "completeddate", "completiondate", "handoverdate", "exitdate", "dispatchdate", "readyon"] },
  { key: "status", aliases: ["jobstatus", "status", "currentstatus", "jobstate", "state", "repairstatus", "closedstatus"] },
  { key: "warranty", aliases: ["warrantytype", "warranty", "warrantystatus", "warrantycategory", "inoutwarranty", "typeofwarranty", "coverage", "warrantyclaim", "paidfree"] },
  { key: "service", aliases: ["servicetype", "service", "repairtype", "jobtype", "category", "servicecategory", "faultcategory", "problem", "complaint", "issue", "serviceline"] },
  { key: "technician", aliases: ["technician", "technicianname", "engineer", "engineername", "tech", "assignedto", "repairedby", "repairby", "attendedby", "mechanic", "staff"] },
  { key: "device", aliases: ["devicemodel", "device", "model", "modelname", "product", "productmodel", "brand", "phone", "handset", "item"] },
  { key: "tat", aliases: ["tat", "tathours", "turnaroundtime", "repairtime", "servicetime", "duration", "totaltime", "elapsedtime", "tatduration", "processingtime"] },
  { key: "revenue", aliases: ["amount", "revenue", "charges", "charge", "bill", "billedamount", "invoice", "invoiceamount", "paidamount", "collection", "totalamount", "servicecharge", "partsamount"] },
  { key: "csat", aliases: ["csat", "rating", "satisfaction", "customersatisfaction", "csatscore", "stars", "feedback", "nps"] },
  { key: "date", aliases: ["date", "closingdate", "reportdate", "day", "closingday"] },
];

const DAILY_MARKERS = ["jobcardsin", "received", "closed", "avgtat", "sla", "pending", "ftfr", "csat", "revenue", "escalations"];

function aliasHit(header: string, aliases: string[]) {
  if (!header) return 0;
  if (aliases.includes(header)) return 3;
  const hit = aliases.find(
    (a) => (header.startsWith(a) || a.startsWith(header)) && Math.min(a.length, header.length) >= 4
  );
  return hit ? 2 : 0;
}

function mapJobColumns(headers: string[]) {
  const normalized = headers.map(norm);
  const claimed = new Map<number, string>();
  const assignment = new Map<string, number>();

  for (const f of JOB_FIELDS) {
    const idx = normalized.findIndex((h, i) => h && !claimed.has(i) && f.aliases.includes(h));
    if (idx >= 0 && f.key !== "date") {
      claimed.set(idx, f.key);
      assignment.set(f.key, idx);
    }
  }
  for (const f of JOB_FIELDS) {
    if (assignment.has(f.key)) continue;
    let best = -1;
    let score = 0;
    normalized.forEach((h, i) => {
      if (!h || claimed.has(i)) return;
      const s = aliasHit(h, f.aliases);
      if (s > score) {
        score = s;
        best = i;
      }
    });
    if (best >= 0) {
      claimed.set(best, f.key);
      assignment.set(f.key, best);
    }
  }
  return assignment;
}

/* --------------------------- value parsing ----------------------- */

function readDate(v: unknown): number | null {
  if (v == null || v === "") return null;
  if (v instanceof Date && !Number.isNaN(v.getTime())) return v.getTime();
  if (typeof v === "number") {
    if (v > 1000000000000) return v;
    if (v > 20000 && v < 80000) {
      const d = new Date(Date.UTC(1899, 11, 30) + v * 86400000);
      return Number.isNaN(d.getTime()) ? null : d.getTime();
    }
  }
  const parsed = parseDateCell(String(v));
  return parsed ? parsed.getTime() : null;
}

/** Keeps the time of day so job-card repair time is accurate. */
function readTimestamp(v: unknown): number | null {
  if (v == null || v === "") return null;
  if (v instanceof Date && !Number.isNaN(v.getTime())) return v.getTime();
  if (typeof v === "number") return readDate(v);
  const s = text(v);
  if (!s) return null;

  const iso = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})[T ](\d{1,2}):(\d{2})(?::(\d{2}))?/);
  if (iso) {
    return new Date(
      Number(iso[1]), Number(iso[2]) - 1, Number(iso[3]),
      Number(iso[4]), Number(iso[5]), Number(iso[6] ?? 0)
    ).getTime();
  }

  const dmy = s.match(
    /^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})(?:[ ,T]+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?)?/i
  );
  if (dmy) {
    let day = Number(dmy[1]);
    let month = Number(dmy[2]);
    let year = Number(dmy[3]);
    if (year < 100) year += 2000;
    if (month > 12 && day <= 12) [day, month] = [month, day];
    let hour = Number(dmy[4] ?? 0);
    const minute = Number(dmy[5] ?? 0);
    const second = Number(dmy[6] ?? 0);
    const ampm = dmy[7]?.toLowerCase();
    if (ampm === "pm" && hour < 12) hour += 12;
    if (ampm === "am" && hour === 12) hour = 0;
    return new Date(year, month - 1, day, hour, minute, second).getTime();
  }

  return readDate(s);
}

function readHours(v: unknown, header: string): number | null {
  if (v == null || v === "") return null;
  if (typeof v === "number" && Number.isFinite(v)) {
    return /min/i.test(header) ? v / 60 : v;
  }
  const s = text(v);
  if (!s) return null;
  const hm = s.match(/^(\d{1,3})\s*[:h]\s*(\d{1,2})\s*m?$/i);
  if (hm) return Number(hm[1]) + Number(hm[2]) / 60;
  if (/\bday/i.test(s)) {
    const d = s.match(/(\d+(?:\.\d+)?)\s*d/i);
    const h = s.match(/(\d+(?:\.\d+)?)\s*h/i);
    const m = s.match(/(\d+(?:\.\d+)?)\s*m/i);
    return (d ? Number(d[1]) * 24 : 0) + (h ? Number(h[1]) : 0) + (m ? Number(m[1]) / 60 : 0);
  }
  const n = parseNumber(s);
  if (!Number.isFinite(n)) return null;
  return /min/i.test(header) ? n / 60 : n;
}

function readWarranty(v: unknown): Warranty {
  const s = text(v).toLowerCase();
  if (!s || /^(n\/?a|-|—|unknown|not specified)$/.test(s)) return "unknown";
  if (/out|paid|chargeable|non.?warranty|ow\b|billable/.test(s)) return "out";
  if (/in.?warranty|inwarr|under.?warranty|free|warranty/.test(s)) return "in";
  return "unknown";
}

/* ---------------------------- workbook --------------------------- */

function sheetRows(ws: XLSX.WorkSheet): unknown[][] {
  return XLSX.utils.sheet_to_json<unknown[]>(ws, {
    header: 1,
    raw: true,
    defval: "",
    blankrows: false,
  });
}

export function detectHeader(rows: unknown[][]) {
  let bestIdx = -1;
  let bestScore = 0;
  for (let i = 0; i < Math.min(rows.length, 15); i++) {
    const cells = (rows[i] ?? []).map(norm).filter(Boolean);
    if (cells.length < 2) continue;
    let score = 0;
    for (const c of cells) {
      if (JOB_FIELDS.some((f) => f.aliases.includes(c))) score += 5;
      else if (JOB_FIELDS.some((f) => f.aliases.some((a) => c.startsWith(a) && Math.min(a.length, c.length) >= 4))) score += 2;
      if (DAILY_MARKERS.includes(c)) score += 3;
    }
    // data rows usually start with a JC number, date or numeric value
    if (cells.some((c) => /^\d/.test(c) || /^jc/.test(c))) score -= 1;
    if (score > bestScore) {
      bestScore = score;
      bestIdx = i;
    }
  }
  return bestIdx;
}

function parseJobSheet(rows: unknown[][], sheetName: string, fileName: string, report: FileReport): Job[] {
  const headerIdx = detectHeader(rows);
  if (headerIdx < 0) {
    report.warnings.push(`${sheetName}: no recognisable header row.`);
    return [];
  }
  const headers = (rows[headerIdx] ?? []).map(text);
  const map = mapJobColumns(headers);
  const col = (key: string) => {
    const i = map.get(key);
    return i === undefined ? -1 : i;
  };
  const idxIn = col("dateIn") >= 0 ? col("dateIn") : col("date");
  if (idxIn < 0) {
    report.warnings.push(`${sheetName}: no "Date In" column found — sheet skipped.`);
    return [];
  }

  const jobs: Job[] = [];
  for (let r = headerIdx + 1; r < rows.length; r++) {
    const row = rows[r] ?? [];
    if (row.every((c) => text(c) === "")) continue;
    const get = (key: string) => {
      const i = col(key);
      return i >= 0 ? row[i] : undefined;
    };
    const dateIn = readTimestamp(row[idxIn]);
    if (dateIn == null) continue;

    const statusText = text(get("status")).toLowerCase();
    const dateOutRaw = readTimestamp(get("dateOut"));
    // a genuine job-card row carries at least one job-specific value
    if (
      !text(get("jc")) &&
      dateOutRaw == null &&
      !text(get("warranty")) &&
      !text(get("technician")) &&
      !text(get("device"))
    ) {
      continue;
    }
    const header = (key: string) => {
      const i = col(key);
      return i >= 0 ? headers[i] : "";
    };
    const tatRaw = readHours(get("tat"), header("tat"));
    let closed = dateOutRaw != null;
    if (statusText) {
      if (/not.?closed|open|pending|wip|in.?progress|awaiting|hold|unrepair/i.test(statusText)) closed = false;
      else if (/closed|delivered|completed|ready|handed|dispatched|repaired/i.test(statusText)) closed = true;
    } else if (!closed && tatRaw != null) closed = true;

    let tat = tatRaw;
    if (tat == null && closed && dateOutRaw != null) tat = (dateOutRaw - dateIn) / HOUR;
    if (tat != null && (!Number.isFinite(tat) || tat < 0 || tat > 24 * 365)) tat = null;
    const dateOut = dateOutRaw ?? (closed && tat != null ? dateIn + tat * HOUR : null);

    const jc = text(get("jc")) || `ROW-${r + 1}`;
    const revenue = parseNumber(text(get("revenue")));
    const csat = parseNumber(text(get("csat")));
    jobs.push({
      id: `${fileName}-${sheetName}-${jc}`,
      jc,
      source: fileName,
      dateIn,
      dateOut,
      closed,
      warranty: readWarranty(get("warranty")),
      service: text(get("service")) || "General",
      technician: text(get("technician")) || "Unassigned",
      device: text(get("device")) || "—",
      tatHours: closed ? tat : null,
      revenue: Number.isFinite(revenue) ? Math.max(0, revenue) : 0,
      csat: Number.isFinite(csat) ? Math.min(5, Math.max(0, csat)) : 0,
    });
  }
  return jobs;
}

export function isJobSheet(rows: unknown[][], headerIdx: number): boolean {
  const headers = (rows[headerIdx] ?? []).map(norm);
  const exact = (aliases: string[]) => headers.some((h) => h && aliases.includes(h));

  // only strong, unambiguous job-card markers count here
  const hasJobCardNumber =
    exact(JOB_FIELDS.find((f) => f.key === "jc")!.aliases) ||
    headers.some(
      (h) =>
        /^(jc|jcn|jcno|jobid)$/.test(h) ||
        /^(jobcard(no|number|id)?|jobsheet(no|number)?|ticketno|workorder(no)?|serviceorder)$/.test(h)
    );
  const hasDateIn = exact(JOB_FIELDS.find((f) => f.key === "dateIn")!.aliases) ||
    headers.some((h) => /(datein|inward|receiveddate|submissiondate|jobdate|opendate|intakedate|receiptdate)/.test(h));
  const hasDateOut = exact(JOB_FIELDS.find((f) => f.key === "dateOut")!.aliases) ||
    headers.some((h) => /(dateout|outward|closeddate|deliverydate|completiondate|handoverdate)/.test(h));
  const hasWarranty = exact(JOB_FIELDS.find((f) => f.key === "warranty")!.aliases) ||
    headers.some((h) => /warranty/.test(h));
  const hasTechnician = exact(JOB_FIELDS.find((f) => f.key === "technician")!.aliases) ||
    headers.some((h) => /(technician|engineer|assignedto|repairby|attendedby)/.test(h));
  const hasDevice = exact(JOB_FIELDS.find((f) => f.key === "device")!.aliases) ||
    headers.some((h) => /(device|model|handset|product)/.test(h));

  // daily summary sheets should never be treated as job cards
  const dailyLike = headers.some(
    (h) => h === "jobcardsin" || h === "jobsreceived" || h === "receivedjobs" || h === "avgtat" || h === "slamet" || h === "slametpct"
  );
  if (!hasJobCardNumber && !hasDateOut && !hasWarranty && dailyLike) return false;

  if (hasJobCardNumber && hasDateIn) return true;
  if (!hasJobCardNumber && dailyLike) return false;
  return [hasDateIn, hasWarranty, hasTechnician, hasDateOut, hasDevice].filter(Boolean).length >= 4;
}

function mergeDaily(rows: ImportedRow[]): ImportedRow[] {
  const byTs = new Map<number, ImportedRow>();
  for (const r of rows) {
    const prev = byTs.get(r.ts);
    if (!prev) {
      byTs.set(r.ts, { ...r });
      continue;
    }
    const wA = prev.closed || prev.received || 1;
    const wB = r.closed || r.received || 1;
    const w = wA + wB;
    const csats = [prev.csat, r.csat].filter((c) => c > 0);
    byTs.set(r.ts, {
      ...prev,
      received: prev.received + r.received,
      closed: prev.closed + r.closed,
      pending: prev.pending + r.pending,
      escalations: prev.escalations + r.escalations,
      revenue: prev.revenue + r.revenue,
      avgTat: (prev.avgTat * wA + r.avgTat * wB) / w,
      slaPct: (prev.slaPct * wA + r.slaPct * wB) / w,
      ftfr: (prev.ftfr * wA + r.ftfr * wB) / w,
      csat: csats.length ? csats.reduce((a, b) => a + b, 0) / csats.length : 0,
    });
  }
  return Array.from(byTs.values()).sort((a, b) => a.ts - b.ts);
}

async function readFile(file: File): Promise<XLSX.WorkBook> {
  if (/\.(csv|tsv|txt)$/i.test(file.name)) {
    const textContent = await file.text();
    return XLSX.read(textContent, { type: "string", cellDates: true });
  }
  const buffer = await file.arrayBuffer();
  return XLSX.read(new Uint8Array(buffer), { type: "array", cellDates: true, cellNF: false });
}

export async function parseWorkbooks(files: File[]): Promise<ParseOutcome> {
  const allJobs: Job[] = [];
  const allDaily: ImportedRow[] = [];
  const reports: FileReport[] = [];
  const errors: string[] = [];
  const warnings: string[] = [];

  for (const file of files) {
    const report: FileReport = {
      name: file.name,
      sheets: [],
      jobRows: 0,
      dailyRows: 0,
      errors: [],
      warnings: [],
    };
    const dailyWarnings: string[] = [];
    try {
      if (file.size > 12_000_000) throw new Error("Larger than 12 MB — split the workbook by month.");
      const wb = await readFile(file);
      for (const sheetName of wb.SheetNames) {
        const ws = wb.Sheets[sheetName];
        if (!ws) continue;
        const rows = sheetRows(ws);
        if (rows.length < 2) {
          report.sheets.push({ name: sheetName, type: "skipped", rows: rows.length, note: "empty sheet" });
          continue;
        }
        const headerIdx = detectHeader(rows);
        if (headerIdx < 0) {
          report.sheets.push({ name: sheetName, type: "skipped", rows: rows.length, note: "no headers" });
          continue;
        }
        if (isJobSheet(rows, headerIdx)) {
          const jobs = parseJobSheet(rows, sheetName, file.name, report);
          allJobs.push(...jobs);
          report.jobRows += jobs.length;
          report.sheets.push({ name: sheetName, type: "job cards", rows: jobs.length });
        } else {
          const parsed = parseSheet(XLSX.utils.sheet_to_csv(ws));
          if (parsed.errors.length && parsed.rows.length === 0) {
            report.sheets.push({
              name: sheetName,
              type: "skipped",
              rows: 0,
              note: parsed.errors[0],
            });
            report.warnings.push(...parsed.errors.slice(0, 2));
          } else {
            allDaily.push(...parsed.rows);
            report.dailyRows += parsed.rows.length;
            report.sheets.push({ name: sheetName, type: "daily summary", rows: parsed.rows.length });
            dailyWarnings.push(...parsed.warnings);
          }
        }
      }
      if (!report.jobRows && !report.dailyRows) {
        report.errors.push("No job-card or daily-summary rows found in this workbook.");
      }
      if (report.jobRows > 0) {
        const missingTech = allJobs.filter((j) => j.technician === "Unassigned").length;
        if (missingTech > 0) {
          report.warnings.push(
            `${missingTech} job card${missingTech === 1 ? " has" : "s have"} no technician assigned.`
          );
        }
      } else {
        // these only matter when there is no job-card sheet to analyse
        report.warnings.push(...dailyWarnings);
      }
    } catch (err) {
      report.errors.push(err instanceof Error ? err.message : "Could not read this file.");
    }
    errors.push(...report.errors.map((e) => `${file.name}: ${e}`));
    warnings.push(...report.warnings.map((w) => `${file.name}: ${w}`));
    reports.push(report);
  }

  // deduplicate job cards across files/sheets, preferring a closed version
  const byJc = new Map<string, Job>();
  let duplicates = 0;
  for (const job of allJobs) {
    const key = job.jc.trim().toUpperCase();
    const prev = byJc.get(key);
    if (!prev) {
      byJc.set(key, job);
      continue;
    }
    duplicates++;
    if ((!prev.closed && job.closed) || (job.dateOut && !prev.dateOut)) byJc.set(key, job);
  }
  if (duplicates > 0) {
    warnings.push(`${duplicates} duplicate job card row${duplicates === 1 ? " was" : "s were"} merged (same JC number).`);
  }

  return {
    jobs: Array.from(byJc.values()).sort((a, b) => a.dateIn - b.dateIn),
    daily: mergeDaily(allDaily),
    files: reports,
    errors,
    warnings: Array.from(new Set(warnings)).slice(0, 12),
  };
}

/* ---------------------------- template --------------------------- */

export function buildTemplate(): SheetSpec[] {
  const today = new Date();
  const fmt = (d: Date) => {
    const p = (n: number) => String(n).padStart(2, "0");
    return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(10 + (d.getDate() % 8))}:${p(d.getMinutes())}`;
  };
  const day = (offset: number) => {
    const d = new Date(today);
    d.setDate(today.getDate() - offset);
    return d;
  };
  const jobHeaders = [
    "Job Card No", "Date In", "Date Out", "Status", "Warranty Type", "Service Type",
    "Device Model", "Technician", "TAT (hours)", "Amount (PKR)", "CSAT",
  ];
  const examples: (string | number)[][] = [
    ["JC-261014-001", fmt(day(3)), fmt(day(3)), "Closed", "In Warranty", "Battery", "Infinix Hot 50", "Ahmed Raza", 3.5, 0, 5],
    ["JC-261014-002", fmt(day(3)), fmt(day(2)), "Closed", "Out of Warranty", "Display", "Tecno Camon 30", "Sana Malik", 26.2, 14500, 4],
    ["JC-261015-001", fmt(day(2)), "", "Not Closed", "In Warranty", "Charging port", "itel A70", "Ayesha Noor", "", 0, ""],
    ["JC-261016-001", fmt(day(1)), fmt(day(1)), "Closed", "Out of Warranty", "Software", "Infinix Note 40", "Bilal Khan", 0.7, 2500, 5],
    ["JC-261017-001", fmt(day(0)), "", "In Progress", "In Warranty", "Board repair", "Tecno Spark 20", "Usman Tariq", "", 0, ""],
  ];
  return [
    { name: "Job Cards", rows: [jobHeaders, ...examples] },
    {
      name: "Daily Summary",
      rows: [
        ["Date", "Job Cards In", "Closed", "Pending", "Avg TAT (hours)", "SLA Met (%)", "CSAT", "Revenue (PKR)"],
        [fmt(day(2)).split(" ")[0], 38, 34, 4, 13.2, 86, 4.6, 268000],
        [fmt(day(1)).split(" ")[0], 41, 39, 2, 12.8, 88, 4.7, 291500],
        [fmt(day(0)).split(" ")[0], 36, 31, 5, 14.6, 82, 4.5, 244000],
      ],
    },
    {
      name: "Instructions",
      rows: [
        ["How to use this template"],
        ["Use either sheet. For job-level analysis (TAT, ≤1 hour closures, warranty contribution) fill the Job Cards sheet."],
        ["One row per job card. Date format: dd/mm/yyyy or yyyy-mm-dd. TAT is in hours (use 0.5 for 30 minutes)."],
        ["Status should say Closed / Delivered, or Not Closed / In Progress. Leave Date Out blank for open jobs."],
        ["Warranty Type: In Warranty or Out of Warranty."],
        ["You can import several daily files at once — duplicates with the same JC number are merged."],
      ],
    },
  ];
}
