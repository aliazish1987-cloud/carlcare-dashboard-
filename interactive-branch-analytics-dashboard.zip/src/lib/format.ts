const intFmt = new Intl.NumberFormat("en-US");
const compactFmt = new Intl.NumberFormat("en-US", {
  notation: "compact",
  maximumFractionDigits: 1,
});
const dShort = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" });
const dFull = new Intl.DateTimeFormat("en-US", {
  weekday: "short",
  month: "short",
  day: "numeric",
});
const dLong = new Intl.DateTimeFormat("en-US", {
  weekday: "long",
  month: "long",
  day: "numeric",
  year: "numeric",
});
const dTable = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  year: "numeric",
});

export const fmtInt = (n: number) => intFmt.format(Math.round(n));
export const fmtCompact = (n: number) => compactFmt.format(Math.round(n * 10) / 10);

/** Pakistani rupee amounts */
export const fmtRs = (n: number) => `Rs ${intFmt.format(Math.round(n))}`;
export const fmtRsCompact = (n: number) => {
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return `Rs ${(n / 1_000_000).toFixed(2)}M`;
  if (abs >= 10_000) return `Rs ${(n / 1000).toFixed(0)}k`;
  return `Rs ${intFmt.format(Math.round(n))}`;
};

export const fmtDateShort = (d: Date) => dShort.format(d);
export const fmtDateFull = (d: Date) => dFull.format(d);
export const fmtDateLong = (d: Date) => dLong.format(d);
export const fmtDateTable = (d: Date) => dTable.format(d);
export const fmtWeekday = (d: Date) => new Intl.DateTimeFormat("en-US", { weekday: "short" }).format(d);

export const fmtPct = (n: number, signed = true) =>
  `${signed && n >= 0 ? "+" : ""}${(n * 100).toFixed(1)}%`;
export const fmtShare = (n: number) => `${(n * 100).toFixed(1)}%`;
export const fmtHours = (n: number) => `${n.toFixed(1)}h`;
export const fmtScore = (n: number) => n.toFixed(2);

export const clamp = (v: number, a: number, b: number) =>
  Math.min(b, Math.max(a, v));
