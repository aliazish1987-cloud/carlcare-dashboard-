import {
  ArrowDownRight,
  ArrowUpRight,
  ClipboardList,
  Hourglass,
  Wallet,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import { fmtInt, fmtPct, fmtRsCompact, fmtShare } from "@/lib/format";
import type { MetricAvailability, Totals } from "@/lib/data";
import { cn } from "@/utils/cn";

interface Item {
  label: string;
  value: string;
  delta: number;
  icon: LucideIcon;
  color: string;
  downGood?: boolean;
  available: boolean;
}

export function OpsPulse({
  totals,
  deltas,
  metrics,
  compared = true,
}: {
  totals: Totals;
  deltas: Totals;
  metrics: MetricAvailability;
  compared?: boolean;
}) {
  const items: Item[] = [
    {
      label: "Job cards in",
      value: fmtInt(totals.received),
      delta: deltas.received,
      icon: ClipboardList,
      color: "var(--brand)",
      available: true,
    },
    {
      label: "Pending at close",
      value: fmtInt(totals.pending),
      delta: deltas.pending,
      icon: Hourglass,
      color: "var(--warn)",
      downGood: true,
      available: true,
    },
    {
      label: "First-time fix",
      value: metrics.ftfr ? fmtShare(totals.ftfr) : "—",
      delta: deltas.ftfr,
      icon: Wrench,
      color: "var(--chart-3)",
      available: metrics.ftfr,
    },
    {
      label: "Service revenue",
      value: metrics.revenue ? fmtRsCompact(totals.revenue) : "—",
      delta: deltas.revenue,
      icon: Wallet,
      color: "var(--up)",
      available: metrics.revenue,
    },
  ];

  return (
    <section
      className="anim-rise rounded-2xl border border-(--line) bg-(--surface) shadow-(--shadow-card)"
      style={{ animationDelay: "210ms" }}
    >
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 pt-4 sm:px-6">
        <div>
          <h2 className="text-[15px] font-semibold tracking-tight text-(--text)">Operations pulse</h2>
          <p className="mt-0.5 text-xs text-(--text-3)">Secondary KPIs for the selected period</p>
        </div>
        <span className="rounded-lg bg-(--surface-2) px-2.5 py-1 text-[11px] font-semibold text-(--text-3)">
          {compared ? "Current vs previous" : "No prior window"}
        </span>
      </div>
      <div className="mt-3 grid grid-cols-2 divide-x divide-y divide-(--line) border-t border-(--line) sm:grid-cols-4 sm:divide-y-0">
        {items.map((it) => {
          const good = it.downGood ? it.delta <= 0 : it.delta >= 0;
          const positive = it.delta >= 0;
          return (
            <div key={it.label} className="flex items-start gap-2.5 px-4 py-3.5 sm:px-5">
              <span
                className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg"
                style={{
                  color: it.available ? it.color : "var(--text-3)",
                  background: it.available
                    ? "color-mix(in srgb, currentColor 12%, transparent)"
                    : "var(--surface-2)",
                }}
              >
                <it.icon size={15} strokeWidth={2.2} />
              </span>
              <div className="min-w-0">
                <p className="truncate text-[11px] font-medium text-(--text-3)">{it.label}</p>
                <div className="mt-0.5 flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                  <span
                    className={cn(
                      "font-display text-lg font-bold tabular-nums leading-tight tracking-tight",
                      it.available ? "text-(--text)" : "text-(--text-3)"
                    )}
                  >
                    {it.value}
                  </span>
                  {it.available && compared && (
                    <span
                      className="inline-flex items-center gap-0.5 text-[10.5px] font-bold tabular-nums"
                      style={{ color: good ? "var(--up)" : "var(--down)" }}
                    >
                      {positive ? <ArrowUpRight size={11} strokeWidth={2.8} /> : <ArrowDownRight size={11} strokeWidth={2.8} />}
                      {fmtPct(Math.abs(it.delta), false)}
                    </span>
                  )}
                </div>
                {!it.available && <p className="mt-0.5 text-[10px] text-(--text-3)">not in imported sheet</p>}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
