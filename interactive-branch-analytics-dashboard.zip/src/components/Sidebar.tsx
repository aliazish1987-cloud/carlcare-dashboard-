import {
  BarChart3,
  CalendarDays,
  ChevronsUpDown,
  ClipboardList,
  FileSpreadsheet,
  FileText,
  Gauge,
  Hourglass,
  LineChart,
  ShieldCheck,
  Target,
  Timer,
  TriangleAlert,
  Users,
  Wrench,
  X,
  type LucideIcon,
} from "lucide-react";
import { fmtDateShort, fmtHours, fmtInt, fmtShare } from "@/lib/format";
import { SLA_HOURS, TODAY, type Totals, type View } from "@/lib/data";
import { cn } from "@/utils/cn";

interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  shortLabel?: string;
}

const NAV: NavItem[] = [
  { id: "overview", label: "Overview", icon: Gauge },
  { id: "throughput", label: "Job Card Throughput", icon: BarChart3 },
  { id: "tat", label: "TAT & SLA", icon: LineChart },
  { id: "team", label: "Technician Scorecard", icon: Users, shortLabel: "Closing Days" },
  { id: "log", label: "Closing Log", icon: ClipboardList },
];

const JOB_NAV: NavItem[] = [
  { id: "overview", label: "Overview", icon: Gauge },
  { id: "brief", label: "Daily Brief", icon: FileText },
  { id: "warranty", label: "Warranty & 1-Hour", icon: ShieldCheck },
  { id: "throughput", label: "Throughput", icon: BarChart3 },
  { id: "tat", label: "TAT & SLA", icon: LineChart },
  { id: "team", label: "Technicians", icon: Users },
  { id: "register", label: "Job Card Register", icon: ClipboardList },
  { id: "periods", label: "Period Reports", icon: CalendarDays },
];

const navFor = (jobMode: boolean) => (jobMode ? JOB_NAV : NAV);

const SLA_TARGET = 0.85;
const CLOSURE_TARGET = 0.9;

function GoalsPanel({ totals }: { totals: Totals }) {
  const closeRate = totals.received ? totals.closed / totals.received : 0;
  const goals = [
    {
      label: "SLA met",
      value: totals.closed > 0 ? fmtShare(totals.slaPct) : "—",
      target: "≥85%",
      ok: totals.closed > 0 && totals.slaPct >= SLA_TARGET,
      icon: ShieldCheck,
    },
    {
      label: "Avg TAT",
      value: totals.closed > 0 ? fmtHours(totals.avgTat) : "—",
      target: `≤${SLA_HOURS}h`,
      ok: totals.closed > 0 && totals.avgTat <= SLA_HOURS,
      icon: Timer,
    },
    {
      label: "Closure rate",
      value: fmtShare(closeRate),
      target: "≥90%",
      ok: closeRate >= CLOSURE_TARGET,
      icon: Target,
    },
  ];

  return (
    <div className="rounded-xl border border-(--line) bg-(--surface-2) p-3.5">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold text-(--text)">Targets vs goals</p>
        <span className="text-[10px] font-medium text-(--text-3)">selected period</span>
      </div>
      <ul className="mt-2.5 space-y-2">
        {goals.map((g) => (
          <li key={g.label} className="flex items-center gap-2">
            <g.icon
              size={13}
              className="shrink-0"
              style={{ color: g.ok ? "var(--up)" : "var(--warn)" }}
            />
            <span className="min-w-0 flex-1 truncate text-[11px] font-medium text-(--text-2)">{g.label}</span>
            <span
              className="text-[11px] font-bold tabular-nums"
              style={{ color: g.ok ? "var(--up)" : "var(--warn)" }}
            >
              {g.value}
            </span>
            <span className="w-10 text-right text-[10px] tabular-nums text-(--text-3)">{g.target}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SidebarBody({
  active,
  onSelect,
  summary,
  totals,
  imported,
  asOf,
  onImport,
  jobMode,
}: {
  active: string;
  onSelect: (id: string) => void;
  summary: View["today"];
  totals: Totals;
  imported: boolean;
  asOf?: Date;
  onImport: () => void;
  jobMode: boolean;
}) {
  const sla = Math.round(summary.slaPct * 100);
  const slaGood = summary.slaPct >= SLA_TARGET;

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 px-5 pb-4 pt-5">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-linear-to-br from-[#2563eb] to-[#0d9488] text-white shadow-lg shadow-blue-500/25">
          <Wrench size={18} strokeWidth={2.3} />
        </span>
        <div className="min-w-0">
          <p className="font-display text-[17px] font-bold leading-tight tracking-tight text-(--text)">
            Carlcare
          </p>
          <p className="truncate text-[11px] font-medium text-(--text-3)">Islamabad Service Center</p>
        </div>
      </div>

      <nav className="flex-1 space-y-4 overflow-y-auto px-3">
        <div>
          <p className="mb-1.5 px-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-(--text-3)">
            Dashboard
          </p>
          <ul className="space-y-0.5">
            {navFor(jobMode).map((item) => {
              const isActive = active === item.id;
              const label =
                jobMode && item.id === "team" && imported
                  ? "Technicians"
                  : item.id === "team" && imported && item.shortLabel
                    ? item.shortLabel
                    : item.label;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => onSelect(item.id)}
                    aria-current={isActive ? "page" : undefined}
                    className={cn(
                      "group relative flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] transition-colors duration-150",
                      isActive
                        ? "bg-(--brand-soft) font-semibold text-(--brand-strong)"
                        : "font-medium text-(--text-3) hover:bg-(--surface-2) hover:text-(--text-2)"
                    )}
                  >
                    {isActive && (
                      <span className="absolute left-0 top-1/2 h-4 w-[3px] -translate-y-1/2 rounded-full bg-(--brand)" />
                    )}
                    <item.icon size={16} strokeWidth={isActive ? 2.3 : 2} />
                    <span className="truncate">{label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>

        <GoalsPanel totals={totals} />

        <button
          type="button"
          onClick={onImport}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-(--line-strong) px-3 py-2 text-[11.5px] font-semibold text-(--text-2) transition-colors hover:border-(--brand) hover:text-(--brand-strong)"
        >
          <FileSpreadsheet size={13} />
          {imported ? "Replace daily sheet" : "Import daily sheet"}
        </button>
      </nav>

      <div className="p-3">
        <div className="rounded-xl border border-(--line) bg-(--surface-2) p-3.5">
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-semibold text-(--text)">
              {imported ? "Latest closing" : "Today's closing"}
            </p>
            <span className="inline-flex items-center gap-1 rounded-md bg-(--up-soft) px-1.5 py-0.5 text-[10px] font-bold text-(--up)">
              <span className="h-1 w-1 rounded-full bg-(--up)" />
              {fmtDateShort(asOf ?? TODAY)}
            </span>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2">
            <div className="rounded-lg bg-(--surface) px-2.5 py-2">
              <p className="text-[10px] font-medium text-(--text-3)">Jobs closed</p>
              <p className="font-display mt-0.5 text-[15px] font-bold tabular-nums text-(--text)">
                {fmtInt(summary.closed)}
                <span className="text-[11px] font-medium text-(--text-3)">/{fmtInt(summary.received)}</span>
              </p>
            </div>
            <div className="rounded-lg bg-(--surface) px-2.5 py-2">
              <p className="text-[10px] font-medium text-(--text-3)">SLA met</p>
              <p
                className="font-display mt-0.5 text-[15px] font-bold tabular-nums"
                style={{ color: slaGood ? "var(--up)" : "var(--warn)" }}
              >
                {sla}%
              </p>
            </div>
          </div>

          <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-(--surface-3)">
            <div
              className="progress-fill h-full rounded-full"
              style={{
                width: `${sla}%`,
                background: slaGood ? "linear-gradient(90deg, var(--up), var(--chart-2))" : "var(--warn)",
              }}
            />
          </div>

          <ul className="mt-3 space-y-1.5 text-[11px] font-medium text-(--text-2)">
            <li className="flex items-center gap-1.5">
              <ShieldCheck size={13} className="shrink-0 text-(--up)" />
              <span className="truncate">{summary.closed} job cards ready for delivery</span>
            </li>
            <li className="flex items-center gap-1.5">
              <Hourglass size={13} className="shrink-0" style={{ color: "var(--warn)" }} />
              <span className="truncate">{fmtInt(summary.pending)} pending at close</span>
            </li>
            <li className="flex items-center gap-1.5">
              <TriangleAlert
                size={13}
                className="shrink-0"
                style={{ color: summary.escalations ? "var(--down)" : "var(--text-3)" }}
              />
              <span className="truncate">
                {summary.escalations > 0
                  ? `${summary.escalations} escalated job card${summary.escalations > 1 ? "s" : ""}`
                  : "No escalations on this day"}
              </span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-(--line) p-3">
        <button
          type="button"
          onClick={() => onSelect("log")}
          className="flex w-full items-center gap-2.5 rounded-xl px-2 py-1.5 text-left transition-colors hover:bg-(--surface-2)"
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-(--brand-soft) text-[11px] font-bold text-(--brand-strong)">
            IS
          </span>
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[12px] font-semibold text-(--text)">Imran Shah</span>
            <span className="block truncate text-[10px] text-(--text-3)">Branch Supervisor</span>
          </span>
          <ChevronsUpDown size={14} className="text-(--text-3)" />
        </button>
      </div>
    </div>
  );
}

export function Sidebar({
  open,
  onClose,
  summary,
  totals,
  imported,
  asOf,
  onImport,
  activeSection,
  onNavigate,
  jobMode,
}: {
  open: boolean;
  onClose: () => void;
  summary: View["today"];
  totals: Totals;
  imported: boolean;
  asOf?: Date;
  onImport: () => void;
  activeSection: string;
  onNavigate: (id: string) => void;
  jobMode: boolean;
}) {
  const select = (id: string) => {
    onNavigate(id);
    onClose();
  };

  const shared = {
    active: activeSection,
    onSelect: select,
    summary,
    totals,
    imported,
    asOf,
    onImport,
    jobMode,
  };

  return (
    <>
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 border-r border-(--line) bg-(--surface) print:hidden lg:block">
        <SidebarBody {...shared} />
      </aside>

      <div className={cn("fixed inset-0 z-50 lg:hidden print:hidden", open ? "pointer-events-auto" : "pointer-events-none")}>
        <div
          className={cn(
            "absolute inset-0 bg-black/45 transition-opacity duration-300",
            open ? "opacity-100" : "opacity-0"
          )}
          onClick={onClose}
        />
        <aside
          className={cn(
            "absolute inset-y-0 left-0 w-64 border-r border-(--line) bg-(--surface) transition-transform duration-300 ease-out",
            open ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <button
            type="button"
            aria-label="Close menu"
            onClick={onClose}
            className="absolute right-3 top-3.5 z-10 flex h-8 w-8 items-center justify-center rounded-lg text-(--text-3) hover:bg-(--surface-2)"
          >
            <X size={16} />
          </button>
          <SidebarBody {...shared} />
        </aside>
      </div>
    </>
  );
}
