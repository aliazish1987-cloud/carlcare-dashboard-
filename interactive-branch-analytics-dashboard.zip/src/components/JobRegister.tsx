import { useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
  Download,
  Search,
  SearchX,
} from "lucide-react";
import type { Job } from "@/lib/jobs";
import { formatTat, FAST_TRACK_HOURS } from "@/lib/jobs";
import { downloadCsv, downloadWorkbook, jobRowsAoa, todayStamp } from "@/lib/export";
import { fmtDateTable, fmtInt, fmtRs } from "@/lib/format";
import { cn } from "@/utils/cn";

type StatusFilter = "all" | "closed" | "open" | "fast";
type SortKey = "dateIn" | "dateOut" | "tat" | "jc" | "warranty";

interface Props {
  jobs: Job[];
  asOf: number;
  days: number;
}

const WARRANTY_META = {
  in: { label: "In warranty", fg: "var(--chart-2)", bg: "color-mix(in srgb, var(--chart-2) 13%, transparent)" },
  out: { label: "Out warranty", fg: "var(--brand-strong)", bg: "var(--brand-soft)" },
  unknown: { label: "Not specified", fg: "var(--text-3)", bg: "var(--surface-2)" },
};

const STATUS_OPTIONS: { key: StatusFilter; label: string }[] = [
  { key: "all", label: "All cards" },
  { key: "closed", label: "Closed" },
  { key: "open", label: "Not closed" },
  { key: "fast", label: "Closed ≤1h" },
];

const PAGE_SIZES = [10, 25, 50, 100, -1];

export function JobRegister({ jobs, asOf, days }: Props) {
  const [status, setStatus] = useState<StatusFilter>("all");
  const [query, setQuery] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("dateIn");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let rows = jobs;
    if (status === "closed") rows = rows.filter((j) => j.closed);
    if (status === "open") rows = rows.filter((j) => !j.closed);
    if (status === "fast") {
      rows = rows.filter(
        (j) => j.closed && j.tatHours != null && (j.tatHours as number) <= FAST_TRACK_HOURS
      );
    }
    if (q) {
      rows = rows.filter((j) =>
        [j.jc, j.device, j.technician, j.service, j.source].join(" ").toLowerCase().includes(q)
      );
    }
    const dir = sortDir === "asc" ? 1 : -1;
    return [...rows].sort((a, b) => {
      if (sortKey === "jc") return a.jc.localeCompare(b.jc) * dir;
      if (sortKey === "warranty") return a.warranty.localeCompare(b.warranty) * dir;
      if (sortKey === "tat") return ((a.tatHours ?? 1e9) - (b.tatHours ?? 1e9)) * dir;
      if (sortKey === "dateOut") return ((a.dateOut ?? 0) - (b.dateOut ?? 0)) * dir;
      return (a.dateIn - b.dateIn) * dir;
    });
  }, [jobs, status, query, sortKey, sortDir]);

  const effectiveSize = pageSize === -1 ? Math.max(filtered.length, 1) : pageSize;
  const pageCount = Math.max(1, Math.ceil(filtered.length / effectiveSize));
  const curPage = Math.min(page, pageCount - 1);
  const rows = filtered.slice(curPage * effectiveSize, curPage * effectiveSize + effectiveSize);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir(key === "dateIn" ? "desc" : "asc");
    }
    setPage(0);
  };

  const rangeLabel = days === 0 ? "all-history" : `${days}d`;
  const fileBase = `carlcare-jobs-${status}-${rangeLabel}-${todayStamp()}`;

  const exportExcel = () => {
    downloadWorkbook(`${fileBase}.xlsx`, [{ name: "Job Cards", rows: jobRowsAoa(filtered) }]);
  };
  const exportCsv = () => {
    downloadCsv(`${fileBase}.csv`, jobRowsAoa(filtered));
  };

  const sortIcon = (key: SortKey) =>
    sortKey === key ? (
      sortDir === "asc" ? <ArrowUp size={12} strokeWidth={2.5} /> : <ArrowDown size={12} strokeWidth={2.5} />
    ) : (
      <ChevronsUpDown size={12} className="opacity-60" />
    );

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap items-center gap-1 rounded-xl border border-(--line) bg-(--surface-2) p-1">
          {STATUS_OPTIONS.map((s) => (
            <button
              key={s.key}
              type="button"
              onClick={() => {
                setStatus(s.key);
                setPage(0);
              }}
              className={cn(
                "h-7 rounded-lg px-2.5 text-[11.5px] font-semibold transition-all",
                status === s.key
                  ? "bg-(--surface) text-(--text) shadow-sm ring-1 ring-(--line)"
                  : "text-(--text-3) hover:text-(--text-2)"
              )}
            >
              {s.label}
              {s.key === "fast" ? "" : ""}
            </button>
          ))}
        </div>

        <div className="relative min-w-48 flex-1">
          <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-(--text-3)" />
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(0);
            }}
            placeholder="Search JC no, device, technician…"
            className="h-9 w-full rounded-lg border border-(--line) bg-(--surface-2) pl-8 pr-3 text-[12px] text-(--text) placeholder:text-(--text-3) focus:border-(--brand) focus:bg-(--surface)"
          />
        </div>

        <button
          type="button"
          onClick={exportExcel}
          className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-(--line) bg-(--surface) px-2.5 text-[11.5px] font-semibold text-(--text-2) transition-colors hover:border-(--brand) hover:text-(--brand-strong)"
        >
          <Download size={13} /> Excel
        </button>
        <button
          type="button"
          onClick={exportCsv}
          className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-(--line) bg-(--surface) px-2.5 text-[11.5px] font-semibold text-(--text-2) transition-colors hover:border-(--brand) hover:text-(--brand-strong)"
        >
          <Download size={13} /> CSV
        </button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-(--line)">
        <table className="w-full min-w-[1040px] border-collapse text-[12.5px]">
          <thead>
            <tr className="bg-(--surface-2) text-left">
              {[
                { key: "jc" as SortKey, label: "Job card" },
                { key: null, label: "Device / service" },
                { key: "dateIn" as SortKey, label: "Date in" },
                { key: "dateOut" as SortKey, label: "Date out" },
                { key: "tat" as SortKey, label: "Repair time" },
                { key: "warranty" as SortKey, label: "Warranty" },
                { key: null, label: "Technician" },
                { key: null, label: "Status" },
              ].map((c) => (
                <th key={c.label} className="whitespace-nowrap px-3 py-2.5 first:pl-4 last:pr-4">
                  {c.key ? (
                    <button
                      type="button"
                      onClick={() => toggleSort(c.key as SortKey)}
                      className={cn(
                        "inline-flex items-center gap-1 text-[10.5px] font-bold uppercase tracking-wider",
                        sortKey === c.key ? "text-(--brand-strong)" : "text-(--text-3) hover:text-(--text-2)"
                      )}
                    >
                      {c.label}
                      {sortIcon(c.key)}
                    </button>
                  ) : (
                    <span className="text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">{c.label}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((j) => {
              const wm = WARRANTY_META[j.warranty];
              const fast = j.closed && j.tatHours != null && j.tatHours <= FAST_TRACK_HOURS;
              const ageDays = !j.closed ? Math.max(0, (asOf - j.dateIn) / 86400000) : 0;
              return (
                <tr key={j.id} className="border-t border-(--line) transition-colors hover:bg-(--surface-2)">
                  <td className="whitespace-nowrap px-3 py-2.5 pl-4">
                    <div className="font-mono text-[11.5px] font-semibold text-(--text)">{j.jc}</div>
                    <div className="mt-0.5 max-w-36 truncate text-[10px] text-(--text-3)">{j.source}</div>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="max-w-44 truncate font-medium text-(--text)">{j.device}</div>
                    <div className="mt-0.5 text-[10.5px] text-(--text-3)">{j.service}</div>
                  </td>
                  <td className="whitespace-nowrap px-3 py-2.5 tabular-nums text-(--text-2)">{fmtDateTable(new Date(j.dateIn))}</td>
                  <td className="whitespace-nowrap px-3 py-2.5 tabular-nums text-(--text-2)">
                    {j.dateOut ? fmtDateTable(new Date(j.dateOut)) : <span className="text-(--text-3)">—</span>}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2.5">
                    <span
                      className="font-semibold tabular-nums"
                      style={{ color: j.tatHours == null ? "var(--text-3)" : j.tatHours <= 1 ? "var(--up)" : j.tatHours > 48 ? "var(--down)" : "var(--text)" }}
                    >
                      {formatTat(j.tatHours)}
                    </span>
                    {fast && (
                      <span className="ml-1.5 rounded bg-(--up-soft) px-1 py-0.5 text-[9.5px] font-bold text-(--up)">≤1h</span>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2.5">
                    <span
                      className="inline-flex rounded-full px-2 py-1 text-[10.5px] font-semibold"
                      style={{ color: wm.fg, background: wm.bg }}
                    >
                      {wm.label}
                    </span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="block max-w-32 truncate text-(--text-2)">{j.technician}</span>
                  </td>
                  <td className="whitespace-nowrap px-3 py-2.5 pr-4">
                    {j.closed ? (
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-(--up-soft) px-2 py-1 text-[10.5px] font-semibold text-(--up)">
                        <span className="h-1.5 w-1.5 rounded-full bg-(--up)" /> Closed
                      </span>
                    ) : (
                      <>
                        <span className="inline-flex items-center gap-1.5 rounded-full bg-(--warn-soft) px-2 py-1 text-[10.5px] font-semibold text-(--warn)">
                          <span className="h-1.5 w-1.5 rounded-full bg-(--warn)" /> Not closed
                        </span>
                        <div className="mt-0.5 text-[10px] text-(--text-3)">{ageDays.toFixed(1)} days old</div>
                      </>
                    )}
                  </td>
                </tr>
              );
            })}
            {rows.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-14 text-center">
                  <SearchX size={26} className="mx-auto mb-2.5 text-(--text-3)" />
                  <p className="text-sm font-medium text-(--text-2)">No job cards match this view</p>
                  <p className="mt-1 text-xs text-(--text-3)">Try another status, or clear the search.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex flex-wrap items-center gap-2.5 text-[11px] text-(--text-3)">
          <span className="tabular-nums">
            Showing <span className="font-semibold text-(--text-2)">{filtered.length === 0 ? 0 : curPage * effectiveSize + 1}–{Math.min(filtered.length, curPage * effectiveSize + effectiveSize)}</span> of{" "}
            <span className="font-semibold text-(--text-2)">{fmtInt(filtered.length)}</span> cards
          </span>
          <label className="flex items-center gap-1.5">
            Rows
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(0);
              }}
              className="h-7 rounded-lg border border-(--line) bg-(--surface) px-1.5 text-[11px] font-semibold text-(--text-2)"
            >
              {PAGE_SIZES.map((n) => (
                <option key={n} value={n}>{n === -1 ? "All" : n}</option>
              ))}
            </select>
          </label>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label="Previous page"
            disabled={curPage === 0}
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            className="flex h-7 w-7 items-center justify-center rounded-lg border border-(--line) text-(--text-2) disabled:opacity-40"
          >
            <ChevronLeft size={14} />
          </button>
          <span className="px-1 text-[11px] tabular-nums text-(--text-3)">
            {curPage + 1} / {pageCount}
          </span>
          <button
            type="button"
            aria-label="Next page"
            disabled={curPage >= pageCount - 1}
            onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
            className="flex h-7 w-7 items-center justify-center rounded-lg border border-(--line) text-(--text-2) disabled:opacity-40"
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>
      {filtered.some((j) => j.closed && j.tatHours == null) && (
        <p className="mt-2 text-[10px] text-(--text-3)">
          Some closed cards have no Date Out or TAT in the sheet, so their repair time shows “—”. Add a TAT or Date Out column to include them.
        </p>
      )}
      <p className="mt-1 text-[10px] text-(--text-3)">
        Total out-of-warranty revenue in these {fmtInt(filtered.length)} cards:{" "}
        {fmtRs(filtered.filter((j) => j.warranty === "out" && j.closed).reduce((a, j) => a + j.revenue, 0))}
      </p>
    </div>
  );
}
