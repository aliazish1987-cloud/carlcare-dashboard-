import { ArrowDownRight, ArrowUpRight, CircleAlert, ShieldCheck, Trophy } from "lucide-react";
import { SLA_HOURS, type View } from "@/lib/data";
import { fmtDateShort, fmtHours, fmtInt, fmtPct, fmtShare } from "@/lib/format";

const SLA_TARGET = 0.85;

export function InsightsBar({ view, imported = false }: { view: View; imported?: boolean }) {
  const bestTech = [...view.ranks]
    .filter((r) => r.closed > 0)
    .sort((a, b) => b.slaPct - a.slaPct || b.closed - a.closed)[0];
  const slowestSvc = [...view.serviceStats]
    .filter((s) => s.closed > 0)
    .sort((a, b) => b.avgTat - a.avgTat)[0];
  const topDay = [...view.logs].filter((l) => l.closed > 0).sort((a, b) => b.closed - a.closed)[0];
  const slowDay = [...view.logs].filter((l) => l.closed > 0).sort((a, b) => b.avgTat - a.avgTat)[0];

  const slaGood = view.totals.slaPct >= SLA_TARGET;
  const slaUp = view.deltas.slaPct >= 0;

  return (
    <section
      className="anim-rise grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-(--line) bg-(--line) sm:grid-cols-3"
      style={{ animationDelay: "235ms" }}
    >
      <div className="flex items-start gap-3 bg-(--surface) px-4 py-3.5">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg"
          style={{
            color: slaGood ? "var(--up)" : "var(--warn)",
            background: slaGood ? "var(--up-soft)" : "var(--warn-soft)",
          }}
        >
          <ShieldCheck size={16} strokeWidth={2.2} />
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-medium text-(--text-3)">SLA health vs 85% goal</p>
          <p
            className="font-display mt-0.5 text-[15px] font-bold tabular-nums"
            style={{ color: slaGood ? "var(--up)" : "var(--warn)" }}
          >
            {fmtShare(view.totals.slaPct)} met
            <span
              className="ml-1.5 inline-flex items-center gap-0.5 align-middle text-[11px] font-bold"
              style={{ color: slaUp ? "var(--up)" : "var(--down)" }}
            >
              {slaUp ? <ArrowUpRight size={11} /> : <ArrowDownRight size={11} />}
              {fmtPct(Math.abs(view.deltas.slaPct), false)}
            </span>
          </p>
          <p className="mt-0.5 truncate text-[11px] text-(--text-3)">
            {slaGood
              ? "Above target — hold the standard"
              : `Gap of ${((SLA_TARGET - view.totals.slaPct) * 100).toFixed(1)}pp to target`}
          </p>
        </div>
      </div>

      <div className="flex items-start gap-3 bg-(--surface) px-4 py-3.5">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-(--chart-4)"
          style={{ background: "color-mix(in srgb, currentColor 12%, transparent)" }}
        >
          <Trophy size={16} strokeWidth={2.2} />
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-medium text-(--text-3)">
            {imported ? "Best closing day by volume" : "Top performer by SLA"}
          </p>
          <p className="font-display mt-0.5 truncate text-[15px] font-bold text-(--text)">
            {imported
              ? topDay
                ? `${fmtDateShort(topDay.date)} · ${fmtInt(topDay.closed)} closed`
                : "No closing days"
              : bestTech
                ? bestTech.tech.name
                : "No closed jobs yet"}
          </p>
          <p className="mt-0.5 truncate text-[11px] text-(--text-3)">
            {imported
              ? topDay
                ? `${fmtShare(topDay.slaPct)} SLA · ${fmtHours(topDay.avgTat)} TAT · ${fmtInt(topDay.pending)} pending`
                : "Adjust the range to see results"
              : bestTech
                ? `${fmtShare(bestTech.slaPct)} SLA · ${fmtHours(bestTech.avgTat)} avg TAT · ${bestTech.closed} closed`
                : "Adjust filters to see technician data"}
          </p>
        </div>
      </div>

      <div className="flex items-start gap-3 bg-(--surface) px-4 py-3.5">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-(--warn)"
          style={{ background: "var(--warn-soft)" }}
        >
          <CircleAlert size={16} strokeWidth={2.2} />
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-medium text-(--text-3)">TAT watch</p>
          <p className="font-display mt-0.5 truncate text-[15px] font-bold text-(--text)">
            {imported
              ? slowDay
                ? `${fmtDateShort(slowDay.date)} · ${fmtHours(slowDay.avgTat)}`
                : "No closed jobs"
              : slowestSvc
                ? `${slowestSvc.label} · ${fmtHours(slowestSvc.avgTat)}`
                : "No repairs closed"}
          </p>
          <p className="mt-0.5 truncate text-[11px] text-(--text-3)">
            {imported
              ? slowDay
                ? `${slowDay.slaPct >= 0.85 ? "Within" : "Below"} SLA at ${fmtShare(slowDay.slaPct)} · ${slowDay.pending} pending`
                : "Widen the date range"
              : slowestSvc
                ? `${slowestSvc.slaPct >= 0.85 ? "Within" : "Below"} SLA at ${fmtShare(slowestSvc.slaPct)} · ${slowestNote(slowestSvc.avgTat)}`
                : "Pending job cards have no TAT yet"}
          </p>
        </div>
      </div>
    </section>
  );
}

const slowestNote = (tat: number) =>
  tat > SLA_HOURS ? `${(tat - SLA_HOURS).toFixed(1)}h over target` : `${(SLA_HOURS - tat).toFixed(1)}h under target`;
