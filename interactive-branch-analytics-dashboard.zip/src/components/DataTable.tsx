import { useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
  Download,
  Printer,
  Search,
  SearchX,
  Star,
} from "lucide-react";
import { Select } from "@/components/ui/Select";
import {
  DAY_STATUS_META,
  SLA_HOURS,
  type DailyRow,
  type DayStatus,
  type MetricAvailability,
} from "@/lib/data";
import { fmtDateFull, fmtDateTable, fmtHours, fmtInt, fmtRs, fmtShare, fmtScore, fmtWeekday } from "@/lib/format";
import { cn } from "@/utils/cn";

type SortKey =
  | "date"
  | "received"
  | "closed"
  | "pending"
  | "avgTat"
  | "slaPct"
  | "ftfr"
  | "csat"
  | "revenue"
  | "status";

interface Col {
  key: SortKey;
  label: string;
  numeric?: boolean;
}

const COLS: Col[] = [
  { key: "date", label: "Date" },
  { key: "received", label: "Job Cards", numeric: true },
  { key: "closed", label: "Closed", numeric: true },
  { key: "pending", label: "Pending", numeric: true },
  { key: "avgTat", label: "Avg TAT", numeric: true },
  { key: "slaPct", label: "SLA Met", numeric: true },
  { key: "ftfr", label: "FTFR", numeric: true },
  { key: "csat", label: "CSAT", numeric: true },
  { key: "revenue", label: "Revenue", numeric: true },
  { key: "status", label: "Closing Status" },
];

const PAGE_SIZES = [10, 25, 50, 100];
const ALL_ROWS = -1;
const STATUS_ORDER: Record<DayStatus, number> = { "on-track": 0, review: 1, variance: 2 };

const ALL_METRICS: MetricAvailability = { csat: true, ftfr: true, revenue: true, escalations: true };

export function DataTable({
  logs,
  days,
  available = ALL_METRICS,
}: {
  logs: DailyRow[];
  days: number;
  available?: MetricAvailability;
}) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [sortKey, setSortKey] = useState<SortKey>("date");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(10);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let rows = logs;
    if (status !== "all") rows = rows.filter((r) => r.status === status);
    if (q) {
      rows = rows.filter((r) => {
        const haystack = `${fmtDateTable(r.date)} ${fmtDateFull(r.date)} ${DAY_STATUS_META[r.status].label}`.toLowerCase();
        return haystack.includes(q);
      });
    }
    const dir = sortDir === "asc" ? 1 : -1;
    const val = (r: DailyRow): number | string => {
      switch (sortKey) {
        case "date": return r.ts;
        case "received": return r.received;
        case "closed": return r.closed;
        case "pending": return r.pending;
        case "avgTat": return r.avgTat;
        case "slaPct": return r.slaPct;
        case "ftfr": return r.ftfr;
        case "csat": return r.csat;
        case "revenue": return r.revenue;
        case "status": return STATUS_ORDER[r.status];
      }
    };
    return [...rows].sort((a, b) => {
      const va = val(a);
      const vb = val(b);
      if (typeof va === "string") return va.localeCompare(vb as string) * dir;
      return ((va as number) - (vb as number)) * dir;
    });
  }, [logs, query, status, sortKey, sortDir]);

  const effectiveSize = pageSize === ALL_ROWS ? Math.max(filtered.length, 1) : pageSize;
  const pageCount = Math.max(1, Math.ceil(filtered.length / effectiveSize));
  const curPage = Math.min(page, pageCount - 1);
  const pageRows = filtered.slice(curPage * effectiveSize, curPage * effectiveSize + effectiveSize);

  const toggleSort = (key: SortKey) => {
    setPage(0);
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir(key === "date" ? "desc" : "asc");
    }
  };

  const exportCsv = () => {
    const header = [
      "Date", "Weekday", "Job Cards In", "Closed", "Pending", "Escalations",
      "Avg TAT (h)", "SLA Met %", "FTFR %", "CSAT", "Revenue (PKR)", "Status",
    ];
    const lines = filtered.map((r) => [
      fmtDateTable(r.date),
      fmtWeekday(r.date),
      r.received,
      r.closed,
      r.pending,
      available.escalations ? r.escalations : "",
      r.avgTat.toFixed(1),
      (r.slaPct * 100).toFixed(1),
      available.ftfr ? (r.ftfr * 100).toFixed(1) : "",
      available.csat ? r.csat.toFixed(2) : "",
      available.revenue ? Math.round(r.revenue) : "",
      DAY_STATUS_META[r.status].label,
    ].join(","));
    const blob = new Blob([[header.join(","), ...lines].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `carlcare-islamabad-closing-${days}d.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const from = filtered.length === 0 ? 0 : curPage * effectiveSize + 1;
  const to = Math.min(filtered.length, curPage * effectiveSize + effectiveSize);

  const printReport = () => {
    const previous = pageSize;
    setPageSize(ALL_ROWS);
    setPage(0);
    // let React paint every row before the browser builds the print layout
    window.setTimeout(() => {
      window.print();
      setPageSize(previous);
    }, 150);
  };
  const slaColor = (pct: number) =>
    pct >= 0.85 ? "var(--up)" : pct >= 0.7 ? "var(--warn)" : "var(--down)";

  return (
    <div>
      {/* toolbar */}
      <div className="mb-4 flex flex-wrap items-center gap-2.5 print:hidden">
        <div className="relative min-w-52 flex-1">
          <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-(--text-3)" />
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(0);
            }}
            placeholder="Search date or closing status…"
            className={cn(
              "h-10 w-full rounded-xl border border-(--line) bg-(--surface-2) pl-9 pr-3 text-sm text-(--text)",
              "placeholder:text-(--text-3) transition-colors duration-200 focus:border-(--brand) focus:bg-(--surface)"
            )}
          />
        </div>
        <Select
          value={status}
          onChange={(v) => {
            setStatus(v);
            setPage(0);
          }}
          options={[
            { value: "all", label: "All statuses" },
            { value: "on-track", label: "On track" },
            { value: "review", label: "Review" },
            { value: "variance", label: "Variance" },
          ]}
          className="w-40"
        />
        <button
          type="button"
          onClick={exportCsv}
          className="inline-flex h-10 items-center gap-2 rounded-xl border border-(--line) bg-(--surface) px-3.5 text-sm font-medium text-(--text-2) transition-colors duration-200 hover:border-(--line-strong) hover:text-(--text)"
        >
          <Download size={15} />
          <span className="hidden sm:inline">Export CSV</span>
        </button>
        <button
          type="button"
          onClick={printReport}
          title="Print every filtered row, or save as PDF for your supervisor report"
          className="inline-flex h-10 items-center gap-2 rounded-xl border border-(--line) bg-(--surface) px-3.5 text-sm font-medium text-(--text-2) transition-colors duration-200 hover:border-(--line-strong) hover:text-(--text)"
        >
          <Printer size={15} />
          <span className="hidden sm:inline">Print</span>
        </button>
      </div>

      {(!available.ftfr || !available.csat || !available.revenue) && (
        <p className="-mt-1 mb-3 text-[11px] text-(--text-3)">
          Your sheet doesn’t include{" "}
          {[
            !available.ftfr && "first-time fix",
            !available.csat && "CSAT",
            !available.revenue && "revenue",
          ]
            .filter(Boolean)
            .join(", ")}
          , so those cells show “—”. Add the column and re-import to populate them.
        </p>
      )}

      {/* table */}
      <div className="overflow-x-auto rounded-xl border border-(--line)">
        <table className="w-full min-w-[1060px] border-collapse text-sm">
          <thead>
            <tr className="bg-(--surface-2)">
              {COLS.map((c) => (
                <th key={c.key} className={cn("px-3 py-2.5 first:pl-4 last:pr-4", c.numeric && "text-right")}>
                  <button
                    type="button"
                    onClick={() => toggleSort(c.key)}
                    className={cn(
                      "inline-flex items-center gap-1 whitespace-nowrap text-[11px] font-semibold uppercase tracking-wider transition-colors duration-150",
                      sortKey === c.key ? "text-(--brand-strong)" : "text-(--text-3) hover:text-(--text-2)",
                      c.numeric && "flex-row-reverse"
                    )}
                  >
                    {c.label}
                    {sortKey === c.key ? (
                      sortDir === "asc" ? <ArrowUp size={12} strokeWidth={2.5} /> : <ArrowDown size={12} strokeWidth={2.5} />
                    ) : (
                      <ChevronsUpDown size={12} className="opacity-60" />
                    )}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((r) => {
              const meta = DAY_STATUS_META[r.status];
              return (
                <tr key={r.ts} className="border-t border-(--line) transition-colors duration-100 hover:bg-(--surface-2)">
                  <td className="whitespace-nowrap px-3 py-3 pl-4">
                    <div className="text-[13px] font-semibold text-(--text)">{fmtDateTable(r.date)}</div>
                    <div className="mt-0.5 text-[11px] text-(--text-3)">{fmtWeekday(r.date)} · daily close</div>
                  </td>
                  <td className="px-3 py-3 text-right text-[13px] font-semibold tabular-nums text-(--text)">{fmtInt(r.received)}</td>
                  <td className="px-3 py-3 text-right text-[13px] tabular-nums text-(--text-2)">{fmtInt(r.closed)}</td>
                  <td className="px-3 py-3 text-right">
                    <div
                      className="text-[13px] font-semibold tabular-nums"
                      style={{ color: r.pending > r.received * 0.22 ? "var(--warn)" : "var(--text-2)" }}
                    >
                      {fmtInt(r.pending)}
                    </div>
                    {available.escalations && r.escalations > 0 && (
                      <div className="text-[10px] font-semibold text-(--down)">{r.escalations} escalated</div>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-3 py-3 text-right">
                    <span
                      className="text-[13px] font-semibold tabular-nums"
                      style={{ color: r.avgTat > SLA_HOURS ? "var(--down)" : "var(--text-2)" }}
                    >
                      {fmtHours(r.avgTat)}
                    </span>
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <span className="hidden h-1.5 w-10 overflow-hidden rounded-full bg-(--surface-3) xl:block">
                        <span
                          className="block h-full rounded-full"
                          style={{ width: `${r.slaPct * 100}%`, background: slaColor(r.slaPct) }}
                        />
                      </span>
                      <span
                        className="w-12 text-right text-[12px] font-semibold tabular-nums"
                        style={{ color: slaColor(r.slaPct) }}
                      >
                        {fmtShare(r.slaPct)}
                      </span>
                    </div>
                  </td>
                  <td className="px-3 py-3 text-right text-[13px] tabular-nums text-(--text-2)">
                    {available.ftfr ? fmtShare(r.ftfr) : "—"}
                  </td>
                  <td className="whitespace-nowrap px-3 py-3 text-right">
                    {available.csat && r.csat > 0 ? (
                      <span className="inline-flex items-center justify-end gap-1 text-[13px] font-semibold tabular-nums text-(--text)">
                        <Star size={11} className="fill-current text-(--chart-4)" />
                        {fmtScore(r.csat)}
                      </span>
                    ) : (
                      <span className="text-[13px] text-(--text-3)">—</span>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-3 py-3 text-right text-[13px] font-semibold tabular-nums text-(--text)">
                    {available.revenue && r.revenue > 0 ? fmtRs(r.revenue) : <span className="text-(--text-3)">—</span>}
                  </td>
                  <td className="px-3 py-3 pr-4">
                    <span
                      title="On track: SLA ≥76% and pending ≤26%. Review: SLA <76%, pending >26% or 4+ escalations. Variance: SLA <68% or 5+ escalations."
                      className="inline-flex cursor-help items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-semibold"
                      style={{ color: meta.fg, background: meta.bg }}
                    >
                      <span className="h-1.5 w-1.5 rounded-full" style={{ background: meta.dot }} />
                      {meta.label}
                    </span>
                  </td>
                </tr>
              );
            })}
            {pageRows.length === 0 && (
              <tr>
                <td colSpan={COLS.length} className="px-4 py-14 text-center">
                  <SearchX size={28} className="mx-auto mb-3 text-(--text-3)" />
                  <p className="text-sm font-medium text-(--text-2)">No closing days match your search</p>
                  <p className="mt-1 text-xs text-(--text-3)">Try a different date or clear the status filter.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* footer */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div className="flex flex-wrap items-center gap-2.5">
          <p className="text-xs tabular-nums text-(--text-3)">
            Showing <span className="font-semibold text-(--text-2)">{from}–{to}</span> of{" "}
            <span className="font-semibold text-(--text-2)">{fmtInt(filtered.length)}</span> closing days
          </p>
          <label className="flex items-center gap-1.5 text-[11px] text-(--text-3)">
            Rows
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(0);
              }}
              className="h-8 rounded-lg border border-(--line) bg-(--surface) px-1.5 text-[11px] font-semibold text-(--text-2)"
            >
              {PAGE_SIZES.map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
              <option value={ALL_ROWS}>All</option>
            </select>
          </label>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label="Previous page"
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            disabled={curPage === 0}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-(--line) text-(--text-2) transition-colors duration-150 hover:bg-(--surface-2) disabled:opacity-40"
          >
            <ChevronLeft size={15} />
          </button>
          {Array.from({ length: Math.min(pageCount, 7) }).map((_, i) => {
            const idx = pageCount <= 7 ? i : Math.min(Math.max(curPage - 3, 0), pageCount - 7) + i;
            return (
              <button
                key={idx}
                type="button"
                onClick={() => setPage(idx)}
                className={cn(
                  "h-8 w-8 rounded-lg text-[13px] font-semibold tabular-nums transition-colors duration-150",
                  idx === curPage ? "bg-(--brand) text-white" : "text-(--text-2) hover:bg-(--surface-2)"
                )}
              >
                {idx + 1}
              </button>
            );
          })}
          <button
            type="button"
            aria-label="Next page"
            onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
            disabled={curPage >= pageCount - 1}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-(--line) text-(--text-2) transition-colors duration-150 hover:bg-(--surface-2) disabled:opacity-40"
          >
            <ChevronRight size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}
