import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

interface CardProps {
  title?: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
  delay?: number;
  id?: string;
}

export function Card({
  title,
  subtitle,
  action,
  children,
  className,
  bodyClassName,
  delay = 0,
  id,
}: CardProps) {
  return (
    <section
      id={id}
      className={cn(
        "anim-rise scroll-mt-24 rounded-2xl border border-(--line) bg-(--surface) shadow-(--shadow-card) print:break-inside-avoid",
        className
      )}
      style={{ animationDelay: `${delay}ms` }}
    >
      {(title || action) && (
        <header className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2 px-5 pt-4 pb-1 sm:px-6 sm:pt-5">
          <div className="min-w-0 flex-1">
            {title && (
              <h2 className="text-[15px] font-semibold tracking-tight text-(--text)">
                {title}
              </h2>
            )}
            {subtitle && (
              <p className="mt-0.5 truncate text-xs text-(--text-3)">{subtitle}</p>
            )}
          </div>
          {action && <div className="flex flex-wrap items-center gap-2">{action}</div>}
        </header>
      )}
      <div className={cn("px-5 pb-5 pt-3 sm:px-6", bodyClassName)}>{children}</div>
    </section>
  );
}
