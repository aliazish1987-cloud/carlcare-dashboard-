import { useEffect, useRef, useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import { cn } from "@/utils/cn";

export interface SelectOption {
  value: string;
  label: string;
  hint?: string;
}

interface SelectProps {
  value: string;
  onChange: (value: string) => void;
  options: SelectOption[];
  label?: string;
  icon?: React.ReactNode;
  className?: string;
  disabled?: boolean;
  disabledHint?: string;
}

export function Select({ value, onChange, options, label, icon, className, disabled, disabledHint }: SelectProps) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const selected = options.find((o) => o.value === value) ?? options[0];

  return (
    <div ref={rootRef} className={cn("relative", className)}>
      {label && (
        <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wider text-(--text-3)">
          {label}
        </span>
      )}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        disabled={disabled}
        title={disabled ? disabledHint : undefined}
        className={cn(
          "flex h-10 w-full items-center gap-2 rounded-xl border border-(--line) bg-(--surface) px-3 text-sm font-medium text-(--text)",
          "transition-colors duration-200 hover:border-(--line-strong) hover:bg-(--surface-2)",
          open && "border-(--brand)",
          disabled && "cursor-not-allowed opacity-55 hover:border-(--line) hover:bg-(--surface)"
        )}
      >
        {icon && <span className="text-(--text-3)">{icon}</span>}
        <span className="min-w-0 flex-1 truncate text-left">{selected.label}</span>
        <ChevronDown
          size={16}
          className={cn("shrink-0 text-(--text-3) transition-transform duration-200", open && "rotate-180")}
        />
      </button>

      {open && (
        <div
          role="listbox"
          className="anim-pop absolute z-50 mt-2 max-h-72 w-full min-w-52 overflow-auto rounded-xl border border-(--line) bg-(--surface) p-1.5 shadow-xl shadow-black/10"
        >
          {options.map((o) => {
            const active = o.value === value;
            return (
              <button
                key={o.value}
                role="option"
                aria-selected={active}
                onClick={() => {
                  onChange(o.value);
                  setOpen(false);
                }}
                className={cn(
                  "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-sm transition-colors duration-150",
                  active
                    ? "bg-(--brand-soft) font-semibold text-(--brand-strong)"
                    : "text-(--text-2) hover:bg-(--surface-2)"
                )}
              >
                <span className="min-w-0 flex-1">
                  <span className="block truncate">{o.label}</span>
                  {o.hint && (
                    <span className="block truncate text-[11px] font-normal text-(--text-3)">
                      {o.hint}
                    </span>
                  )}
                </span>
                {active && <Check size={15} className="shrink-0" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
