import type { ReactNode } from "react";
import { cn } from "@/utils/cn";

export interface SegmentedOption {
  value: string;
  label: string;
  icon?: ReactNode;
}

interface SegmentedProps {
  value: string;
  onChange: (value: string) => void;
  options: SegmentedOption[];
  label?: string;
  size?: "sm" | "md";
}

export function Segmented({ value, onChange, options, label, size = "md" }: SegmentedProps) {
  return (
    <div>
      {label && (
        <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-wider text-(--text-3)">
          {label}
        </span>
      )}
      <div className="inline-flex items-center gap-1 rounded-xl border border-(--line) bg-(--surface-2) p-1">
        {options.map((o) => {
          const active = o.value === value;
          return (
            <button
              key={o.value}
              type="button"
              onClick={() => onChange(o.value)}
              className={cn(
                "flex items-center gap-1.5 rounded-lg font-medium transition-all duration-200",
                size === "sm" ? "h-7 px-2.5 text-xs" : "h-8 px-3 text-[13px]",
                active
                  ? "bg-(--surface) text-(--text) shadow-sm ring-1 ring-(--line)"
                  : "text-(--text-3) hover:text-(--text-2)"
              )}
            >
              {o.icon}
              {o.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
