import { CalendarCheck, Star } from "lucide-react";
import { DAY_STATUS_META, type DailyRow } from "@/lib/data";
import { fmtDateTable, fmtHours, fmtShare, fmtScore } from "@/lib/format";

/** Fallback for imported sheets without technician columns. */
export function DayHighlights({ logs }: { logs: DailyRow[] }) {
  const recent = [...logs].sort((a, b) => b.ts - a.ts).slice(0, 6);

  if (recent.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-10 text-center">
        <CalendarCheck size={26} className="mb-2 text-(--text-3)" />
        <p className="text-[13px] font-medium text-(--text-2)">No closing days in this range</p>
        <p className="mt-1 max-w-56 text-[11px] text-(--text-3)">
          The imported sheet has no rows inside the selected range. Widen the range to see results.
        </p>
      </div>
    );
  }

  return (
    <ul className="space-y-0.5">
      {recent.map((r) => {
        const meta = DAY_STATUS_META[r.status];
        return (
          <li
            key={r.ts}
            className="flex items-center gap-3 rounded-xl px-2 py-2 transition-colors duration-150 hover:bg-(--surface-2)"
          >
            <span
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[10px] font-bold"
              style={{ color: "var(--brand-strong)", background: "var(--brand-soft)" }}
            >
              {r.date.getDate()}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="truncate text-[12.5px] font-semibold text-(--text)">{fmtDateTable(r.date)}</span>
                <span className="shrink-0 text-[11px] font-semibold tabular-nums text-(--text-2)">
                  {r.closed} closed
                </span>
              </div>
              <div className="mt-1 flex items-center gap-2 text-[10.5px] text-(--text-3)">
                <span className="tabular-nums">{fmtHours(r.avgTat)} TAT</span>
                <span className="h-1 w-1 rounded-full bg-(--line-strong)" />
                <span className="tabular-nums">{fmtShare(r.slaPct)} SLA</span>
                {r.csat > 0 && (
                  <>
                    <span className="h-1 w-1 rounded-full bg-(--line-strong)" />
                    <span className="inline-flex items-center gap-0.5 tabular-nums">
                      <Star size={9} className="fill-current text-(--chart-4)" />
                      {fmtScore(r.csat)}
                    </span>
                  </>
                )}
                <span className="ml-auto inline-flex items-center gap-1 font-semibold" style={{ color: meta.fg }}>
                  <span className="h-1.5 w-1.5 rounded-full" style={{ background: meta.dot }} />
                  {meta.label}
                </span>
              </div>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
