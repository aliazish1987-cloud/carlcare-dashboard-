import { useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  ClipboardPaste,
  Download,
  FileSpreadsheet,
  Loader2,
  RefreshCw,
  Trash2,
  TriangleAlert,
  UploadCloud,
  Wand2,
  X,
} from "lucide-react";
import { buildTemplate, parseWorkbooks, type ParseOutcome } from "@/lib/excelImport";
import { parseSheet, type ImportedDataset } from "@/lib/import";
import { makeDemoJobDataset, type JobDataset } from "@/lib/jobs";
import { downloadWorkbook } from "@/lib/export";
import { fmtDateShort, fmtInt, fmtRs, fmtShare } from "@/lib/format";
import { cn } from "@/utils/cn";

interface Props {
  open: boolean;
  onClose: () => void;
  onApplyJobs: (dataset: JobDataset) => void;
  onApplyDaily: (dataset: ImportedDataset) => void;
  onLoadDemo: (dataset: JobDataset) => void;
  currentLabel: string | null;
  onRestoreSample: () => void;
}

export function ImportDialog({
  open,
  onClose,
  onApplyJobs,
  onApplyDaily,
  onLoadDemo,
  currentLabel,
  onRestoreSample,
}: Props) {
  const [files, setFiles] = useState<File[]>([]);
  const [outcome, setOutcome] = useState<ParseOutcome | null>(null);
  const [busy, setBusy] = useState(false);
  const [pasteMode, setPasteMode] = useState(false);
  const [pasteText, setPasteText] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    setFiles([]);
    setOutcome(null);
    setBusy(false);
    setPasteMode(false);
    setPasteText("");
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && !busy && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, busy, onClose]);

  const analyze = async (next: File[]) => {
    setBusy(true);
    try {
      const parsed = await parseWorkbooks(next);
      setOutcome(parsed);
    } catch {
      setOutcome({
        jobs: [],
        daily: [],
        files: [],
        errors: ["The files could not be read. Please try re-saving them as .xlsx."],
        warnings: [],
      });
    } finally {
      setBusy(false);
    }
  };

  const addFiles = (incoming: FileList | null) => {
    if (!incoming) return;
    const next = [...files, ...Array.from(incoming)].filter(
      (f, i, arr) => arr.findIndex((x) => x.name === f.name && x.size === f.size) === i
    );
    setFiles(next);
    void analyze(next);
  };

  const removeFile = (name: string) => {
    const next = files.filter((f) => f.name !== name);
    setFiles(next);
    if (next.length) void analyze(next);
    else setOutcome(null);
  };

  const pasteParsed = useMemo(
    () => (pasteText.trim() ? parseSheet(pasteText) : null),
    [pasteText]
  );

  if (!open) return null;

  const jobCount = outcome?.jobs.length ?? 0;
  const dailyCount = outcome?.daily.length ?? 0;
  const range =
    outcome && jobCount
      ? {
          from: new Date(Math.min(...outcome.jobs.map((j) => j.dateIn))),
          to: new Date(Math.max(...outcome.jobs.map((j) => j.dateIn))),
        }
      : null;
  const warrantyCounts =
    outcome && jobCount
      ? {
          in: outcome.jobs.filter((j) => j.warranty === "in").length,
          out: outcome.jobs.filter((j) => j.warranty === "out").length,
          closed: outcome.jobs.filter((j) => j.closed).length,
        }
      : null;

  const apply = () => {
    if (jobCount > 0 && outcome) {
      onApplyJobs({
        kind: "jobs",
        name: files.map((f) => f.name).join(", ").slice(0, 90) || "Uploaded workbooks",
        importedAt: Date.now(),
        files: files.map((f) => f.name),
        jobs: outcome.jobs,
      });
      onClose();
      return;
    }
    const rows = outcome?.daily.length ? outcome.daily : pasteParsed?.rows ?? [];
    if (rows.length) {
      onApplyDaily({
        name: files.map((f) => f.name).join(", ") || `Pasted closing sheet · ${rows.length} days`,
        importedAt: Date.now(),
        rows,
        mapped: [],
      });
      onClose();
    }
  };

  const canApply = jobCount > 0 || dailyCount > 0 || (pasteParsed?.rows.length ?? 0) > 0;

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center p-0 sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px]" onClick={() => !busy && onClose()} />
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Import day-end workbooks"
        className="anim-pop relative flex max-h-[94vh] w-full max-w-3xl flex-col overflow-hidden rounded-t-2xl border border-(--line) bg-(--surface) shadow-2xl sm:rounded-2xl"
      >
        <div className="flex items-start justify-between gap-4 border-b border-(--line) px-5 py-4 sm:px-6">
          <div>
            <h2 className="font-display text-lg font-bold tracking-tight text-(--text)">
              Upload daily day-end workbooks
            </h2>
            <p className="mt-0.5 text-xs text-(--text-3)">
              Excel (.xlsx/.xls) or CSV. Upload as many daily files as you have — duplicates are merged.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close import dialog"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-(--text-3) hover:bg-(--surface-2) hover:text-(--text)"
          >
            <X size={17} />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4 sm:px-6">
          {currentLabel && (
            <div className="flex flex-wrap items-center gap-2 rounded-xl border border-(--line) bg-(--surface-2) px-3 py-2.5">
              <FileSpreadsheet size={15} className="text-(--brand-strong)" />
              <p className="min-w-0 flex-1 truncate text-xs text-(--text-2)">
                Currently using <span className="font-semibold text-(--text)">{currentLabel}</span>
              </p>
              <button
                type="button"
                onClick={() => {
                  onRestoreSample();
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-(--line) bg-(--surface) px-2.5 py-1.5 text-[11px] font-semibold text-(--text-2) hover:text-(--text)"
              >
                <RefreshCw size={12} /> Restore sample
              </button>
            </div>
          )}

          <div
            onDragOver={(e) => {
              e.preventDefault();
            }}
            onDrop={(e) => {
              e.preventDefault();
              addFiles(e.dataTransfer.files);
            }}
            onClick={() => inputRef.current?.click()}
            className="flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-(--line-strong) bg-(--surface-2) px-4 py-6 text-center transition-colors hover:border-(--brand)"
          >
            {busy ? (
              <Loader2 size={22} className="animate-spin text-(--brand-strong)" />
            ) : (
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-(--brand-soft) text-(--brand-strong)">
                <UploadCloud size={21} />
              </span>
            )}
            <p className="mt-2 text-sm font-semibold text-(--text)">
              {busy ? "Reading workbooks…" : "Drop Excel files here, or click to browse"}
            </p>
            <p className="mt-0.5 text-[11px] text-(--text-3)">
              Multiple files supported · .xlsx · .xls · .csv · up to 12 MB each · analysed in your browser
            </p>
            <input
              ref={inputRef}
              type="file"
              multiple
              accept=".xlsx,.xls,.csv,.tsv,.txt"
              className="hidden"
              onChange={(e) => {
                addFiles(e.target.files);
                e.target.value = "";
              }}
            />
          </div>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-[11.5px]">
            <button
              type="button"
              onClick={() => downloadWorkbook("carlcare-day-end-template.xlsx", buildTemplate())}
              className="inline-flex items-center gap-1.5 font-semibold text-(--brand-strong) hover:underline"
            >
              <Download size={13} /> Download Excel template
            </button>
            <button
              type="button"
              onClick={() => {
                onLoadDemo(makeDemoJobDataset());
                onClose();
              }}
              className="inline-flex items-center gap-1.5 font-medium text-(--text-2) hover:text-(--text)"
            >
              <Wand2 size={13} /> Load 95-day demo workbooks
            </button>
            <button
              type="button"
              onClick={() => setPasteMode((v) => !v)}
              className="inline-flex items-center gap-1.5 font-medium text-(--text-2) hover:text-(--text)"
            >
              <ClipboardPaste size={13} /> {pasteMode ? "Hide paste box" : "Paste a daily summary from Excel"}
            </button>
          </div>

          {files.length > 0 && (
            <ul className="space-y-1.5">
              {files.map((f) => {
                const report = outcome?.files.find((r) => r.name === f.name);
                const rows = report ? report.jobRows + report.dailyRows : 0;
                const failed = report && report.errors.length > 0 && rows === 0;
                return (
                  <li key={f.name} className="flex items-center gap-2 rounded-lg border border-(--line) px-2.5 py-2">
                    <FileSpreadsheet size={14} className={failed ? "text-(--down)" : "text-(--brand-strong)"} />
                    <span className="min-w-0 flex-1 truncate text-[12px] font-medium text-(--text)">{f.name}</span>
                    <span className="shrink-0 text-[10.5px] text-(--text-3)">
                      {report
                        ? `${fmtInt(report.jobRows)} job cards · ${fmtInt(report.dailyRows)} daily rows`
                        : "queued"}
                    </span>
                    <button
                      type="button"
                      onClick={() => removeFile(f.name)}
                      aria-label={`Remove ${f.name}`}
                      className="flex h-6 w-6 items-center justify-center rounded text-(--text-3) hover:bg-(--surface-2) hover:text-(--down)"
                    >
                      <Trash2 size={12} />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}

          {pasteMode && (
            <div>
              <textarea
                value={pasteText}
                onChange={(e) => setPasteText(e.target.value)}
                rows={4}
                placeholder={"Date,Job Cards In,Closed,Pending,Avg TAT,SLA Met (%),CSAT,Revenue\n2026-10-16,52,46,6,14.2,84,4.6,318000"}
                className="w-full resize-y rounded-xl border border-(--line) bg-(--surface) p-3 font-mono text-[11px] text-(--text) placeholder:text-(--text-3) focus:border-(--brand)"
              />
              {pasteParsed && (
                <p className="mt-1 text-[11px] text-(--text-3)">
                  {pasteParsed.rows.length} daily rows detected
                  {pasteParsed.errors.length ? ` · ${pasteParsed.errors[0]}` : ""}
                </p>
              )}
            </div>
          )}

          {outcome && (
            <div className="space-y-3">
              {jobCount > 0 && (
                <>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 rounded-lg bg-(--up-soft) px-2 py-1 text-[11px] font-bold text-(--up)">
                      <Check size={12} strokeWidth={3} /> {fmtInt(jobCount)} unique job cards
                    </span>
                    {range && (
                      <span className="rounded-lg bg-(--surface-2) px-2 py-1 text-[11px] font-semibold text-(--text-2)">
                        {fmtDateShort(range.from)} – {fmtDateShort(range.to)}
                      </span>
                    )}
                    {warrantyCounts && (
                      <>
                        <span className="rounded-lg bg-(--surface-2) px-2 py-1 text-[11px] text-(--text-2)">
                          Closed {fmtInt(warrantyCounts.closed)} ({fmtShare(warrantyCounts.closed / jobCount)})
                        </span>
                        <span className="rounded-lg bg-(--surface-2) px-2 py-1 text-[11px] text-(--text-2)">
                          In warranty {fmtShare(warrantyCounts.in / jobCount)}
                        </span>
                        <span className="rounded-lg bg-(--surface-2) px-2 py-1 text-[11px] text-(--text-2)">
                          Out of warranty {fmtShare(warrantyCounts.out / jobCount)}
                        </span>
                      </>
                    )}
                  </div>

                  <div className="overflow-x-auto rounded-lg border border-(--line)">
                    <table className="w-full min-w-[620px] text-[11.5px]">
                      <thead>
                        <tr className="bg-(--surface-2) text-left text-[10.5px] uppercase tracking-wide text-(--text-3)">
                          <th className="px-2.5 py-1.5 font-bold">Job card</th>
                          <th className="px-2.5 py-1.5 font-bold">Date in</th>
                          <th className="px-2.5 py-1.5 font-bold">Date out</th>
                          <th className="px-2.5 py-1.5 font-bold">TAT</th>
                          <th className="px-2.5 py-1.5 font-bold">Warranty</th>
                          <th className="px-2.5 py-1.5 font-bold">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {outcome.jobs.slice(0, 4).map((j) => (
                          <tr key={j.id} className="border-t border-(--line) text-(--text-2)">
                            <td className="px-2.5 py-1.5 font-mono text-[10.5px] text-(--text)">{j.jc}</td>
                            <td className="px-2.5 py-1.5">{fmtDateShort(new Date(j.dateIn))}</td>
                            <td className="px-2.5 py-1.5">{j.dateOut ? fmtDateShort(new Date(j.dateOut)) : "—"}</td>
                            <td className="px-2.5 py-1.5 tabular-nums">{j.tatHours != null ? `${j.tatHours.toFixed(1)}h` : "—"}</td>
                            <td className="px-2.5 py-1.5">{j.warranty === "in" ? "In" : j.warranty === "out" ? "Out" : "—"}</td>
                            <td className="px-2.5 py-1.5">{j.closed ? "Closed" : "Open"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {outcome.files.map((r) => (
                      <span key={r.name} className="rounded-md border border-(--line) px-2 py-1 text-[10px] text-(--text-3)">
                        {r.sheets.map((s) => `${s.name}: ${s.type}`).join(" · ")}
                      </span>
                    ))}
                  </div>
                </>
              )}

              {jobCount === 0 && dailyCount > 0 && (
                <p className="rounded-lg bg-(--up-soft) px-3 py-2 text-[11px] font-medium text-(--up)">
                  {fmtInt(dailyCount)} daily summary rows detected. Job-level reports (≤1h closures, warranty mix) need a
                  Job Cards sheet — see the template.
                </p>
              )}

              {outcome.errors.length > 0 && (
                <div className="rounded-lg bg-(--down-soft) px-3 py-2">
                  <p className="text-[11px] font-bold text-(--down)">Some files could not be imported</p>
                  <ul className="mt-1 space-y-0.5 text-[11px] text-(--down)">
                    {outcome.errors.slice(0, 5).map((e, i) => (
                      <li key={i}>• {e}</li>
                    ))}
                  </ul>
                </div>
              )}
              {outcome.warnings.length > 0 && (
                <div className="rounded-lg bg-(--warn-soft) px-3 py-2">
                  <p className="flex items-center gap-1 text-[11px] font-bold text-(--warn)">
                    <TriangleAlert size={12} /> Notes
                  </p>
                  <ul className="mt-1 space-y-0.5 text-[11px] text-(--warn)">
                    {outcome.warnings.slice(0, 6).map((w, i) => (
                      <li key={i}>• {w}</li>
                    ))}
                  </ul>
                </div>
              )}
              {jobCount > 0 && (
                <p className="text-[10.5px] leading-relaxed text-(--text-3)">
                  Recognised fields are mapped automatically (JC no, Date In/Out, Status, Warranty, Service, Device,
                  Technician, TAT, Amount, CSAT). Cards missing a JC number are kept with a row reference. Amount total:{" "}
                  {fmtRs(outcome.jobs.reduce((a, j) => a + j.revenue, 0))}.
                </p>
              )}
            </div>
          )}

          <p className={cn("text-[10.5px] leading-relaxed text-(--text-3)")}>
            For the full analysis, include a <strong className="text-(--text-2)">Job Cards</strong> sheet with one row per
            job card: JC number, Date In, Date Out, Status, Warranty Type, Service, Device, Technician. A{" "}
            <strong className="text-(--text-2)">Daily Summary</strong> sheet is optional. Your files never leave this
            browser.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-end gap-2 border-t border-(--line) bg-(--surface) px-5 py-3 sm:px-6">
          <button
            type="button"
            onClick={onClose}
            className="h-9 rounded-xl border border-(--line) px-3.5 text-[13px] font-medium text-(--text-2) hover:bg-(--surface-2)"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={apply}
            disabled={!canApply || busy}
            className="inline-flex h-9 items-center gap-2 rounded-xl bg-(--brand) px-4 text-[13px] font-semibold text-white transition-all hover:bg-(--brand-strong) disabled:opacity-45"
          >
            <FileSpreadsheet size={14} />
            {jobCount > 0
              ? `Analyse ${fmtInt(jobCount)} job cards`
              : dailyCount > 0
                ? `Load ${dailyCount} daily rows`
                : (pasteParsed?.rows.length ?? 0) > 0
                  ? `Load ${pasteParsed?.rows.length} pasted rows`
                  : "Load into dashboard"}
          </button>
        </div>
      </div>
    </div>
  );
}
