import { useMemo, useRef, useState } from "react";
import { useMeasure } from "@/hooks/hooks";
import { fmtDateFull, fmtDateShort, fmtCompact, fmtInt, clamp } from "@/lib/format";
import type { DailyPoint } from "@/lib/data";

const M = { t: 14, r: 8, b: 26, l: 36 };

export function VolumeChart({ data, height = 250 }: { data: DailyPoint[]; height?: number }) {
  const [wrapRef, { width }] = useMeasure<HTMLDivElement>();
  const svgRef = useRef<SVGSVGElement>(null);
  const [hover, setHover] = useState<number | null>(null);

  const W = Math.max(width, 260);
  const innerW = W - M.l - M.r;
  const innerH = height - M.t - M.b;

  const { yMax, colW, barW } = useMemo(() => {
    const maxV = Math.max(1, ...data.map((d) => Math.max(d.received, d.closed)));
    const exp = Math.floor(Math.log10(maxV));
    const f = maxV / Math.pow(10, exp);
    const nice = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10;
    const yMax = nice * Math.pow(10, exp) * 1.05;
    const colW = data.length ? innerW / data.length : innerW;
    const barW = Math.max(2.5, Math.min(15, (colW * 0.72) / 2));
    return { yMax, colW, barW };
  }, [data, innerW]);

  const ticks = [0.25, 0.5, 0.75, 1].map((f) => yMax * f);
  const labelEvery = Math.max(1, Math.ceil(data.length / 6));
  const hov = hover !== null ? data[hover] : null;
  const hovX = hover !== null ? M.l + colW * hover + colW / 2 : 0;
  const tipX = hov ? clamp(hovX, 100, W - 100) : 0;

  const onMove = (e: React.PointerEvent) => {
    if (!svgRef.current || data.length === 0) return;
    const rect = svgRef.current.getBoundingClientRect();
    const idx = clamp(Math.floor((e.clientX - rect.left - M.l) / colW), 0, data.length - 1);
    setHover(idx);
  };

  return (
    <div
      ref={wrapRef}
      className="relative w-full"
      style={{ height }}
      role="img"
      aria-label="Grouped daily bars of job cards received and closed; exact figures are listed in the closing log"
    >
      <svg
        ref={svgRef}
        width={W}
        height={height}
        className="block overflow-visible"
        onPointerMove={onMove}
        onPointerLeave={() => setHover(null)}
      >
        {ticks.map((t, i) => {
          const gy = M.t + innerH - (t / yMax) * innerH;
          return (
            <g key={i}>
              <line x1={M.l} x2={W - M.r} y1={gy} y2={gy} stroke="var(--line)" strokeDasharray="3 5" />
              <text x={M.l - 8} y={gy + 4} textAnchor="end" fontSize={10.5} fill="var(--text-3)" fontWeight={500}>
                {fmtCompact(t)}
              </text>
            </g>
          );
        })}
        <line x1={M.l} x2={W - M.r} y1={M.t + innerH} y2={M.t + innerH} stroke="var(--line)" />

        {data.map((d, i) => {
          const groupLeft = M.l + colW * i;
          const gap = 2;
          const receivedX = groupLeft + (colW - (barW * 2 + gap)) / 2;
          const closedX = receivedX + barW + gap;
          const hReceived = (d.received / yMax) * innerH;
          const hClosed = (d.closed / yMax) * innerH;
          const hoverOn = hover === i;
          return (
            <g key={i}>
              {hoverOn && (
                <rect
                  x={groupLeft + 1}
                  y={M.t}
                  width={Math.max(colW - 2, 1)}
                  height={innerH}
                  rx={4}
                  fill="var(--surface-2)"
                  opacity={0.9}
                />
              )}
              <rect
                x={receivedX}
                y={M.t + innerH - hReceived}
                width={barW}
                height={Math.max(hReceived, 0)}
                rx={Math.min(3, barW / 2.4)}
                fill="var(--brand)"
                opacity={hoverOn ? 1 : 0.9}
                className="bar-grow"
                style={{ animationDelay: `${Math.min(i * 10, 380) + 80}ms` }}
              />
              <rect
                x={closedX}
                y={M.t + innerH - hClosed}
                width={barW}
                height={Math.max(hClosed, 0)}
                rx={Math.min(3, barW / 2.4)}
                fill="var(--chart-2)"
                opacity={hoverOn ? 1 : 0.9}
                className="bar-grow"
                style={{ animationDelay: `${Math.min(i * 10, 380) + 130}ms` }}
              />
            </g>
          );
        })}

        {data.map((d, i) =>
          i % labelEvery === 0 && i < data.length - labelEvery / 2 ? (
            <text
              key={i}
              x={M.l + colW * i + colW / 2}
              y={height - 6}
              textAnchor="middle"
              fontSize={10.5}
              fill="var(--text-3)"
              fontWeight={500}
            >
              {fmtDateShort(d.date)}
            </text>
          ) : null
        )}
      </svg>

      <div
        className="chart-tip absolute top-1 z-10 w-52 rounded-xl border border-(--line) bg-(--surface) p-3 shadow-xl shadow-black/10"
        style={{
          left: tipX - 104,
          opacity: hov ? 1 : 0,
          transform: hov ? "translateY(0)" : "translateY(4px)",
        }}
      >
        {hov && (
          <>
            <div className="mb-2 flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-(--text)">{fmtDateFull(hov.date)}</span>
              <span className="rounded-md bg-(--surface-2) px-1.5 py-0.5 text-[10px] font-semibold text-(--text-3)">
                jobs
              </span>
            </div>
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-(--text-2)">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--brand)" }} />
                  Received
                </span>
                <span className="font-semibold tabular-nums text-(--text)">{fmtInt(hov.received)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-(--text-2)">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--chart-2)" }} />
                  Closed
                </span>
                <span className="font-semibold tabular-nums text-(--text)">{fmtInt(hov.closed)}</span>
              </div>
              <div className="flex items-center justify-between border-t border-(--line) pt-1.5">
                <span className="text-(--text-2)">Pending at close</span>
                <span
                  className="font-semibold tabular-nums"
                  style={{ color: hov.pending > 0 ? "var(--warn)" : "var(--up)" }}
                >
                  {fmtInt(hov.pending)}
                </span>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
