import { useMemo, useState } from "react";
import { useEntrance } from "@/hooks/hooks";
import { fmtInt, fmtShare } from "@/lib/format";
import type { MixSeg } from "@/lib/data";
import { cn } from "@/utils/cn";

const R = 72;
const C = 2 * Math.PI * R;

export function MixDonut({ segments }: { segments: MixSeg[] }) {
  const p = useEntrance(800);
  const [hover, setHover] = useState<string | null>(null);

  const total = useMemo(() => segments.reduce((a, s) => a + s.value, 0) || 1, [segments]);

  const arcs = useMemo(() => {
    let acc = 0;
    return segments.map((s) => {
      const share = s.value / total;
      const start = acc;
      acc += share;
      return { ...s, share, start };
    });
  }, [segments, total]);

  const active = arcs.find((a) => a.key === hover) ?? null;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        <svg width={184} height={184} viewBox="0 0 184 184" className="-rotate-90">
          <circle cx={92} cy={92} r={R} fill="none" stroke="var(--surface-3)" strokeWidth={22} />
          {arcs.map((a) => {
            if (a.share <= 0) return null;
            const len = Math.max(0, a.share * C * p - 2.5);
            const isHover = hover === a.key;
            return (
              <circle
                key={a.key}
                cx={92}
                cy={92}
                r={R}
                fill="none"
                stroke={a.color}
                strokeWidth={isHover ? 30 : 22}
                strokeDasharray={`${len} ${Math.max(0, C - len)}`}
                strokeDashoffset={-a.start * C * p}
                strokeLinecap="butt"
                style={{
                  transition: "stroke-width 0.25s ease, opacity 0.25s ease",
                  opacity: hover === null || isHover ? 1 : 0.33,
                  cursor: "pointer",
                }}
                onMouseEnter={() => setHover(a.key)}
                onMouseLeave={() => setHover(null)}
              />
            );
          })}
        </svg>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="max-w-28 text-[10px] font-semibold uppercase leading-tight tracking-widest text-(--text-3)">
            {active ? active.label : "Total job cards"}
          </span>
          <span className="font-display mt-1 text-[26px] font-bold leading-none tabular-nums tracking-tight text-(--text)">
            {fmtInt(active ? active.value : total)}
          </span>
          <span
            className="mt-1.5 rounded-full px-2 py-0.5 text-[11px] font-semibold"
            style={{
              color: active ? active.color : "var(--text-2)",
              background: active ? "color-mix(in srgb, currentColor 12%, transparent)" : "var(--surface-2)",
            }}
          >
            {active ? fmtShare(active.share) : "in period"}
          </span>
        </div>
      </div>

      <ul className="w-full space-y-0.5">
        {arcs.map((a) => (
          <li key={a.key}>
            <button
              type="button"
              onMouseEnter={() => setHover(a.key)}
              onMouseLeave={() => setHover(null)}
              className={cn(
                "flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-sm transition-colors duration-150",
                hover === a.key ? "bg-(--surface-2)" : "opacity-90"
              )}
            >
              <span className="h-2.5 w-2.5 shrink-0 rounded-[4px]" style={{ background: a.color }} />
              <span className="min-w-0 flex-1 truncate text-left text-[13px] font-medium text-(--text-2)">
                {a.label}
              </span>
              <span className="text-[13px] font-semibold tabular-nums text-(--text)">{fmtInt(a.value)}</span>
              <span className="w-11 text-right text-xs tabular-nums text-(--text-3)">{fmtShare(a.share)}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
