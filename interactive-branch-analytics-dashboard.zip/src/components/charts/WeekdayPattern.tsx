import { useState } from "react";
import { SLA_HOURS, type WeekdayStat } from "@/lib/data";
import { fmtInt, fmtHours, fmtShare } from "@/lib/format";

/** Compact staffing pattern: average TAT and SLA by day of week. */
export function WeekdayPattern({ data }: { data: WeekdayStat[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const active = data.filter((d) => d.days > 0 && d.received > 0);
  if (active.length === 0) return null;

  const max = Math.max(...active.map((d) => d.avgTat), 1);
  const current = hover !== null ? data[hover] : null;
  const slowest = [...active].sort((a, b) => b.avgTat - a.avgTat)[0];

  return (
    <div className="mt-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <p className="text-[10px] font-semibold uppercase tracking-wider text-(--text-3)">TAT by weekday</p>
        <p className="text-[10px] text-(--text-3)">
          {current
            ? `${current.label} · ${fmtInt(current.received)} in · ${fmtHours(current.avgTat)} · ${fmtShare(current.slaPct)} SLA`
            : `Slowest day: ${slowest.label} at ${fmtHours(slowest.avgTat)}`}
        </p>
      </div>
      <div className="mt-2 flex items-end gap-1.5" role="img" aria-label="Average turnaround time by weekday; details available in the closing log">
        {data.map((d) => {
          const hasData = d.days > 0 && d.received > 0;
          const over = d.avgTat > SLA_HOURS;
          const isHover = hover === d.dow;
          return (
            <button
              key={d.dow}
              type="button"
              disabled={!hasData}
              onMouseEnter={() => setHover(d.dow)}
              onFocus={() => setHover(d.dow)}
              onMouseLeave={() => setHover(null)}
              onBlur={() => setHover(null)}
              aria-label={`${d.label}: average TAT ${fmtHours(d.avgTat)}, ${fmtShare(d.slaPct)} SLA`}
              className="group relative flex flex-1 flex-col items-center gap-1.5 rounded-md pb-0.5 disabled:opacity-35"
            >
              <span className="flex h-12 w-full items-end justify-center">
                <span
                  className="w-full max-w-7 rounded-t-[3px] transition-all duration-200"
                  style={{
                    height: hasData ? `${Math.max(8, (d.avgTat / max) * 44)}px` : "3px",
                    background: !hasData
                      ? "var(--surface-3)"
                      : over
                        ? `color-mix(in srgb, var(--down) ${isHover ? 100 : 72}%, var(--surface))`
                        : `color-mix(in srgb, var(--brand) ${isHover ? 100 : 65}%, var(--surface))`,
                  }}
                />
              </span>
              <span
                className="text-[10px] font-semibold transition-colors"
                style={{ color: isHover ? "var(--text)" : "var(--text-3)" }}
              >
                {d.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
