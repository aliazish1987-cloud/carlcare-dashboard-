import { useId, useMemo } from "react";

interface SparklineProps {
  data: number[];
  color?: string;
  width?: number;
  height?: number;
}

export function Sparkline({ data, color = "var(--brand)", width = 120, height = 36 }: SparklineProps) {
  const gid = useId().replace(/[:]/g, "");

  const { line, area } = useMemo(() => {
    if (data.length < 2) return { line: "", area: "" };
    const min = Math.min(...data);
    const max = Math.max(...data);
    const span = max - min || 1;
    const pad = 3;
    const x = (i: number) => pad + (i / (data.length - 1)) * (width - pad * 2);
    const y = (v: number) => pad + (1 - (v - min) / span) * (height - pad * 2);
    const pts = data.map((v, i) => ({ x: x(i), y: y(v) }));
    let d = `M ${pts[0].x.toFixed(1)} ${pts[0].y.toFixed(1)}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i];
      const p1 = pts[i];
      const p2 = pts[i + 1];
      const p3 = pts[i + 2] || p2;
      d += ` C ${(p1.x + (p2.x - p0.x) / 6).toFixed(1)} ${(p1.y + (p2.y - p0.y) / 6).toFixed(1)}, ${(p2.x - (p3.x - p1.x) / 6).toFixed(1)} ${(p2.y - (p3.y - p1.y) / 6).toFixed(1)}, ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
    }
    return { line: d, area: `${d} L ${pts[pts.length - 1].x} ${height} L ${pts[0].x} ${height} Z` };
  }, [data, width, height]);

  return (
    <svg width={width} height={height} className="block" aria-hidden>
      <defs>
        <linearGradient id={`sp-${gid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22" />
          <stop offset="100%" stopColor={color} stopOpacity="0.01" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#sp-${gid})`} className="anim-fade" style={{ animationDelay: "350ms" }} />
      <path
        d={line}
        fill="none"
        stroke={color}
        strokeWidth={1.8}
        strokeLinecap="round"
        pathLength={1}
        className="chart-line"
        style={{ animationDelay: "150ms", animationDuration: "900ms" }}
      />
    </svg>
  );
}
