import { useId, useMemo, useRef, useState } from "react";
import { useMeasure } from "@/hooks/hooks";
import { smoothPath, type Pt } from "@/lib/chart";
import { fmtDateFull, fmtDateShort, fmtHours, fmtInt, fmtShare, clamp } from "@/lib/format";
import { SLA_HOURS, type DailyPoint } from "@/lib/data";

const M = { t: 16, r: 40, b: 26, l: 38 };

export function TatChart({ data, height = 250 }: { data: DailyPoint[]; height?: number }) {
  const gid = useId().replace(/[:]/g, "");
  const [wrapRef, { width }] = useMeasure<HTMLDivElement>();
  const svgRef = useRef<SVGSVGElement>(null);
  const [hover, setHover] = useState<number | null>(null);

  const W = Math.max(width, 280);
  const innerW = W - M.l - M.r;
  const innerH = height - M.t - M.b;

  const { yMax, ticks, tatPts, slaPts, tatLine, slaLine, tatArea } = useMemo(() => {
    if (data.length === 0) {
      return {
        yMax: 36,
        ticks: [0, 12, 24, 36],
        tatPts: [] as Pt[],
        slaPts: [] as Pt[],
        tatLine: "",
        slaLine: "",
        tatArea: "",
      };
    }
    const maxAvg = Math.max(1, ...data.map((d) => d.avgTat));
    const yMax = Math.max(36, Math.ceil((maxAvg * 1.18) / 12) * 12);
    const ticks = [0, 1 / 3, 2 / 3, 1].map((f) => yMax * f);
    const x = (i: number) => M.l + (data.length > 1 ? (i / (data.length - 1)) * innerW : innerW / 2);
    const yTat = (v: number) => M.t + innerH - (v / yMax) * innerH;
    const ySla = (v: number) => M.t + innerH - ((clamp(v * 100, 40, 100) - 40) / 60) * innerH;
    const tatPts: Pt[] = data.map((d, i) => ({ x: x(i), y: yTat(d.avgTat) }));
    const slaPts: Pt[] = data.map((d, i) => ({ x: x(i), y: ySla(d.slaPct) }));
    const tatLine = smoothPath(tatPts);
    const slaLine = smoothPath(slaPts);
    const base = M.t + innerH;
    const tatArea = `${tatLine} L ${tatPts[tatPts.length - 1].x.toFixed(1)} ${base} L ${tatPts[0].x.toFixed(1)} ${base} Z`;
    return { yMax, ticks, tatPts, slaPts, tatLine, slaLine, tatArea };
  }, [data, innerW, innerH]);

  const onMove = (e: React.PointerEvent) => {
    if (!svgRef.current || data.length === 0) return;
    const rect = svgRef.current.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const idx = clamp(Math.round(((px - M.l) / innerW) * (data.length - 1)), 0, data.length - 1);
    setHover(idx);
  };

  const labelEvery = Math.max(1, Math.ceil(data.length / 6));
  const hov = hover !== null ? data[hover] : null;
  const hovTat = hover !== null ? tatPts[hover] : null;
  const hovSla = hover !== null ? slaPts[hover] : null;
  const tipX = hovTat ? clamp(hovTat.x, 108, W - 108) : 0;
  const targetY = M.t + innerH - (SLA_HOURS / yMax) * innerH;

  return (
    <div
      ref={wrapRef}
      className="relative w-full"
      style={{ height }}
      role="img"
      aria-label="Average turnaround time in hours against SLA compliance percentage; exact figures are listed in the closing log"
    >
      <svg
        ref={svgRef}
        width={W}
        height={height}
        className="block overflow-visible"
        onPointerMove={onMove}
        onPointerLeave={() => setHover(null)}
      >
        <defs>
          <linearGradient id={`tat-${gid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--brand)" stopOpacity="0.22" />
            <stop offset="100%" stopColor="var(--brand)" stopOpacity="0.01" />
          </linearGradient>
        </defs>

        {ticks.map((t, i) => {
          const gy = M.t + innerH - (t / yMax) * innerH;
          const rightPct = 40 + (i / 3) * 60;
          return (
            <g key={i}>
              <line x1={M.l} x2={W - M.r} y1={gy} y2={gy} stroke="var(--line)" strokeDasharray="3 5" />
              <text x={M.l - 8} y={gy + 4} textAnchor="end" fontSize={10.5} fill="var(--text-3)" fontWeight={500}>
                {i === 0 ? "0h" : `${t.toFixed(0)}h`}
              </text>
              <text x={W - M.r + 8} y={gy + 4} textAnchor="start" fontSize={10.5} fill="var(--text-3)" fontWeight={500}>
                {rightPct.toFixed(0)}%
              </text>
            </g>
          );
        })}

        {/* SLA target */}
        <line
          x1={M.l}
          x2={W - M.r}
          y1={targetY}
          y2={targetY}
          stroke="var(--chart-4)"
          strokeWidth={1.3}
          strokeDasharray="5 4"
          opacity={0.9}
        />
        <text x={W - M.r} y={targetY - 5} textAnchor="end" fontSize={9.5} fontWeight={600} fill="var(--chart-4)">
          {SLA_HOURS}h target
        </text>

        <path d={tatArea} fill={`url(#tat-${gid})`} className="anim-fade" style={{ animationDelay: "250ms" }} />
        <path
          d={tatLine}
          fill="none"
          stroke="var(--brand)"
          strokeWidth={2.5}
          strokeLinecap="round"
          pathLength={1}
          className="chart-line"
        />
        <path
          d={slaLine}
          fill="none"
          stroke="var(--chart-2)"
          strokeWidth={2}
          strokeLinecap="round"
          pathLength={1}
          className="chart-line"
          style={{ animationDelay: "260ms" }}
        />

        {hov && hovTat && hovSla && (
          <g>
            <line
              x1={hovTat.x}
              x2={hovTat.x}
              y1={M.t}
              y2={M.t + innerH}
              stroke="var(--line-strong)"
              strokeWidth={1}
            />
            <circle cx={hovTat.x} cy={hovTat.y} r={4.5} fill="var(--brand)" stroke="var(--surface)" strokeWidth={2.5} />
            <circle cx={hovSla.x} cy={hovSla.y} r={4} fill="var(--chart-2)" stroke="var(--surface)" strokeWidth={2.5} />
          </g>
        )}

        {data.map((d, i) =>
          i % labelEvery === 0 && i < data.length - labelEvery / 2 ? (
            <text
              key={i}
              x={tatPts[i].x}
              y={height - 6}
              textAnchor="middle"
              fontSize={10.5}
              fill="var(--text-3)"
              fontWeight={500}
            >
              {fmtDateShort(d.date)}
            </text>
          ) : null
        )}
      </svg>

      <div
        className="chart-tip absolute top-1 z-10 w-56 rounded-xl border border-(--line) bg-(--surface) p-3 shadow-xl shadow-black/10"
        style={{
          left: tipX - 112,
          opacity: hov ? 1 : 0,
          transform: hov ? "translateY(0)" : "translateY(4px)",
        }}
      >
        {hov && (
          <>
            <div className="mb-2 flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-(--text)">{fmtDateFull(hov.date)}</span>
              <span
                className="rounded-md px-1.5 py-0.5 text-[10px] font-bold"
                style={{
                  color: hov.avgTat <= SLA_HOURS ? "var(--up)" : "var(--down)",
                  background: hov.avgTat <= SLA_HOURS ? "var(--up-soft)" : "var(--down-soft)",
                }}
              >
                {hov.avgTat <= SLA_HOURS ? "within TAT" : "over TAT"}
              </span>
            </div>
            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-(--text-2)">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--brand)" }} />
                  Average TAT
                </span>
                <span className="font-semibold tabular-nums text-(--text)">{fmtHours(hov.avgTat)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-(--text-2)">
                  <span className="h-2 w-2 rounded-full" style={{ background: "var(--chart-2)" }} />
                  Within SLA
                </span>
                <span className="font-semibold tabular-nums text-(--text)">{fmtShare(hov.slaPct)}</span>
              </div>
              <div className="flex items-center justify-between border-t border-(--line) pt-1.5">
                <span className="text-(--text-2)">Jobs closed</span>
                <span className="font-semibold tabular-nums text-(--text)">{fmtInt(hov.closed)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-(--text-2)">Escalations</span>
                <span
                  className="font-semibold tabular-nums"
                  style={{ color: hov.escalations ? "var(--down)" : "var(--up)" }}
                >
                  {fmtInt(hov.escalations)}
                </span>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
