import { useMemo, useState } from "react";
import { Download, FileSpreadsheet } from "lucide-react";
import {
  buildPeriodSummaries,
  formatTat,
  warrantySummary,
  type Granularity,
  type Job,
  type WarrantyStat,
} from "@/lib/jobs";
import {
  buildFullReport,
  downloadCsv,
  downloadWorkbook,
  summaryRowsAoa,
  todayStamp,
} from "@/lib/export";
import { fmtDateShort, fmtInt, fmtRsCompact, fmtShare } from "@/lib/format";
import { Segmented } from "@/components/ui/Segmented";
import { cn } from "@/utils/cn";

const LIMITS: Record<Granularity, number> = { day: 14, week: 10, month: 12 };
const TITLES: Record<Granularity, string> = {
  day: "Daily",
  week: "Weekly",
  month: "Monthly",
};

export function PeriodAnalysis({
  jobs,
  sourceLabel,
}: {
  jobs: Job[];
  sourceLabel: string;
}) {
  const [granularity, setGranularity] = useState<Granularity>("week");
  const [showAll, setShowAll] = useState(false);

  const all = useMemo(
    () => buildPeriodSummaries(jobs, granularity, 500),
    [jobs, granularity]
  );
  const rows = showAll ? all : all.slice(-LIMITS[granularity]);
  const latest = rows[rows.length - 1];
  const complete = all.filter((r) => !r.partial);
  const cmpLatest = complete[complete.length - 1] ?? rows[rows.length - 1];
  const cmpPrevious = complete[complete.length - 2] ?? rows[rows.length - 2];
  const warranty = useMemo<WarrantyStat[]>(() => warrantySummary(jobs), [jobs]);

  const latestIn = rows.reduce((a, r) => a + r.inCount, 0);
  const latestOut = rows.reduce((a, r) => a + r.outCount, 0);
  const latestTotal = rows.reduce((a, r) => a + r.received, 0);

  const exportCurrent = () => {
    downloadWorkbook(`carlcare-${granularity}ly-summary-${todayStamp()}.xlsx`, [
      { name: `${TITLES[granularity]} Summary`, rows: summaryRowsAoa(rows) },
    ]);
  };
  const exportCsv = () => {
    downloadCsv(`carlcare-${granularity}ly-summary-${todayStamp()}.csv`, summaryRowsAoa(rows));
  };
  const exportFull = () => {
    const daily = buildPeriodSummaries(jobs, "day", 120);
    const weekly = buildPeriodSummaries(jobs, "week", 52);
    const monthly = buildPeriodSummaries(jobs, "month", 24);
    downloadWorkbook(`carlcare-full-analysis-${todayStamp()}.xlsx`, buildFullReport({
      jobs,
      daily,
      weekly,
      monthly,
      warranty,
      meta: `Source: ${sourceLabel} · ${fmtInt(jobs.length)} job cards · exported ${new Date().toLocaleString("en-GB")}`,
    }));
  };

  const delta = (cur: number, prev: number, kind: "pp" | "pct" = "pp") => {
    if (!prev) return "—";
    if (kind === "pp") return `${cur - prev >= 0 ? "+" : ""}${((cur - prev) * 100).toFixed(1)}pp`;
    return `${cur - prev >= 0 ? "+" : ""}${(((cur - prev) / Math.abs(prev)) * 100).toFixed(1)}%`;
  };

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
        <Segmented
          value={granularity}
          onChange={(v) => {
            setGranularity(v as Granularity);
            setShowAll(false);
          }}
          options={[
            { value: "day", label: "Daily" },
            { value: "week", label: "Weekly" },
            { value: "month", label: "Monthly" },
          ]}
        />
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={exportCurrent}
            className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-(--line) px-2.5 text-[11px] font-semibold text-(--text-2) hover:border-(--brand) hover:text-(--brand-strong)"
          >
            <Download size={12} /> {TITLES[granularity]} Excel
          </button>
          <button
            type="button"
            onClick={exportCsv}
            className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-(--line) px-2.5 text-[11px] font-semibold text-(--text-2) hover:border-(--brand) hover:text-(--brand-strong)"
          >
            <Download size={12} /> CSV
          </button>
          <button
            type="button"
            onClick={exportFull}
            className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-(--brand) px-2.5 text-[11px] font-semibold text-white hover:bg-(--brand-strong)"
          >
            <FileSpreadsheet size={12} /> Full report
          </button>
        </div>
      </div>

      <p className="mb-2 text-[11px] leading-relaxed text-(--text-3)">
        Grouped by submission date, so each row shows what happened to the job cards received in that period.
        {cmpLatest && cmpPrevious && (
          <>
            {" "}Last completed {granularity}: <strong className="text-(--text-2)">{cmpLatest.label}</strong> — closures{" "}
            {delta(cmpLatest.closed, cmpPrevious.closed, "pct")}, SLA {delta(cmpLatest.slaPct, cmpPrevious.slaPct)}, in-warranty share{" "}
            {delta(cmpLatest.inPct, cmpPrevious.inPct)}.
          </>
        )}{" "}
        Rows marked <strong className="text-(--text-2)">to date</strong> are still in progress.
      </p>

      <div className="overflow-x-auto rounded-xl border border-(--line)">
        <table className="w-full min-w-[880px] border-collapse text-[12px]">
          <thead>
            <tr className="bg-(--surface-2) text-right">
              <th className="px-3 py-2.5 pl-4 text-left text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">Period</th>
              <th className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">In</th>
              <th className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">Closed</th>
              <th className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">Not closed</th>
              <th className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">Avg TAT</th>
              <th className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">SLA</th>
              <th className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">In warr.</th>
              <th className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">Out warr.</th>
              <th className="px-3 py-2.5 pr-4 text-[10.5px] font-bold uppercase tracking-wider text-(--text-3)">Revenue</th>
            </tr>
          </thead>
          <tbody>
            {[...rows].reverse().map((r) => (
              <tr key={r.key} className={cn("border-t border-(--line) hover:bg-(--surface-2)", r === latest && "bg-(--brand-soft)/40")}>
                <td className="whitespace-nowrap px-3 py-2.5 pl-4">
                  <span className="font-semibold text-(--text)">{r.label}</span>
                  {r === latest && (
                    <span className="ml-1.5 rounded bg-(--brand) px-1 py-0.5 text-[9px] font-bold text-white">
                      {r.partial ? "to date" : "latest"}
                    </span>
                  )}
                  <div className="text-[10px] text-(--text-3)">{fmtDateShort(new Date(r.start))} cohort</div>
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums text-(--text-2)">{fmtInt(r.received)}</td>
                <td className="px-3 py-2.5 text-right font-semibold tabular-nums text-(--text)">{fmtInt(r.closed)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums" style={{ color: r.pending ? "var(--warn)" : "var(--text-2)" }}>{fmtInt(r.pending)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums text-(--text-2)">{formatTat(r.avgTat)}</td>
                <td className="px-3 py-2.5 text-right font-semibold tabular-nums" style={{ color: r.slaPct >= 0.85 ? "var(--up)" : r.slaPct >= 0.7 ? "var(--warn)" : "var(--down)" }}>{fmtShare(r.slaPct)}</td>
                <td className="px-3 py-2.5 text-right tabular-nums" style={{ color: "var(--chart-2)" }}>
                  {fmtShare(r.inPct)}
                  <span className="ml-1 text-[10px] text-(--text-3)">{r.inCount}</span>
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums" style={{ color: "var(--brand-strong)" }}>
                  {fmtShare(r.outPct)}
                  <span className="ml-1 text-[10px] text-(--text-3)">{r.outCount}</span>
                </td>
                <td className="whitespace-nowrap px-3 py-2.5 pr-4 text-right tabular-nums text-(--text)">{fmtRsCompact(r.revenue)}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={9} className="px-4 py-12 text-center text-sm text-(--text-3)">No job cards in this dataset.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <p className="text-[10.5px] text-(--text-3)">
          {rows.length} {granularity} rows · {fmtInt(latestTotal)} submissions · in warranty {fmtShare(latestTotal ? latestIn / latestTotal : 0)}, out of warranty{" "}
          {fmtShare(latestTotal ? latestOut / latestTotal : 0)}
        </p>
        {all.length > LIMITS[granularity] && (
          <button
            type="button"
            onClick={() => setShowAll((v) => !v)}
            className="text-[11px] font-semibold text-(--brand-strong) hover:underline"
          >
            {showAll ? `Show last ${LIMITS[granularity]}` : `Show all ${all.length}`}
          </button>
        )}
      </div>
    </div>
  );
}
