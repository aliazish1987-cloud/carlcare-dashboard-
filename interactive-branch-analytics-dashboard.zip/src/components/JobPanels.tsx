import {
  ArrowDownRight,
  ArrowUpRight,
  BadgeCheck,
  Clock,
  Download,
  FileText,
  PackageOpen,
  ShieldQuestion,
  TriangleAlert,
  Zap,
} from "lucide-react";
import type { JobView, PeriodSummary, WarrantyStat } from "@/lib/jobs";
import { FAST_TRACK_HOURS, formatTat } from "@/lib/jobs";
import { downloadWorkbook, jobRowsAoa, todayStamp } from "@/lib/export";
import { fmtDateShort, fmtHours, fmtInt, fmtRsCompact, fmtShare } from "@/lib/format";
import { MixDonut } from "@/components/charts/MixDonut";

const pp = (n: number) => `${n >= 0 ? "+" : ""}${(n * 100).toFixed(1)}pp`;

/* ------------------------- daily brief --------------------------- */

export function BriefAnalysis({
  view,
  weekly,
  monthly,
  days,
  sourceLabel,
}: {
  view: JobView;
  weekly: PeriodSummary[];
  monthly: PeriodSummary[];
  days: number;
  sourceLabel: string;
}) {
  const t = view.totals;
  const p = view.prevTotals;
  const closeRate = t.received ? t.closed / t.received : 0;
  const prevCloseRate = p.received ? p.closed / p.received : 0;
  const inW = view.job.warranty.find((w) => w.key === "in");
  const outW = view.job.warranty.find((w) => w.key === "out");
  const fast = view.job.fastPct;
  const slow = view.job.tatBuckets.find((b) => b.key === "slow")?.count ?? 0;
  const oldest = [...view.job.openJobs].sort((a, b) => a.dateIn - b.dateIn)[0];
  const completeWeeks = weekly.filter((w) => !w.partial);
  const completeMonths = monthly.filter((m) => !m.partial);
  const wNow = completeWeeks[completeWeeks.length - 1];
  const wPrev = completeWeeks[completeWeeks.length - 2];
  const mNow = completeMonths[completeMonths.length - 1];
  const mPrev = completeMonths[completeMonths.length - 2];
  const targetOk = t.slaPct >= 0.85;
  const periodText = days === 0 ? "all history" : `the last ${days} days`;

  const findings: { icon: typeof Clock; color: string; title: string; text: string }[] = [
    {
      icon: BadgeCheck,
      color: targetOk ? "var(--up)" : "var(--warn)",
      title: "Closures & SLA",
      text: `You closed ${fmtInt(t.closed)} of ${fmtInt(t.received)} submitted job cards (${fmtShare(closeRate)}) at an average TAT of ${formatTat(t.avgTat)}. SLA compliance is ${fmtShare(t.slaPct)} — ${targetOk ? "above" : "below"} the 85% target${view.compared ? `, ${pp(t.slaPct - p.slaPct)} versus the previous period` : ""}.`,
    },
    {
      icon: Zap,
      color: "var(--up)",
      title: "1-hour closures",
      text: `${fmtInt(view.job.fastJobs.length)} job cards were closed within ${FAST_TRACK_HOURS} hour (${fmtShare(fast)} of all closures). ${fmtInt(slow)} closures took longer than 48 hours${slow ? " — review spare-parts availability for those cards" : ""}.`,
    },
    {
      icon: ShieldQuestion,
      color: "var(--chart-2)",
      title: "Warranty contribution",
      text: inW || outW
        ? `In-warranty devices contributed ${fmtShare(inW?.pct ?? 0)} of submissions (${fmtInt(inW?.count ?? 0)} cards${inW ? `, avg TAT ${formatTat(inW.avgTat)}` : ""}), while out-of-warranty contributed ${fmtShare(outW?.pct ?? 0)} (${fmtInt(outW?.count ?? 0)} cards${outW ? `, avg TAT ${formatTat(outW.avgTat)}` : ""}).`
        : "The uploaded sheets do not contain a warranty column, so warranty contribution cannot be calculated.",
    },
    {
      icon: PackageOpen,
      color: view.job.openOver72 ? "var(--down)" : "var(--warn)",
      title: "Backlog & ageing",
      text: `${fmtInt(t.pending)} job cards are still not closed, of which ${fmtInt(view.job.openOver72)} are older than 72 hours${oldest ? `. Oldest open card: ${oldest.jc} (${oldest.device}), submitted ${fmtDateShort(new Date(oldest.dateIn))}` : ""}.`,
    },
    {
      icon: ArrowUpRight,
      color: "var(--brand)",
      title: weekly.length >= 2 && wPrev ? "Week-on-week" : "Week-on-week",
      text:
        wPrev && wNow
          ? `Last completed week (${wNow.label}): ${fmtInt(wNow.closed)} closed from ${fmtInt(wNow.received)} submitted, SLA ${fmtShare(wNow.slaPct)} (${pp(wNow.slaPct - wPrev.slaPct)} vs previous week). In-warranty share ${fmtShare(wNow.inPct)}, out-of-warranty ${fmtShare(wNow.outPct)}.`
          : "Not enough completed weeks yet — import more daily workbooks to unlock week-on-week conclusions.",
    },
    {
      icon: ArrowDownRight,
      color: "var(--chart-3)",
      title: "Month-on-month",
      text:
        mPrev && mNow
          ? `${mNow.label}: ${fmtInt(mNow.received)} submitted, ${fmtInt(mNow.closed)} closed, average TAT ${formatTat(mNow.avgTat)} and SLA ${fmtShare(mNow.slaPct)} (${pp(mNow.slaPct - mPrev.slaPct)} vs ${mPrev.label}).`
          : "Only one month of data is available so far; month-on-month comparison will appear with the next month of sheets.",
    },
  ];

  const exportBrief = () => {
    downloadWorkbook(`carlcare-daily-brief-${todayStamp()}.xlsx`, [
      {
        name: "Daily Brief",
        rows: [
          ["Carlcare Islamabad — Daily Brief Analysis"],
          [`Period: ${periodText} · Source: ${sourceLabel} · Generated ${new Date().toLocaleString("en-GB")}`],
          [],
          ["Finding", "Conclusion"],
          ...findings.map((f) => [f.title, f.text]),
          [],
          ["Missed closures", `${p.received ? pp(closeRate - prevCloseRate) : "—"} closure rate change vs previous period`],
        ],
      },
    ]);
  };

  return (
    <section
      id="brief"
      className="anim-rise scroll-mt-24 rounded-2xl border border-(--line) bg-(--surface) shadow-(--shadow-card)"
      style={{ animationDelay: "225ms" }}
    >
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-(--line) px-5 py-4 sm:px-6">
        <div className="flex items-start gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-(--brand-soft) text-(--brand-strong)">
            <FileText size={17} />
          </span>
          <div>
            <h2 className="text-[15px] font-semibold tracking-tight text-(--text)">Daily brief analysis</h2>
            <p className="mt-0.5 text-xs text-(--text-3)">
              Auto-generated conclusions for {periodText} · source: {sourceLabel}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={exportBrief}
          className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-(--line) px-2.5 text-[11.5px] font-semibold text-(--text-2) transition-colors hover:border-(--brand) hover:text-(--brand-strong)"
        >
          <Download size={13} />
          Download brief
        </button>
      </div>
      <div className="grid grid-cols-1 gap-px bg-(--line) sm:grid-cols-2 xl:grid-cols-3">
        {findings.map((f) => (
          <div key={f.title} className="flex items-start gap-2.5 bg-(--surface) px-4 py-3.5 sm:px-5">
            <span
              className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg"
              style={{ color: f.color, background: "color-mix(in srgb, currentColor 12%, transparent)" }}
            >
              <f.icon size={14} strokeWidth={2.2} />
            </span>
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-wide text-(--text-3)">{f.title}</p>
              <p className="mt-1 text-[12px] leading-relaxed text-(--text-2)">{f.text}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ------------------------- warranty mix -------------------------- */

export function WarrantyCard({ stats, onReport }: { stats: WarrantyStat[]; onReport: () => void }) {
  const total = stats.reduce((a, s) => a + s.count, 0);
  const inW = stats.find((s) => s.key === "in");
  const outW = stats.find((s) => s.key === "out");
  const segments = stats.map((s) => ({
    key: s.key,
    label: s.label,
    value: s.count,
    color: s.color,
  }));

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <p className="font-display text-2xl font-bold tabular-nums tracking-tight text-(--text)">
            {fmtShare(inW?.pct ?? 0)}
            <span className="ml-1.5 text-xs font-medium text-(--text-3)">in warranty</span>
          </p>
          <p className="text-[11px] text-(--text-3)">
            {fmtShare(outW?.pct ?? 0)} out of warranty · {fmtInt(total)} submissions
          </p>
        </div>
        <button
          type="button"
          onClick={onReport}
          className="inline-flex h-7 items-center gap-1 rounded-lg px-2 text-[11px] font-semibold text-(--brand-strong) hover:bg-(--brand-soft)"
        >
          <Download size={12} /> Excel
        </button>
      </div>

      <MixDonut segments={segments} />

      <div className="mt-2 divide-y divide-(--line) border-t border-(--line)">
        {stats.map((s) => (
          <div key={s.key} className="flex items-center gap-2 py-2 text-[11.5px]">
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: s.color }} />
            <span className="min-w-0 flex-1 truncate font-medium text-(--text-2)">{s.label}</span>
            <span className="w-12 text-right font-semibold tabular-nums text-(--text)">{fmtShare(s.pct)}</span>
            <span className="w-14 text-right tabular-nums text-(--text-3)">{formatTat(s.avgTat)}</span>
            <span
              className="w-12 text-right font-semibold tabular-nums"
              style={{ color: s.slaPct >= 0.85 ? "var(--up)" : s.slaPct >= 0.7 ? "var(--warn)" : "var(--down)" }}
            >
              {fmtShare(s.slaPct)}
            </span>
          </div>
        ))}
        <div className="flex items-center justify-between pt-2 text-[10px] text-(--text-3)">
          <span>contribution</span><span>avg TAT</span><span>SLA</span>
        </div>
      </div>
    </div>
  );
}

/* -------------------------- fast track --------------------------- */

export function FastTrackCard({ view }: { view: JobView }) {
  const closed = view.job.closedJobs.length;
  const fast = view.job.fastJobs.length;
  const open = view.job.openJobs.length;

  const exportFast = () => {
    downloadWorkbook(`carlcare-closed-within-1h-${todayStamp()}.xlsx`, [
      { name: "Closed within 1 hour", rows: jobRowsAoa(view.job.fastJobs) },
    ]);
  };
  const exportOpen = () => {
    downloadWorkbook(`carlcare-not-closed-${todayStamp()}.xlsx`, [
      { name: "Not closed", rows: jobRowsAoa(view.job.openJobs) },
    ]);
  };

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-display text-2xl font-bold tabular-nums tracking-tight" style={{ color: "var(--up)" }}>
            {fmtInt(fast)}
            <span className="ml-1.5 text-xs font-medium text-(--text-3)">closed ≤1 hour</span>
          </p>
          <p className="text-[11px] text-(--text-3)">
            {fmtShare(view.job.fastPct)} of {fmtInt(closed)} closures · {fmtInt(open)} still not closed
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={exportFast}
            className="inline-flex h-7 items-center gap-1 rounded-lg bg-(--up-soft) px-2 text-[11px] font-semibold text-(--up) transition-opacity hover:opacity-80"
          >
            <Download size={12} /> ≤1h report
          </button>
          <button
            type="button"
            onClick={exportOpen}
            className="inline-flex h-7 items-center gap-1 rounded-lg bg-(--warn-soft) px-2 text-[11px] font-semibold text-(--warn) transition-opacity hover:opacity-80"
          >
            <Download size={12} /> Not-closed report
          </button>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-(--text-3)">Repair time of closed jobs</p>
          <ul className="space-y-1.5">
            {view.job.tatBuckets.map((b) => {
              const pct = closed ? b.count / closed : 0;
              return (
                <li key={b.key} className="flex items-center gap-2">
                  <span className="w-24 shrink-0 text-[11px] text-(--text-2)">{b.label}</span>
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-(--surface-3)">
                    <span
                      className="block h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct * 100}%`, background: b.color }}
                    />
                  </span>
                  <span className="w-8 text-right text-[11px] font-bold tabular-nums text-(--text)">{b.count}</span>
                  <span className="w-9 text-right text-[10px] tabular-nums text-(--text-3)">{fmtShare(pct)}</span>
                </li>
              );
            })}
          </ul>
        </div>
        <div>
          <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-(--text-3)">
            Ageing of open job cards
          </p>
          <ul className="space-y-1.5">
            {view.job.agingBuckets.map((b) => {
              const pct = open ? b.count / open : 0;
              return (
                <li key={b.key} className="flex items-center gap-2">
                  <span className="w-24 shrink-0 text-[11px] text-(--text-2)">{b.label}</span>
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-(--surface-3)">
                    <span
                      className="block h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct * 100}%`, background: b.color }}
                    />
                  </span>
                  <span className="w-8 text-right text-[11px] font-bold tabular-nums text-(--text)">{b.count}</span>
                  <span className="w-9 text-right text-[10px] tabular-nums text-(--text-3)">{fmtShare(pct)}</span>
                </li>
              );
            })}
          </ul>
          {view.job.openOver72 > 0 ? (
            <p className="mt-2 flex items-start gap-1.5 rounded-lg bg-(--down-soft) px-2 py-1.5 text-[10.5px] font-medium text-(--down)">
              <TriangleAlert size={12} className="mt-0.5 shrink-0" />
              {view.job.openOver72} cards are past 72 hours — assign or escalate today.
            </p>
          ) : (
            <p className="mt-2 flex items-center gap-1.5 rounded-lg bg-(--up-soft) px-2 py-1.5 text-[10.5px] font-medium text-(--up)">
              <BadgeCheck size={12} /> No open card is older than 72 hours.
            </p>
          )}
        </div>
      </div>
      {view.metrics.revenue && (
        <p className="mt-3 border-t border-(--line) pt-2 text-[10.5px] text-(--text-3)">
          Out-of-warranty revenue in period: {fmtRsCompact(view.totals.revenue)} · average{" "}
          {fmtHours(view.totals.avgTat)} per closed card
        </p>
      )}
    </div>
  );
}


