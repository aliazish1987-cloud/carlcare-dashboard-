import {
  CalendarRange,
  FileSpreadsheet,
  Menu,
  Moon,
  RotateCcw,
  Sun,
  Upload,
  UserRound,
  Wrench,
} from "lucide-react";
import { Select, type SelectOption } from "@/components/ui/Select";
import { Segmented } from "@/components/ui/Segmented";
import { CENTER, TODAY } from "@/lib/data";
import { fmtDateLong } from "@/lib/format";
import { cn } from "@/utils/cn";

interface HeaderProps {
  days: number;
  onDays: (d: number) => void;
  service: string;
  onService: (s: string) => void;
  serviceOptions: SelectOption[];
  technician: string;
  onTechnician: (t: string) => void;
  technicianOptions: SelectOption[];
  warranty: string;
  onWarranty: (w: string) => void;
  showWarranty: boolean;
  breakdownDisabled?: boolean;
  breakdownHint?: string;
  dark: boolean;
  onToggleDark: () => void;
  onMenu: () => void;
  imported: boolean;
  onImport: () => void;
  asOf?: Date;
  modeLabel: string;
}

const RANGE_OPTIONS = [
  ...[7, 14, 30, 90].map((d) => ({ value: String(d), label: `${d}D` })),
  { value: "0", label: "All" },
];

export function Header({
  days,
  onDays,
  service,
  onService,
  serviceOptions,
  technician,
  onTechnician,
  technicianOptions,
  warranty,
  onWarranty,
  showWarranty,
  breakdownDisabled,
  breakdownHint,
  dark,
  onToggleDark,
  onMenu,
  imported,
  onImport,
  asOf,
  modeLabel,
}: HeaderProps) {
  const isDefault = days === 30 && service === "all" && technician === "all" && warranty === "all";

  return (
    <header className="glass relative z-30 border-b border-(--line) print:hidden lg:sticky lg:top-0">
      <div className="mx-auto flex h-14 max-w-[1440px] items-center gap-3 px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          aria-label="Open menu"
          onClick={onMenu}
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-(--line) text-(--text-2) transition-colors hover:bg-(--surface-2) lg:hidden"
        >
          <Menu size={17} />
        </button>
        <nav className="flex min-w-0 items-center gap-1.5 text-[13px] font-medium">
          <span className="hidden text-(--text-3) sm:inline">Service Center</span>
          <span className="hidden text-(--text-3) sm:inline">/</span>
          <span className="hidden text-(--text-2) sm:inline">Islamabad</span>
          <span className="hidden text-(--text-3) sm:inline">/</span>
          <span className="truncate text-(--text)">Daily Analysis</span>
        </nav>
        <div className="flex-1" />
        <span className="hidden items-center gap-2 rounded-full border border-(--line) bg-(--surface) px-3 py-1.5 text-[11px] font-semibold text-(--text-2) md:inline-flex">
          <span className={cn("h-1.5 w-1.5 rounded-full", imported ? "bg-(--brand)" : "live-dot bg-(--up)")} />
          {imported ? "Your uploaded sheets" : "Sample dataset · not live"}
        </span>
        <button
          type="button"
          onClick={onImport}
          className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-(--line) bg-(--surface) px-2.5 text-[12px] font-semibold text-(--text-2) transition-colors duration-200 hover:border-(--brand) hover:text-(--brand-strong)"
        >
          {imported ? <FileSpreadsheet size={14} /> : <Upload size={14} />}
          <span className="hidden sm:inline">{imported ? "Add / replace files" : "Import Excel"}</span>
        </button>
        <button
          type="button"
          onClick={onToggleDark}
          aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
          className="relative flex h-9 w-9 items-center justify-center overflow-hidden rounded-lg border border-(--line) bg-(--surface) text-(--text-2) transition-colors duration-200 hover:bg-(--surface-2) hover:text-(--text)"
        >
          <Sun size={16} className={cn("absolute transition-all duration-300", dark ? "-rotate-90 scale-0 opacity-0" : "rotate-0 scale-100 opacity-100")} />
          <Moon size={16} className={cn("absolute transition-all duration-300", dark ? "rotate-0 scale-100 opacity-100" : "rotate-90 scale-0 opacity-0")} />
        </button>
      </div>

      <div className="mx-auto max-w-[1440px] px-4 pb-4 pt-2 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-x-6 gap-y-4">
          <div className="anim-rise">
            <h1 className="font-display text-xl font-bold tracking-tight text-(--text) sm:text-2xl">
              Daily Branch Analysis
            </h1>
            <p className="mt-1 text-[13px] text-(--text-3)">
              {fmtDateLong(asOf ?? TODAY)} · {CENTER.replace(" Service Center", "")} · {modeLabel}
              {days === 0 && " · all history"}
            </p>
          </div>

          <div className="anim-rise flex flex-wrap items-end gap-3" style={{ animationDelay: "60ms" }}>
            <Segmented
              label="Range"
              size="sm"
              value={String(days)}
              onChange={(v) => onDays(Number(v))}
              options={RANGE_OPTIONS}
            />
            <Select
              label="Warranty"
              value={warranty}
              onChange={onWarranty}
              icon={<Wrench size={15} />}
              className={cn("w-36", !showWarranty && "hidden")}
              options={[
                { value: "all", label: "All devices" },
                { value: "in", label: "In warranty" },
                { value: "out", label: "Out of warranty" },
                { value: "unknown", label: "Not specified" },
              ]}
            />
            <Select
              label="Service line"
              value={service}
              onChange={onService}
              icon={<Wrench size={15} />}
              className="w-44"
              options={serviceOptions}
              disabled={breakdownDisabled}
              disabledHint={breakdownHint}
            />
            <Select
              label="Technician"
              value={technician}
              onChange={onTechnician}
              icon={<UserRound size={15} />}
              className="w-40"
              options={technicianOptions}
              disabled={breakdownDisabled}
              disabledHint={breakdownHint}
            />
            <button
              type="button"
              onClick={() => {
                onDays(30);
                onService("all");
                onTechnician("all");
                onWarranty("all");
              }}
              className={cn(
                "mb-px inline-flex h-10 items-center gap-1.5 rounded-xl border px-3 text-[13px] font-medium transition-all duration-200",
                isDefault
                  ? "pointer-events-none border-transparent text-transparent"
                  : "border-(--line) text-(--text-2) hover:bg-(--surface-2) hover:text-(--text)"
              )}
            >
              <RotateCcw size={14} />
              Reset
            </button>
            <span className="mb-px hidden h-10 items-center gap-1.5 rounded-xl bg-(--brand-soft) px-3 text-[13px] font-semibold text-(--brand-strong) 2xl:inline-flex">
              <CalendarRange size={14} />
              {days === 0 ? "Full history" : `${days}-day view`}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
