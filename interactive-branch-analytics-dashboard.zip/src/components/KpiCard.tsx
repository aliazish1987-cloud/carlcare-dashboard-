import { ArrowDownRight, ArrowUpRight, Minus, type LucideIcon } from "lucide-react";
import { useCountUp } from "@/hooks/hooks";
import { Sparkline } from "@/components/charts/Sparkline";
import { fmtPct } from "@/lib/format";
import { cn } from "@/utils/cn";

interface KpiCardProps {
  label: string;
  icon: LucideIcon;
  value: number;
  format: (n: number) => string;
  delta: number;
  spark: number[];
  color: string;
  periodLabel: string;
  goodWhenDown?: boolean;
  delay?: number;
  animKey?: string;
  /** e.g. "goal ≥85%" */
  target?: string;
  available?: boolean;
  compared?: boolean;
  unavailableNote?: string;
}

export function KpiCard({
  label,
  icon: Icon,
  value,
  format,
  delta,
  spark,
  color,
  periodLabel,
  goodWhenDown = false,
  delay = 0,
  animKey,
  target,
  available = true,
  compared = true,
  unavailableNote = "not in sheet",
}: KpiCardProps) {
  const animated = useCountUp(value);
  const up = delta >= 0;
  const good = goodWhenDown ? !up : up;

  return (
    <div
      className={cn(
        "anim-rise group relative overflow-hidden rounded-2xl border border-(--line) bg-(--surface) p-5",
        "shadow-(--shadow-card) transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
      )}
      style={{ animationDelay: `${delay}ms` }}
    >
      <span
        className="absolute inset-x-0 top-0 h-[2.5px] opacity-80"
        style={{ background: `linear-gradient(90deg, transparent, ${available ? color : "var(--line-strong)"}, transparent)` }}
      />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span
              className="flex h-8 w-8 items-center justify-center rounded-lg"
              style={{ color, background: "color-mix(in srgb, currentColor 12%, transparent)" }}
            >
              <Icon size={16} strokeWidth={2.2} />
            </span>
            <span className="text-[13px] font-medium text-(--text-2)">{label}</span>
            {target && available && (
              <span className="rounded bg-(--surface-2) px-1.5 py-0.5 text-[9.5px] font-semibold uppercase tracking-wide text-(--text-3)">
                {target}
              </span>
            )}
          </div>
          <div
            className={cn(
              "font-display mt-3 truncate text-[26px] font-bold leading-none tabular-nums tracking-tight lg:text-[30px]",
              available ? "text-(--text)" : "text-(--text-3)"
            )}
          >
            {available ? format(animated) : "—"}
          </div>
        </div>
        {available && spark.length > 1 && (
          <div className="shrink-0 pt-1">
            <Sparkline key={animKey} data={spark} color={color} width={92} height={36} />
          </div>
        )}
      </div>
      <div className="mt-3.5 flex items-center gap-2">
        {available ? (
          compared ? (
            <span
              className="inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[11px] font-bold tabular-nums"
              style={{
                color: good ? "var(--up)" : "var(--down)",
                background: good ? "var(--up-soft)" : "var(--down-soft)",
              }}
            >
              {up ? <ArrowUpRight size={13} strokeWidth={2.6} /> : <ArrowDownRight size={13} strokeWidth={2.6} />}
              {fmtPct(Math.abs(delta), false)}
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 rounded-md bg-(--surface-2) px-1.5 py-1 text-[11px] font-semibold text-(--text-3)">
              <Minus size={12} strokeWidth={2.6} />
              no prior window
            </span>
          )
        ) : (
          <span className="inline-flex items-center gap-1 rounded-md bg-(--surface-2) px-1.5 py-1 text-[11px] font-semibold text-(--text-3)">
            optional metric
          </span>
        )}
        <span className="truncate text-[11px] text-(--text-3)">
          {available ? (compared ? `vs previous ${periodLabel}` : "full history has no comparison window") : unavailableNote}
        </span>
      </div>
    </div>
  );
}
