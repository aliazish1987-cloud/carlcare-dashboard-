import { useMemo, useState } from "react";
import { ChevronDown, Medal, Timer } from "lucide-react";
import { fmtHours, fmtInt, fmtScore, fmtShare } from "@/lib/format";
import { SERVICES, type TechRank } from "@/lib/data";

type SortKey = "closed" | "sla" | "tat" | "csat";

const SORT_LABELS: Record<SortKey, string> = {
  closed: "Sort: jobs closed",
  sla: "Sort: SLA met",
  tat: "Sort: fastest TAT",
  csat: "Sort: CSAT",
};

export function TechnicianScorecard({ ranks }: { ranks: TechRank[] }) {
  const [sort, setSort] = useState<SortKey>("closed");
  const [showAll, setShowAll] = useState(false);

  const sorted = useMemo(() => {
    const rows = [...ranks];
    rows.sort((a, b) => {
      if (sort === "closed") return b.closed - a.closed;
      if (sort === "sla") return b.slaPct - a.slaPct || b.closed - a.closed;
      if (sort === "tat") return (a.avgTat || 999) - (b.avgTat || 999);
      return b.csat - a.csat || b.closed - a.closed;
    });
    return rows;
  }, [ranks, sort]);

  const visible = showAll ? sorted : sorted.slice(0, 6);

  if (ranks.length === 0) {
    return (
      <div className="py-10 text-center text-sm text-(--text-3)">
        No technician activity in this period.
      </div>
    );
  }

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <label className="relative inline-flex items-center">
          <span className="sr-only">Sort technicians</span>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
            className="h-8 appearance-none rounded-lg border border-(--line) bg-(--surface-2) pl-2.5 pr-7 text-[11px] font-semibold text-(--text-2) transition-colors hover:text-(--text)"
          >
            {(Object.keys(SORT_LABELS) as SortKey[]).map((k) => (
              <option key={k} value={k}>
                {SORT_LABELS[k]}
              </option>
            ))}
          </select>
          <ChevronDown size={12} className="pointer-events-none absolute right-2 text-(--text-3)" />
        </label>
        {ranks.length > 6 && (
          <button
            type="button"
            onClick={() => setShowAll((v) => !v)}
            className="rounded-lg px-2 py-1 text-[11px] font-semibold text-(--brand-strong) transition-colors hover:bg-(--brand-soft)"
          >
            {showAll ? "Show top 6" : `Show all ${ranks.length}`}
          </button>
        )}
      </div>

      <ul className="space-y-0.5">
        {visible.map((r, i) => {
          const svc = SERVICES.find((s) => s.key === r.tech.specialty);
          const color = svc?.color ?? "var(--brand)";
          const slaColor =
            r.slaPct >= 0.85 ? "var(--up)" : r.slaPct >= 0.7 ? "var(--warn)" : "var(--down)";
          return (
            <li
              key={r.tech.id}
              className="group flex items-center gap-3 rounded-xl px-2 py-2 transition-colors duration-150 hover:bg-(--surface-2)"
            >
              <div className="relative shrink-0">
                <span
                  className="flex h-9 w-9 items-center justify-center rounded-full text-[11px] font-bold"
                  style={{ color, background: "color-mix(in srgb, currentColor 13%, transparent)" }}
                >
                  {r.tech.avatar}
                </span>
                {i === 0 && (
                  <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-(--chart-4) text-white ring-2 ring-(--surface)">
                    <Medal size={9} strokeWidth={3} />
                  </span>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <span className="truncate text-[13px] font-semibold text-(--text)">{r.tech.name}</span>
                  <span className="shrink-0 text-[12px] font-bold tabular-nums text-(--text)">
                    {fmtInt(r.closed)}
                    <span className="ml-1 text-[10px] font-medium text-(--text-3)">closed</span>
                  </span>
                </div>
                <div className="mt-1 flex items-center gap-2 text-[11px] text-(--text-3)">
                  <span className="inline-flex items-center gap-1 tabular-nums">
                    <Timer size={11} />
                    {r.avgTat > 0 ? fmtHours(r.avgTat) : "—"}
                  </span>
                  <span className="h-1 w-1 rounded-full bg-(--line-strong)" />
                  <span className="tabular-nums">{fmtScore(r.csat)} CSAT</span>
                  <span className="truncate">{r.tech.role}</span>
                </div>
                <div className="mt-1.5 flex items-center gap-2">
                  <div className="h-1 flex-1 overflow-hidden rounded-full bg-(--surface-3)">
                    <div
                      className="progress-fill h-full rounded-full"
                      style={{
                        width: `${r.slaPct * 100}%`,
                        background: slaColor,
                        transitionDelay: `${i * 60}ms`,
                      }}
                    />
                  </div>
                  <span className="shrink-0 text-[10px] font-bold tabular-nums" style={{ color: slaColor }}>
                    {fmtShare(r.slaPct)} SLA
                  </span>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
      <p className="mt-2 border-t border-(--line) pt-2 text-[10px] text-(--text-3)">
        Bar = share of closed jobs within SLA. CSAT excludes cards with no rating.
      </p>
    </div>
  );
}
