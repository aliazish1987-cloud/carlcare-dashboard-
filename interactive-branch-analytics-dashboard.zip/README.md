# Carlcare Islamabad — Daily Branch Analysis

Browser-based dashboard for day-end workbooks: job cards, TAT/SLA, 1-hour closures,
warranty contribution, daily/weekly/monthly conclusions and Excel/CSV exports.
All analysis runs in the browser; uploaded files are **never sent to a server**.

## Build

```bash
npm install
npm run build
```

Output: `dist/index.html` — a single self-contained file (~840 KB).
JavaScript, CSS and the Excel engine (SheetJS) are inlined; nothing else is required
except Google Fonts (optional — system fonts are used if offline).

## Turning it into a browser link

Pick one option. All of them serve the same `dist/index.html`.

### 1. GitHub Pages (recommended if the team already uses GitHub)

A ready-made workflow is included at `.github/workflows/deploy.yml`.

**First push:**
```bash
git init
git add .
git commit -m "Carlcare daily branch analysis dashboard"
git branch -M main
git remote add origin https://github.com/<your-user>/<your-repo>.git
git push -u origin main
```

**Enable Pages once:** repository **Settings → Pages → Build and deployment →
Source: GitHub Actions**. The workflow then runs on every push to `main`.

Your link will be:
```
https://<your-user>.github.io/<your-repo>/
```

You can also run it manually: **Actions → Deploy to GitHub Pages → Run workflow**.
`dist/` is intentionally git-ignored — the workflow builds it on GitHub.

**Manual alternative (no Actions):** run `npm run build`, copy `dist/index.html`
to `docs/index.html`, commit it, then set **Settings → Pages → Deploy from a branch →
`main` / `docs`**.

> On a private repository, GitHub Pages may still be publicly reachable depending on your
> plan. The app contains no uploaded data (only synthetic demo figures), so sharing the
> page is safe — but never commit real workbooks or exported customer reports to the repo.

### 2. Netlify Drop (fastest, free, gives an HTTPS link)
1. Run `npm run build`.
2. Open <https://app.netlify.com/drop>.
3. Drag the whole **`dist` folder** onto the page.
4. Copy the generated `https://…netlify.app` URL. Share that with supervisors.

### 3. Cloudflare Pages (free)
Dashboard → Workers & Pages → Pages → *Upload assets* → upload the contents of `dist`
→ deploy. A `https://<project>.pages.dev` link is produced.

### 4. Internal server (no internet needed for the app)
Copy `dist/index.html` to any web server, e.g. IIS:
`C:\inetpub\wwwroot\carlcare\index.html` → `http://<server-ip>/carlcare/`.
Only the single file is needed.

### 5. Local testing on your own PC
```bash
npx serve dist
# or: python -m http.server 3000 --directory dist
```
Then open `http://localhost:3000`.

> Opening `index.html` by double-clicking may work in Chrome/Edge, but a served
> `http(s)` address is more reliable and keeps imports saved under a stable origin.

## Important: a link shares the app, not the data

| Topic | Behaviour |
|---|---|
| Uploaded workbooks | Stored in this browser only (`localStorage`), per browser + per domain |
| Sharing the link | Others get an empty dashboard until they import their own files |
| Changing domain | Data imported on the old domain does not follow to the new one |
| Moving data between PCs | Export a report/register, or re-import the original workbooks |
| Multiple supervisors, one shared dataset | Requires a backend/database — not included |

## First use

1. Click **Import Excel** and drop one or many day-end files.
2. Ensure at least one sheet has one row per **job card** (JC No, Date In, Date Out/Status,
   Warranty Type, Service, Technician) for per-job reports.
3. Set the range/warranty/service/technician filters.
4. Use **Daily brief**, **Warranty Contribution**, **1-Hour Closures**, **Job Card Register**
   and **Daily / Weekly / Monthly Analysis**, then download Excel/CSV as needed.

A template with instructions is available inside the import dialog.
